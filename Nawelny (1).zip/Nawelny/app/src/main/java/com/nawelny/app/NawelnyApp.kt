package com.nawelny.app

import android.app.Application

class NawelnyApp : Application() {
    val hub by lazy { Hub(this) }
}
