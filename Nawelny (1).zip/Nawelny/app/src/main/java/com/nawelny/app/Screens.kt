package com.nawelny.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtTime(t: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))

@Composable
fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (on) MaterialTheme.colorScheme.primary else Color.White,
        shadowElevation = 1.dp,
        modifier = Modifier.padding(horizontal = 3.dp).clickable(onClick = onClick)
    ) {
        Text(label, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = if (on) Color.White else Color.Black, maxLines = 1)
    }
}

/** اختيار الأجهزة المستهدفة (الكل أو أجهزة محددة). */
@Composable
fun TargetsBar(hub: Hub) {
    if (hub.connected.isEmpty()) {
        Text("لا توجد أجهزة متصلة — اتصل بجهاز من تبويب الأجهزة", color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
    } else {
        val all = hub.connected.all { it.id in hub.selected }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("إلى: ")
            Chip("الكل", all) {
                if (all) hub.selected.clear()
                else hub.connected.forEach { if (it.id !in hub.selected) hub.selected.add(it.id) }
            }
            hub.connected.forEach { p ->
                Chip(p.name, p.id in hub.selected) {
                    if (p.id in hub.selected) hub.selected.remove(p.id) else hub.selected.add(p.id)
                }
            }
        }
    }
}

@Composable
fun TransferRow(hub: Hub, t: Transfer) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text((if (t.mine) "📤 " else "📥 ") + t.name + "  " + (t.progress * 100).toInt() + "%", maxLines = 1)
            LinearProgressIndicator(progress = { t.progress }, modifier = Modifier.fillMaxWidth())
        }
        TextButton({ hub.cancel(t) }) { Text("إلغاء") }
    }
}

// ───────────────── الأجهزة ─────────────────
@Composable
fun DevicesTab(hub: Hub, ok: Boolean) {
    var showSettings by remember { mutableStateOf(false) }
    if (showSettings) {
        var n by remember { mutableStateOf(hub.myName) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("الإعدادات") },
            text = {
                Column {
                    OutlinedTextField(n, { if (it.length <= 20) n = it }, label = { Text("اسم جهازك") }, singleLine = true)
                    TextButton({ hub.clearHistory() }) { Text("🗑 حذف سجل الرسائل والملفات") }
                }
            },
            confirmButton = { TextButton({ hub.rename(n); showSettings = false }) { Text("حفظ") } },
            dismissButton = { TextButton({ showSettings = false }) { Text("إغلاق") } }
        )
    }
    val avail = hub.found.filter { f -> hub.connected.none { it.id == f.id } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ناولني", Modifier.weight(1f), style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            TextButton({ showSettings = true }) { Text("⚙️ الإعدادات") }
        }
        Text("جهازك ظاهر للقريبين باسم: ${hub.myName}")
        Spacer(Modifier.height(8.dp))
        OutlinedButton({ hub.shareApp() }) { Text("📲 مشاركة التطبيق (APK) بأي وسيلة") }
        if (hub.queue.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Card { Text("📎 ${hub.queue.size} ملف جاهز للإرسال — اتصل بجهاز", Modifier.padding(16.dp)) }
        }
        LazyColumn(Modifier.weight(1f)) {
            item {
                Spacer(Modifier.height(16.dp))
                Text("الأجهزة المتصلة (${hub.connected.size})", style = MaterialTheme.typography.titleMedium)
                if (hub.connected.isEmpty()) Text("لا يوجد", color = Color.Gray)
            }
            items(hub.connected, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🟢 ${p.name}", Modifier.weight(1f))
                        TextButton({ hub.disconnect(p) }) { Text("قطع") }
                    }
                }
            }
            item {
                Spacer(Modifier.height(16.dp))
                Text("الأجهزة القريبة", style = MaterialTheme.typography.titleMedium)
                if (!ok) Text("يلزم السماح بالأذونات ليعمل التطبيق")
                else if (avail.isEmpty()) Text("جارٍ البحث… افتح ناولني على الجهاز الآخر", color = Color.Gray)
            }
            items(avail, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { hub.connect(p) }) {
                    Text("📱 ${p.name}  —  اضغط للاتصال", Modifier.padding(18.dp))
                }
            }
        }
    }
}

// ───────────────── إرسال ─────────────────
@Composable
fun RowScope.BigBtn(label: String, onClick: () -> Unit) {
    Button(onClick, Modifier.weight(1f).padding(4.dp)) { Text(label) }
}

@Composable
fun SendTab(hub: Hub) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { l ->
        if (l.isNotEmpty()) hub.sendNow(l)
    }
    val outgoing = hub.transfers.filter { it.mine }
    val log = hub.msgs.filter { it.type == "s" || (it.type == "e" && it.mine) }.asReversed()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("إرسال", style = MaterialTheme.typography.titleLarge)
        TargetsBar(hub)
        Row { BigBtn("📁 ملفات") { pick.launch("*/*") }; BigBtn("🎬 فيديوهات") { pick.launch("video/*") } }
        Row { BigBtn("🖼 صور") { pick.launch("image/*") }; BigBtn("📦 تطبيقات") { pick.launch("application/vnd.android.package-archive") } }
        OutlinedButton({ hub.sendAppToPeers() }, Modifier.fillMaxWidth().padding(horizontal = 4.dp)) { Text("📲 إرسال تطبيق ناولني نفسه") }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(outgoing) { TransferRow(hub, it) }
            items(log) { m -> Text(if (m.type == "s") "${iconOf(m.kind)} ${m.text}" else m.text, Modifier.padding(vertical = 4.dp)) }
        }
    }
}

// ───────────────── استلام ─────────────────
@Composable
fun ReceiveTab(hub: Hub) {
    var f by remember { mutableStateOf(0) }
    val incoming = hub.transfers.filter { !it.mine && it.accepted }
    val shown = hub.msgs.filter { m ->
        m.type == "f" && when (f) {
            0 -> m.kind == "image"
            1 -> m.kind == "video"
            2 -> m.kind == "apk" || m.kind == "aab"
            else -> m.kind != "image" && m.kind != "video" && m.kind != "apk" && m.kind != "aab"
        }
    }.asReversed()
    val errors = hub.msgs.filter { it.type == "e" && !it.mine }.takeLast(3).asReversed()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("استلام", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
            listOf("🖼 صور", "🎬 فيديوهات", "📦 تطبيقات", "📁 ملفات").forEachIndexed { i, l -> Chip(l, f == i) { f = i } }
        }
        incoming.forEach { TransferRow(hub, it) }
        LazyColumn(Modifier.weight(1f)) {
            if (shown.isEmpty()) item { Text("لا يوجد شيء هنا بعد", color = Color.Gray, modifier = Modifier.padding(8.dp)) }
            items(shown) { m ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${iconOf(m.kind)} ${m.text}")
                        Text("من ${m.from} • ${fmtTime(m.time)} • ${placeOf(m.kind)}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        val pad = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                        when (m.kind) {
                            "apk" -> TextButton({ m.uri?.let { hub.install(it) } }, contentPadding = pad) { Text("⬇️ تثبيت") }
                            "aab" -> Text("ملف AAB لا يُثبَّت مباشرة على الهاتف", style = MaterialTheme.typography.bodySmall)
                            else -> TextButton({ m.uri?.let { hub.open(it) } }, contentPadding = pad) { Text("فتح") }
                        }
                    }
                }
            }
            items(errors) { Text(it.text, Modifier.padding(vertical = 2.dp), color = Color.Gray) }
        }
    }
}

// ───────────────── رسائل ─────────────────
@Composable
fun ChatTab(hub: Hub) {
    var t by remember { mutableStateOf("") }
    val list = hub.msgs.filter { it.type == "t" }
    val state = rememberLazyListState()
    LaunchedEffect(list.size) { if (list.isNotEmpty()) state.animateScrollToItem(list.size - 1) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("رسائل", style = MaterialTheme.typography.titleLarge)
        TargetsBar(hub)
        LazyColumn(Modifier.weight(1f), state = state) {
            items(list) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.Start else Arrangement.End) {
                    Surface(shape = RoundedCornerShape(14.dp), color = if (m.mine) Color(0xFFD9FDD3) else Color.White,
                        shadowElevation = 1.dp, modifier = Modifier.padding(4.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            if (!m.mine) Text(m.from, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text(m.text)
                            Text(fmtTime(m.time), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            val link = firstLink(m.text)
                            val pad = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            Row {
                                if (link != null) TextButton({ hub.openLink(link) }, contentPadding = pad) { Text("🔗 فتح الرابط") }
                                TextButton({ hub.copy(m.text) }, contentPadding = pad) { Text("📋 نسخ") }
                            }
                        }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(t, { if (it.length <= 5000) t = it }, Modifier.weight(1f), placeholder = { Text("اكتب رسالة") })
            Spacer(Modifier.width(6.dp))
            Button({ if (t.isNotBlank()) { hub.sendText(t.trim()); t = "" } }) { Text("إرسال") }
        }
    }
}

// ───────────────── مكالمات ─────────────────
@Composable
fun CallsTab(hub: Hub, withMic: (() -> Unit) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("مكالمات", style = MaterialTheme.typography.titleLarge)
        TargetsBar(hub)
        Spacer(Modifier.height(8.dp))
        Button({ withMic { hub.callSelected() } }, enabled = hub.connected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
            Text(if (hub.inCall) "➕ إضافة المحددين للمكالمة" else "📞 اتصال صوتي بالمحدد")
        }
        if (hub.inCall) {
            Spacer(Modifier.height(16.dp))
            Text("🎙 مكالمة جارية", style = MaterialTheme.typography.titleMedium)
            hub.callPeers.forEach { Text("🟢 ${hub.peerName(it)}", Modifier.padding(vertical = 2.dp)) }
            hub.calling.forEach { Text("⏳ جارٍ الاتصال بـ ${hub.peerName(it)}", Modifier.padding(vertical = 2.dp), color = Color.Gray) }
            Spacer(Modifier.height(12.dp))
            Row {
                OutlinedButton({ hub.setMuted(!hub.muted) }, Modifier.weight(1f).padding(4.dp)) {
                    Text(if (hub.muted) "🔇 مكتوم" else "🎙 الميكروفون")
                }
                OutlinedButton({ hub.setSpeakerOn(!hub.speaker) }, Modifier.weight(1f).padding(4.dp)) {
                    Text(if (hub.speaker) "🔊 مكبّر الصوت" else "📱 السماعة")
                }
            }
            Button({ hub.endCall() }, Modifier.fillMaxWidth().padding(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) { Text("إنهاء المكالمة") }
        } else {
            Spacer(Modifier.height(12.dp))
            Text("المكالمة تعمل مباشرة بين الأجهزة القريبة بدون إنترنت.", color = Color.Gray)
        }
    }
}
