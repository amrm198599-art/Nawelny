package com.nawelny.app

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.ParcelFileDescriptor
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.Payload
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.ConcurrentHashMap

/** صوت المكالمات: ميكروفون -> Stream لكل جهاز، واستقبال Stream -> سماعة. */
class Voice(ctx: Context, private val client: ConnectionsClient) {
    private val rate = 16000
    private val am = ctx.getSystemService(AudioManager::class.java)
    private val outPipes = ConcurrentHashMap<String, OutputStream>()
    private val outPayloads = ConcurrentHashMap<String, Long>()
    private val players = ConcurrentHashMap<String, InputStream>()

    @Volatile var muted = false
    @Volatile var active = false
        private set

    fun begin() {
        if (active) return
        active = true
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        setSpeaker(true)
        Thread { recordLoop() }.start()
    }

    @Suppress("DEPRECATION")
    fun setSpeaker(on: Boolean) { am.isSpeakerphoneOn = on }

    /** ابدأ إرسال صوتك لهذا الجهاز. */
    fun addPeer(id: String) {
        removeOut(id)
        val pipe = ParcelFileDescriptor.createPipe()
        val p = Payload.fromStream(pipe[0])
        outPayloads[id] = p.id
        outPipes[id] = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
        client.sendPayload(id, p)
    }

    private fun removeOut(id: String) {
        outPipes.remove(id)?.let { runCatching { it.close() } }
        outPayloads.remove(id)?.let { runCatching { client.cancelPayload(it) } }
    }

    fun removePeer(id: String) {
        removeOut(id)
        players.remove(id)?.let { runCatching { it.close() } }
    }

    fun end() {
        active = false
        outPipes.keys.toList().forEach { removeOut(it) }
        players.keys.toList().forEach { id -> players.remove(id)?.let { runCatching { it.close() } } }
        am.mode = AudioManager.MODE_NORMAL
        setSpeaker(false)
    }

    @SuppressLint("MissingPermission")
    private fun recordLoop() {
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096) * 2)
        } catch (e: Exception) { return }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return }
        val buf = ByteArray(1280)
        rec.startRecording()
        try {
            while (active) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                if (muted) java.util.Arrays.fill(buf, 0, n, 0.toByte())
                for ((id, o) in outPipes) {
                    try { o.write(buf, 0, n) } catch (e: IOException) { outPipes.remove(id) }
                }
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
    }

    /** شغّل صوت الجهاز الآخر. */
    fun play(id: String, p: Payload) {
        val ins = p.asStream()?.asInputStream() ?: return
        players.put(id, ins)?.let { runCatching { it.close() } }
        Thread {
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(maxOf(min, 4096) * 2)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            track.play()
            val buf = ByteArray(1280)
            try {
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    if (n > 0) track.write(buf, 0, n)
                }
            } catch (e: Exception) {
            } finally {
                runCatching { track.stop() }
                track.release()
            }
        }.start()
    }
}
