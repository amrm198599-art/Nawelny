package com.nawelny.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var hub: Hub
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        hub = (application as NawelnyApp).hub
        handle(intent)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF00A884))) { App(hub) }
            }
        }
    }
    override fun onStart() {
        super.onStart(); hub.foreground = true; hub.refreshChecks()
        if (requiredGranted(this)) { hub.autoFix(); hub.ensureSearch() }
    }
    override fun onStop() { super.onStop(); hub.foreground = false }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }

    @Suppress("DEPRECATION")
    private fun handle(i: Intent?) {
        when (i?.action) {
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { hub.enqueue(listOf(it)) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { hub.enqueue(it) }
        }
    }
}

fun fmt(b: Long) = if (b >= 1_048_576) "%.1f م.ب".format(b / 1048576.0) else "${b / 1024} ك.ب"

fun perms(): Array<String> = buildList {
    if (Build.VERSION.SDK_INT >= 31) {
        add(Manifest.permission.BLUETOOTH_ADVERTISE); add(Manifest.permission.BLUETOOTH_CONNECT); add(Manifest.permission.BLUETOOTH_SCAN)
    }
    if (Build.VERSION.SDK_INT >= 33) { add(Manifest.permission.NEARBY_WIFI_DEVICES); add(Manifest.permission.POST_NOTIFICATIONS) }
    add(Manifest.permission.ACCESS_COARSE_LOCATION); add(Manifest.permission.ACCESS_FINE_LOCATION)
    if (Build.VERSION.SDK_INT <= 28) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    add(Manifest.permission.RECORD_AUDIO)
}.toTypedArray()

fun requiredGranted(ctx: Context): Boolean = perms().filter { it !in optionalPerms }
    .all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

private val optionalPerms: Set<String> = buildSet {
    add(Manifest.permission.POST_NOTIFICATIONS); add(Manifest.permission.RECORD_AUDIO)
    add(Manifest.permission.ACCESS_FINE_LOCATION)
    // على أندرويد 13+ الموقع غير إلزامي، وإن احتاجه النظام تظهر بطاقة التنبيه في شاشة الأجهزة
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.ACCESS_COARSE_LOCATION)
}

@Composable
fun App(hub: Hub) {
    val ctx = LocalContext.current
    var reqTick by remember { mutableStateOf(0) }
    val ok = remember(hub.permTick, reqTick) { requiredGranted(ctx) }
    var tab by remember { mutableStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        reqTick++
        if (requiredGranted(ctx)) { hub.refreshChecks(); hub.autoFix(); hub.ensureSearch() }
        else hub.openPermissionPage()   // يفتح صفحة أذونات التطبيق تلقائياً
    }
    LaunchedEffect(Unit) { launcher.launch(perms()) }

    var pendingMic by remember { mutableStateOf<(() -> Unit)?>(null) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingMic?.invoke()
        else Toast.makeText(ctx, "إذن الميكروفون مطلوب للمكالمات", Toast.LENGTH_LONG).show()
        pendingMic = null
    }
    val withMic: (() -> Unit) -> Unit = { action ->
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) action()
        else { pendingMic = action; micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
    }

    hub.requests.firstOrNull()?.let { (id, info) ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("طلب اتصال") },
            text = { Text("${hub.peerName(id)}\nرمز التحقق: ${info.authenticationDigits}\n(يجب أن يتطابق على الجهازين)") },
            confirmButton = { TextButton({ hub.accept(id) }) { Text("قبول") } },
            dismissButton = { TextButton({ hub.reject(id) }) { Text("رفض") } }
        )
    }
    hub.transfers.firstOrNull { !it.mine && !it.accepted && it.named }?.let { t ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("ملف وارد من ${hub.peerName(t.peerId)}") },
            text = { Text("${iconOf(null)} ${t.name}\n${fmt(t.size)}") },
            confirmButton = { TextButton({ hub.acceptFile(t) }) { Text("قبول") } },
            dismissButton = { TextButton({ hub.rejectFile(t) }) { Text("رفض") } }
        )
    }
    hub.ringing?.let { id ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("📞 مكالمة واردة") },
            text = { Text(hub.peerName(id)) },
            confirmButton = { TextButton({ withMic { hub.acceptCall() } }) { Text("رد") } },
            dismissButton = { TextButton({ hub.declineCall() }) { Text("رفض") } }
        )
    }

    val tabs = listOf("📡" to "الأجهزة", "📤" to "إرسال", "📥" to "استلام", "💬" to "رسائل", "📞" to "مكالمات")
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, (icon, label) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Text(icon) }, label = { Text(label, maxLines = 1) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFFF4FBF9))) {
            when (tab) {
                0 -> DevicesTab(hub, ok) { launcher.launch(perms()) }
                1 -> SendTab(hub)
                2 -> ReceiveTab(hub)
                3 -> ChatTab(hub)
                else -> CallsTab(hub, withMic)
            }
        }
    }
}
