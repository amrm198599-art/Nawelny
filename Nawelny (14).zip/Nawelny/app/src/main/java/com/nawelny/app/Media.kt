package com.nawelny.app

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import java.io.File

/** عنصر قابل للتحديد في شاشة «تحديد الملفات». kind: app | image | video | audio | file */
data class MediaItem(
    val key: String, val id: Long, val name: String, val size: Long,
    val uri: Uri?, val kind: String, val pkg: String? = null, val apkPath: String? = null
)

object Thumbs {
    private val c = LruCache<String, ImageBitmap>(300)
    fun get(k: String): ImageBitmap? = c.get(k)
    fun put(k: String, v: ImageBitmap) { c.put(k, v) }
}

fun mediaPerms(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

fun mediaGranted(ctx: Context): Boolean =
    mediaPerms().any { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

fun queryMedia(ctx: Context, collection: Uri, kind: String): List<MediaItem> {
    val out = mutableListOf<MediaItem>()
    val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE)
    runCatching {
        ctx.contentResolver.query(collection, proj, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            while (c.moveToNext() && out.size < 800) {
                val id = c.getLong(iId)
                out.add(MediaItem("$kind:$id", id, c.getString(iName) ?: "ملف", c.getLong(iSize),
                    ContentUris.withAppendedId(collection, id), kind))
            }
        }
    }
    return out
}

fun loadApps(ctx: Context): List<MediaItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return runCatching {
        pm.queryIntentActivities(i, 0)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .map { ai ->
                MediaItem("app:${ai.packageName}", 0, ai.loadLabel(pm).toString(),
                    File(ai.sourceDir).length(), null, "app", ai.packageName, ai.sourceDir)
            }
            .sortedBy { it.name.lowercase() }
    }.getOrDefault(emptyList())
}

private fun decodeSampled(ctx: Context, uri: Uri): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > 480) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
}

@Suppress("DEPRECATION")
fun loadThumb(ctx: Context, m: MediaItem): ImageBitmap? = runCatching {
    if (m.kind == "app") {
        ctx.packageManager.getApplicationIcon(m.pkg!!).toBitmap(112, 112).asImageBitmap()
    } else {
        val uri = m.uri ?: return@runCatching null
        val bmp: Bitmap? =
            if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(uri, Size(240, 240), null)
            else if (m.kind == "video") MediaStore.Video.Thumbnails.getThumbnail(ctx.contentResolver, m.id, MediaStore.Video.Thumbnails.MINI_KIND, null)
            else decodeSampled(ctx, uri)
        bmp?.asImageBitmap()
    }
}.getOrNull()
