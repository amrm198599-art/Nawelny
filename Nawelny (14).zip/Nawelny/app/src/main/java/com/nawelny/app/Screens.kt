package com.nawelny.app

import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.lazy.grid.items as gridItems

val Blue = Color(0xFF2D7FF9)
val Bg = Color(0xFFF5F5F5)

fun fmtTime(t: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))

// ───────────────── عناصر مشتركة ─────────────────
@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("→", fontSize = 28.sp, modifier = Modifier.clickable(onClick = onBack).padding(8.dp))
        Spacer(Modifier.width(8.dp))
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (on) Blue else Color.White,
        shadowElevation = 1.dp,
        modifier = Modifier.padding(horizontal = 3.dp).clickable(onClick = onClick)
    ) {
        Text(label, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = if (on) Color.White else Color.Black, maxLines = 1)
    }
}

/** اختيار الأجهزة المستهدفة (الكل أو أجهزة محددة). */
@Composable
fun TargetsBar(hub: Hub) {
    if (hub.connected.isEmpty()) {
        Text("لا توجد أجهزة متصلة", color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
    } else {
        val all = hub.connected.all { it.id in hub.selected }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("إلى: ")
            Chip("الكل", all) {
                if (all) hub.selected.clear()
                else hub.connected.forEach { if (it.id !in hub.selected) hub.selected.add(it.id) }
            }
            hub.connected.forEach { p ->
                Chip(p.name, p.id in hub.selected) {
                    if (p.id in hub.selected) hub.selected.remove(p.id) else hub.selected.add(p.id)
                }
            }
        }
    }
}

@Composable
fun TransferRow(hub: Hub, t: Transfer) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text((if (t.mine) "📤 " else "📥 ") + t.name + "  " + (t.progress * 100).toInt() + "%", maxLines = 1)
            LinearProgressIndicator(progress = { t.progress }, modifier = Modifier.fillMaxWidth())
        }
        TextButton({ hub.cancel(t) }) { Text("إلغاء") }
    }
}

@Composable
fun SettingsDialog(hub: Hub, onClose: () -> Unit) {
    var n by remember { mutableStateOf(hub.myName) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("الإعدادات") },
        text = {
            Column {
                OutlinedTextField(n, { if (it.length <= 20) n = it }, label = { Text("اسم جهازك") }, singleLine = true)
                TextButton({ hub.clearHistory() }) { Text("🗑 حذف سجل الرسائل والملفات") }
                Text("الإصدار ${hub.version}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        },
        confirmButton = { TextButton({ hub.rename(n); onClose() }) { Text("حفظ") } },
        dismissButton = { TextButton(onClose) { Text("إغلاق") } }
    )
}

// ───────────────── الرئيسية ─────────────────
@Composable
fun BigCircle(icon: String, label: String, badge: Int, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(4.dp)) {
        Box {
            Surface(shape = CircleShape, color = Blue, shadowElevation = 6.dp, modifier = Modifier.size(92.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(icon, fontSize = 36.sp) }
            }
            if (badge > 0) Surface(shape = CircleShape, color = Color(0xFFE53935), modifier = Modifier.align(Alignment.TopEnd)) {
                Text(badge.toString(), color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(label, fontSize = 17.sp, color = Color(0xFF333B52))
    }
}

@Composable
fun Tile(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White, shadowElevation = 1.dp, modifier = modifier.clickable(onClick = onClick)) {
        Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 26.sp)
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
fun HomeScreen(hub: Hub, nav: (String) -> Unit) {
    var settings by remember { mutableStateOf(false) }
    if (settings) SettingsDialog(hub) { settings = false }
    val received = hub.msgs.count { it.type == "f" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(50), color = Blue) {
                Text("ناولني", Modifier.padding(horizontal = 24.dp, vertical = 8.dp), color = Color.White,
                    fontWeight = FontWeight.Bold, fontSize = 24.sp)
            }
            Spacer(Modifier.weight(1f))
            TextButton({ settings = true }) { Text("⚙️", fontSize = 24.sp) }
        }
        Spacer(Modifier.height(36.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            BigCircle("📂", "ملفات", received) { nav("files") }
            BigCircle("📥", "استلام", 0) { nav("recv") }
            BigCircle("📤", "إرسال", 0) { nav("pick") }
        }
        Spacer(Modifier.height(32.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("💬", "رسائل", Modifier.weight(1f)) { nav("chat") }
            Tile("📞", "مكالمات", Modifier.weight(1f)) { nav("calls") }
            Tile("📲", "شارك التطبيق", Modifier.weight(1f)) { hub.shareApp() }
        }
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("🔢 رقم جهازك", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(hub.myCode, Modifier.weight(1f), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Blue)
                    TextButton({ hub.copy(hub.myCode) }) { Text("📋 نسخ") }
                }
                Text("الاسم: ${hub.myName}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth().clickable { nav("recv") }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("الأجهزة المتصلة (${hub.connected.size})", fontWeight = FontWeight.Bold)
                if (hub.connected.isEmpty()) Text("لا يوجد — اضغط «استلام» أو «إرسال» للاتصال بجهاز", color = Color.Gray, fontSize = 13.sp)
                else hub.connected.forEach { Text("🟢 ${it.name}", Modifier.padding(top = 4.dp)) }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ───────────────── الاتصال بالأجهزة (إرسال / استلام) ─────────────────
@Composable
fun ConnectScreen(hub: Hub, ok: Boolean, requestPerms: () -> Unit, title: String, onBack: () -> Unit) {
    val avail = hub.found.filter { f -> hub.connected.none { it.id == f.id } }
    val outgoing = hub.transfers.filter { it.mine }
    var codeIn by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        TopBar(title, onBack)
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            item {
                Text("جهازك ظاهر للقريبين باسم: ${hub.myName}")
                Spacer(Modifier.height(8.dp))
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🔢 رقم جهازك (أعطه للطرف الآخر)", style = MaterialTheme.typography.labelMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(hub.myCode, Modifier.weight(1f), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Blue)
                            TextButton({ hub.copy(hub.myCode) }) { Text("📋 نسخ") }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("اتصل برقم جهاز آخر", style = MaterialTheme.typography.labelMedium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(codeIn, { v -> if (v.length <= 6 && v.all { it.isDigit() }) codeIn = v },
                                Modifier.weight(1f), singleLine = true, placeholder = { Text("000000") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            Spacer(Modifier.width(8.dp))
                            Button({ hub.connectByCode(codeIn) }) { Text("اتصال") }
                        }
                        if (hub.codeStatus.isNotEmpty()) Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(hub.codeStatus, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            TextButton({ hub.cancelCode() }) { Text("إلغاء") }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton({ hub.resetAsked(); requestPerms(); hub.refreshChecks(); hub.autoFix(); hub.restartSearch() }) {
                    Text("🔄 إعادة البحث")
                }
                if (hub.advStatus != "يعمل ✅" || hub.discStatus != "يعمل ✅") {
                    val tick = hub.permTick
                    Text("الأذونات (كما يراها التطبيق):\n${hub.permReport()}", style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
                    Text("البث: ${hub.advStatus}\nالبحث: ${hub.discStatus}", style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
                }
                if (hub.queue.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Card { Text("📎 ${hub.queue.size} ملف جاهز للإرسال — اتصل بجهاز وسيبدأ الإرسال تلقائياً", Modifier.padding(16.dp)) }
                }
                outgoing.forEach { TransferRow(hub, it) }
                Spacer(Modifier.height(12.dp))
                Text("الأجهزة المتصلة (${hub.connected.size})", style = MaterialTheme.typography.titleMedium)
                if (hub.connected.isEmpty()) Text("لا يوجد", color = Color.Gray) else TargetsBar(hub)
            }
            items(hub.connected, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🟢 ${p.name}", Modifier.weight(1f))
                        TextButton({ hub.disconnect(p) }) { Text("قطع") }
                    }
                }
            }
            item {
                Spacer(Modifier.height(16.dp))
                Text("الأجهزة القريبة", style = MaterialTheme.typography.titleMedium)
                if (!ok) Text("يلزم السماح بالأذونات ليعمل التطبيق")
                else if (avail.isEmpty()) Text("جارٍ البحث… افتح ناولني على الجهاز الآخر", color = Color.Gray)
            }
            items(avail, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { hub.connectNow(p) },
                    colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Text("📱 ${p.name}  —  اضغط للاتصال", Modifier.padding(18.dp))
                }
            }
            item {
                if (hub.log.isNotEmpty()) Text("السجل:\n" + hub.log.joinToString("\n"),
                    style = MaterialTheme.typography.bodySmall, color = Color.Gray, modifier = Modifier.padding(top = 16.dp, bottom = 16.dp))
            }
        }
    }
}

// ───────────────── تحديد الملفات ─────────────────
@Composable
fun CheckMark(sel: Boolean, modifier: Modifier) {
    Box(modifier.padding(4.dp).size(22.dp).clip(CircleShape)
        .background(if (sel) Blue else Color.White.copy(alpha = 0.75f))
        .border(1.5.dp, if (sel) Blue else Color.Gray, CircleShape), contentAlignment = Alignment.Center) {
        if (sel) Text("✓", color = Color.White, fontSize = 14.sp)
    }
}

@Composable
fun Thumb(m: MediaItem, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(Thumbs.get(m.key), m.key) {
        if (value == null) value = withContext(Dispatchers.IO) { loadThumb(ctx, m)?.also { Thumbs.put(m.key, it) } }
    }
    Box(modifier.background(Color(0xFFE6E6E6)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(if (m.kind == "app") "📦" else iconOf(m.kind), fontSize = 22.sp)
    }
}

@Composable
fun PickCell(hub: Hub, m: MediaItem, square: Boolean) {
    val sel = hub.picks.any { it.key == m.key }
    Column(Modifier.padding(4.dp).clickable { hub.togglePick(m) }, horizontalAlignment = Alignment.CenterHorizontally) {
        if (square) {
            Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
                Thumb(m, Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)))
                if (m.kind == "video") Text("▶", color = Color.White, fontSize = 18.sp, modifier = Modifier.align(Alignment.Center))
                CheckMark(sel, Modifier.align(Alignment.TopStart))
            }
        } else {
            Box(Modifier.size(64.dp)) {
                Thumb(m, Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)))
                CheckMark(sel, Modifier.align(Alignment.TopStart))
            }
            Text(m.name, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
            Text(fmt(m.size), fontSize = 11.sp, color = Color.Gray)
        }
    }
}

@Composable
fun PickRow(hub: Hub, m: MediaItem) {
    val sel = hub.picks.any { it.key == m.key }
    Row(Modifier.fillMaxWidth().clickable { hub.togglePick(m) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(iconOf(m.kind), fontSize = 26.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(m.name, maxLines = 1)
            Text(fmt(m.size), fontSize = 12.sp, color = Color.Gray)
        }
        CheckMark(sel, Modifier)
    }
}

@Composable
fun PickScreen(hub: Hub, onBack: () -> Unit, onNext: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf("image") }
    var permTick by remember { mutableStateOf(0) }
    val granted = remember(permTick) { mediaGranted(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permTick++ }
    LaunchedEffect(Unit) { if (!mediaGranted(ctx)) launcher.launch(mediaPerms()) }
    val sys = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { hub.addPicked(it) }
    var data by remember { mutableStateOf<List<MediaItem>?>(null) }
    LaunchedEffect(tab, granted) {
        data = null
        data = withContext(Dispatchers.IO) {
            when (tab) {
                "app" -> loadApps(ctx)
                "image" -> queryMedia(ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image")
                "video" -> queryMedia(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video")
                "audio" -> queryMedia(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio")
                else -> emptyList()
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("تحديد الملفات", onBack)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
            listOf("audio" to "موسيقى", "image" to "صور", "app" to "تطبيقات", "video" to "فيديوهات", "file" to "ملفات").forEach { (k, l) ->
                Column(Modifier.clickable { tab = k }.padding(horizontal = 14.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(l, fontSize = 17.sp, fontWeight = if (tab == k) FontWeight.Bold else FontWeight.Normal,
                        color = if (tab == k) Color.Black else Color.Gray)
                    Box(Modifier.padding(top = 4.dp).height(3.dp).width(24.dp).background(if (tab == k) Blue else Color.Transparent))
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val list = data
            when {
                tab == "file" -> Column(Modifier.fillMaxSize().padding(16.dp)) {
                    Button({ sys.launch("*/*") }, Modifier.fillMaxWidth()) { Text("📁 تصفح الملفات واختيارها") }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn { items(hub.picks.filter { it.kind == "file" }, key = { it.key }) { PickRow(hub, it) } }
                }
                tab != "app" && !granted -> Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("يلزم السماح بالوصول للوسائط لعرضها", color = Color.Gray)
                    Spacer(Modifier.height(8.dp))
                    Button({ launcher.launch(mediaPerms()) }) { Text("السماح") }
                    TextButton({ hub.openAppSettings() }) { Text("فتح إعدادات التطبيق") }
                }
                list == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                list.isEmpty() -> Text("لا يوجد شيء هنا", color = Color.Gray, modifier = Modifier.align(Alignment.Center))
                tab == "audio" -> LazyColumn { items(list, key = { it.key }) { PickRow(hub, it) } }
                else -> LazyVerticalGrid(columns = GridCells.Fixed(if (tab == "app") 4 else 3), contentPadding = PaddingValues(8.dp)) {
                    gridItems(list, key = { it.key }) { PickCell(hub, it, tab != "app") }
                }
            }
        }
        Surface(shadowElevation = 8.dp, color = Color.White) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("تم تحديد ${hub.picks.size} ملف (ملفات)", Modifier.weight(1f))
                Button(onNext, enabled = hub.picks.isNotEmpty(), shape = RoundedCornerShape(12.dp)) { Text("التالي") }
            }
        }
    }
}

// ───────────────── الملفات المستلمة ─────────────────
private fun group(kind: String?) = when (kind) {
    "apk", "aab" -> "app"; "audio" -> "audio"; "image" -> "image"; "video" -> "video"; "doc" -> "doc"; else -> "file"
}

@Composable
fun FilesScreen(hub: Hub, onBack: () -> Unit) {
    var cat by remember { mutableStateOf<String?>(null) }
    val files = hub.msgs.filter { it.type == "f" }
    val cats = listOf("app" to ("📦" to "تطبيقات"), "audio" to ("🎵" to "موسيقى"), "image" to ("🖼" to "صور"),
        "video" to ("🎬" to "فيديوهات"), "doc" to ("📄" to "مستندات"), "file" to ("📁" to "ملفات أخرى"))
    val colors = listOf(Color(0xFF3B9BFF), Color(0xFFFF5A5A), Color(0xFF45C36B), Color(0xFF8A5CF6), Color(0xFFFF9A2E), Color(0xFF7A869A))
    val incoming = hub.transfers.filter { !it.mine && it.accepted }
    Column(Modifier.fillMaxSize()) {
        TopBar(cats.firstOrNull { it.first == cat }?.second?.second ?: "ملفاتي المستلمة") { if (cat != null) cat = null else onBack() }
        if (cat == null) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(12.dp)) {
                        cats.chunked(3).forEachIndexed { r, row ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                row.forEachIndexed { c, (k, v) ->
                                    val n = files.count { group(it.kind) == k }
                                    Column(Modifier.weight(1f).clickable { cat = k }, horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(Modifier.size(64.dp).clip(RoundedCornerShape(18.dp)).background(colors[r * 3 + c]), contentAlignment = Alignment.Center) {
                                            Text(v.first, fontSize = 30.sp)
                                        }
                                        Text(v.second, Modifier.padding(top = 6.dp), fontSize = 15.sp)
                                        Text(n.toString(), fontSize = 13.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                incoming.forEach { TransferRow(hub, it) }
                hub.msgs.filter { it.type == "e" && !it.mine }.takeLast(3).asReversed().forEach {
                    Text(it.text, Modifier.padding(vertical = 2.dp), color = Color.Gray)
                }
            }
        } else {
            val shown = files.filter { group(it.kind) == cat }.asReversed()
            LazyColumn(Modifier.padding(horizontal = 16.dp)) {
                if (shown.isEmpty()) item { Text("لا يوجد شيء هنا بعد", color = Color.Gray, modifier = Modifier.padding(8.dp)) }
                items(shown) { m ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${iconOf(m.kind)} ${m.text}")
                            Text("من ${m.from} • ${fmtTime(m.time)} • ${placeOf(m.kind)}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            val pad = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            when (m.kind) {
                                "apk" -> TextButton({ m.uri?.let { hub.install(it) } }, contentPadding = pad) { Text("⬇️ تثبيت") }
                                "aab" -> Text("ملف AAB لا يُثبَّت مباشرة على الهاتف", style = MaterialTheme.typography.bodySmall)
                                else -> TextButton({ m.uri?.let { hub.open(it) } }, contentPadding = pad) { Text("فتح") }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ───────────────── رسائل ─────────────────
@Composable
fun ChatTab(hub: Hub, modifier: Modifier) {
    var t by remember { mutableStateOf("") }
    val list = hub.msgs.filter { it.type == "t" }
    val state = rememberLazyListState()
    LaunchedEffect(list.size) { if (list.isNotEmpty()) state.animateScrollToItem(list.size - 1) }
    Column(modifier.padding(horizontal = 12.dp)) {
        TargetsBar(hub)
        LazyColumn(Modifier.weight(1f), state = state) {
            items(list) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.Start else Arrangement.End) {
                    Surface(shape = RoundedCornerShape(14.dp), color = if (m.mine) Color(0xFFD6E8FF) else Color.White,
                        shadowElevation = 1.dp, modifier = Modifier.padding(4.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            if (!m.mine) Text(m.from, style = MaterialTheme.typography.labelSmall, color = Blue)
                            Text(m.text)
                            Text(fmtTime(m.time), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            val link = firstLink(m.text)
                            val pad = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            Row {
                                if (link != null) TextButton({ hub.openLink(link) }, contentPadding = pad) { Text("🔗 فتح الرابط") }
                                TextButton({ hub.copy(m.text) }, contentPadding = pad) { Text("📋 نسخ") }
                            }
                        }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            OutlinedTextField(t, { if (it.length <= 5000) t = it }, Modifier.weight(1f), placeholder = { Text("اكتب رسالة") })
            Spacer(Modifier.width(6.dp))
            Button({ if (t.isNotBlank()) { hub.sendText(t.trim()); t = "" } }) { Text("إرسال") }
        }
    }
}

// ───────────────── مكالمات ─────────────────
@Composable
fun CallsTab(hub: Hub, withMic: (() -> Unit) -> Unit, modifier: Modifier) {
    Column(modifier.padding(16.dp)) {
        TargetsBar(hub)
        Spacer(Modifier.height(8.dp))
        Button({ withMic { hub.callSelected() } }, enabled = hub.connected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
            Text(if (hub.inCall) "➕ إضافة المحددين للمكالمة" else "📞 اتصال صوتي بالمحدد")
        }
        if (hub.inCall) {
            Spacer(Modifier.height(16.dp))
            Text("🎙 مكالمة جارية", style = MaterialTheme.typography.titleMedium)
            hub.callPeers.forEach { Text("🟢 ${hub.peerName(it)}", Modifier.padding(vertical = 2.dp)) }
            hub.calling.forEach { Text("⏳ جارٍ الاتصال بـ ${hub.peerName(it)}", Modifier.padding(vertical = 2.dp), color = Color.Gray) }
            Spacer(Modifier.height(12.dp))
            Row {
                OutlinedButton({ hub.muteMic(!hub.muted) }, Modifier.weight(1f).padding(4.dp)) {
                    Text(if (hub.muted) "🔇 مكتوم" else "🎙 الميكروفون")
                }
                OutlinedButton({ hub.setSpeakerOn(!hub.speaker) }, Modifier.weight(1f).padding(4.dp)) {
                    Text(if (hub.speaker) "🔊 مكبّر الصوت" else "📱 السماعة")
                }
            }
            Button({ hub.endCall() }, Modifier.fillMaxWidth().padding(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) { Text("إنهاء المكالمة") }
        } else {
            Spacer(Modifier.height(12.dp))
            Text("المكالمة تعمل مباشرة بين الأجهزة القريبة بدون إنترنت.", color = Color.Gray)
        }
    }
}
