package com.nawelny.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Patterns
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

data class Peer(val id: String, val name: String, val code: String = "")

/** type: t رسالة نصية | f ملف مستلم | s ملف مُرسل | e حدث/خطأ */
data class Msg(
    val type: String, val mine: Boolean, val from: String, val text: String,
    val uri: String? = null, val kind: String? = null, val time: Long = System.currentTimeMillis()
)

class Transfer(val id: Long, name: String, val mine: Boolean, val peerId: String) {
    var name by mutableStateOf(name)
    var progress by mutableStateOf(0f)
    var named by mutableStateOf(false)
    var accepted by mutableStateOf(mine)
    var size = 0L
    var completed = false
    val targets = mutableSetOf<String>()
    var toNames = ""
}

fun iconOf(kind: String?) = when (kind) {
    "image" -> "🖼"; "video" -> "🎬"; "audio" -> "🎵"; "apk", "aab" -> "📦"; "doc" -> "📄"; else -> "📁"
}

fun placeOf(kind: String?) = when (kind) {
    "image" -> "معرض الصور"; "video" -> "معرض الفيديو"; "audio" -> "الموسيقى"; "doc" -> "المستندات"; else -> "التنزيلات"
}

fun firstLink(t: String): String? {
    val m = Patterns.WEB_URL.matcher(t)
    while (m.find()) {
        val u = m.group()
        if (u.contains("://")) return u
        if (u.startsWith("www.", ignoreCase = true) || u.contains("/")) return "https://$u"
    }
    return null
}

class Hub(private val ctx: Context) {
    private val client = Nearby.getConnectionsClient(ctx)
    private val voice = Voice(ctx, client)
    private val service = "com.nawelny.app"
    private val prefs = ctx.getSharedPreferences("nawelny", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())

    var myName by mutableStateOf(prefs.getString("name", null)
        ?: ("ناولني-" + (1000..9999).random()).also { prefs.edit().putString("name", it).apply() })
    var foreground = false
    val version: String = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""

    /** رقم الجهاز (6 أرقام) يظهر للآخرين ليتصلوا به مباشرة. */
    val myCode: String = prefs.getString("code", null)
        ?: (100000..999999).random().toString().also { prefs.edit().putString("code", it).apply() }
    var codeStatus by mutableStateOf("")
    private var pendingCode: String? = null
    private fun advName() = "$myName#$myCode"
    private fun parseName(s: String): Pair<String, String> {
        val m = Regex("^(.*)#(\\d{6})$").find(s)
        return if (m != null) m.groupValues[1] to m.groupValues[2] else s to ""
    }

    val found = mutableStateListOf<Peer>()
    val connected = mutableStateListOf<Peer>()
    val selected = mutableStateListOf<String>()
    val msgs = mutableStateListOf<Msg>()
    val queue = mutableStateListOf<Uri>()
    val requests = mutableStateListOf<Pair<String, ConnectionInfo>>()
    val transfers = mutableStateListOf<Transfer>()

    val callPeers = mutableStateListOf<String>()
    val calling = mutableStateListOf<String>()
    var ringing by mutableStateOf<String?>(null)
    var muted by mutableStateOf(false)
    var speaker by mutableStateOf(true)
    val inCall: Boolean get() = callPeers.isNotEmpty() || calling.isNotEmpty()

    var advStatus by mutableStateOf("…")
    var discStatus by mutableStateOf("…")
    val warnings = mutableStateListOf<String>()
    private var started = false
    private val files = HashMap<Long, Payload>()
    private val pendingNames = HashMap<String, String>()
    private val held = HashMap<Uri, android.os.ParcelFileDescriptor>()
    private val heldNames = HashMap<Uri, String>()

    init { loadHistory() }

    private fun ui(f: () -> Unit) { if (Looper.myLooper() == Looper.getMainLooper()) f() else main.post(f) }
    private fun toast(s: String) = ui { Toast.makeText(ctx, s, Toast.LENGTH_LONG).show() }

    fun peerName(id: String): String =
        connected.find { it.id == id }?.name ?: pendingNames[id] ?: "جهاز قريب"

    private fun safeName(n: String): String =
        File(n.replace("\\", "/")).name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_")
            .trim('.', ' ').ifBlank { "ملف" }.take(120)

    // ───────── السجل ─────────
    private val histFile get() = File(ctx.filesDir, "h_room.txt")

    private fun clean(s: String) = s.replace("\u0002", "").replace("\\", "\\\\").replace("\n", "\\n")
    private fun unclean(s: String) =
        Regex("\\\\(.)").replace(s) { if (it.groupValues[1] == "n") "\n" else it.groupValues[1] }

    private fun addMsg(m: Msg) = ui {
        msgs.add(m)
        runCatching {
            histFile.appendText(listOf(m.type, if (m.mine) "1" else "0", m.time.toString(), clean(m.from),
                m.kind ?: "", m.uri ?: "", clean(m.text)).joinToString("\u0002") + "\n")
        }
    }

    private fun loadHistory() {
        val f = histFile
        if (!f.exists()) return
        runCatching {
            f.readLines().forEach { l ->
                val p = l.split('\u0002', limit = 7)
                if (p.size == 7) msgs.add(Msg(p[0], p[1] == "1", unclean(p[3]), unclean(p[6]),
                    p[5].ifBlank { null }, p[4].ifBlank { null }, p[2].toLongOrNull() ?: 0L))
            }
        }
    }

    fun clearHistory() {
        ctx.filesDir.listFiles { f -> f.name.startsWith("h_") }?.forEach { it.delete() }
        msgs.clear()
    }

    // ───────── الاتصال ─────────
    private fun startSvc(call: Boolean) {
        runCatching { ctx.startForegroundService(Intent(ctx, TransferService::class.java).putExtra("call", call)) }
    }
    private fun stopSvc() { ctx.stopService(Intent(ctx, TransferService::class.java)) }

    private val conn = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            pendingNames[id] = parseName(info.endpointName).first
            requests.add(id to info)
            if (!foreground) notifyUser("طلب اتصال", "${pendingNames[id]} يريد الاتصال بك")
        }
        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            requests.removeAll { it.first == id }
            codeStatus = ""
            if (r.status.isSuccess) {
                if (connected.none { it.id == id }) connected.add(Peer(id, pendingNames[id] ?: "جهاز قريب"))
                if (id !in selected) selected.add(id)
                startSvc(voice.active)
                flush(listOf(id))
            }
        }
        override fun onDisconnected(id: String) { dropPeer(id) }
    }

    private fun dropPeer(id: String) {
        connected.removeAll { it.id == id }
        selected.remove(id)
        transfers.filter { !it.mine && it.peerId == id }.forEach { files.remove(it.id); transfers.remove(it) }
        transfers.filter { it.mine }.forEach { it.targets.remove(id); if (it.targets.isEmpty()) transfers.remove(it) }
        dropCall(id)
        if (connected.isEmpty()) stopSvc()
    }

    private fun okCode(e: Exception): Boolean {
        val m = e.message ?: ""
        return m.startsWith("8001") || m.startsWith("8002")
    }

    fun start() {
        if (started) return
        started = true
        advStatus = "…"; discStatus = "…"
        val s = Strategy.P2P_CLUSTER
        client.startAdvertising(advName(), service, conn, AdvertisingOptions.Builder().setStrategy(s).build())
            .addOnSuccessListener { advStatus = "يعمل ✅" }
            .addOnFailureListener { advStatus = if (okCode(it)) "يعمل ✅" else "فشل ❌ ${it.message}" }
        client.startDiscovery(service, object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(id: String, i: DiscoveredEndpointInfo) {
                val (n, c) = parseName(i.endpointName)
                val peer = Peer(id, n, c)
                found.removeAll { it.id == id }; found.add(peer)
                if (c.isNotEmpty() && c == pendingCode) {
                    pendingCode = null
                    codeStatus = "تم العثور على $n — جارٍ الاتصال…"
                    connect(peer)
                }
            }
            override fun onEndpointLost(id: String) { found.removeAll { it.id == id } }
        }, DiscoveryOptions.Builder().setStrategy(s).build())
            .addOnSuccessListener { discStatus = "يعمل ✅" }
            .addOnFailureListener { discStatus = if (okCode(it)) "يعمل ✅" else "فشل ❌ ${it.message}" }
    }

    fun restartSearch() {
        client.stopAdvertising(); client.stopDiscovery()
        found.clear(); started = false
        start()
    }

    /** يفحص الموقع والبلوتوث والواي فاي، لأن Nearby لا يعمل بدونها. */
    fun refreshChecks() {
        permTick++
        val had = warnings.isNotEmpty()
        warnings.clear()
        runCatching {
            if (Build.VERSION.SDK_INT <= 32) {
                val lm = ctx.getSystemService(LocationManager::class.java)
                val on = if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled else true
                if (!on) warnings.add("loc")
            }
            val bt = ctx.getSystemService(BluetoothManager::class.java)?.adapter
            if (bt != null && !bt.isEnabled) warnings.add("bt")
            val wm = ctx.applicationContext.getSystemService(WifiManager::class.java)
            if (wm != null && !wm.isWifiEnabled) warnings.add("wifi")
        }
        if (started && ((had && warnings.isEmpty()) || failing())) restartSearch()
    }

    var permTick by mutableStateOf(0)

    /** حالة الأذونات كما يراها التطبيق نفسه. */
    fun permReport(): String {
        fun g(p: String) = if (ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED) "✅" else "❌"
        val l = mutableListOf("أندرويد ${Build.VERSION.SDK_INT}")
        l.add("موقع تقريبي ${g(Manifest.permission.ACCESS_COARSE_LOCATION)}")
        l.add("موقع دقيق ${g(Manifest.permission.ACCESS_FINE_LOCATION)}")
        if (Build.VERSION.SDK_INT >= 31) {
            l.add("بلوتوث مسح ${g(Manifest.permission.BLUETOOTH_SCAN)}")
            l.add("بلوتوث بث ${g(Manifest.permission.BLUETOOTH_ADVERTISE)}")
            l.add("بلوتوث اتصال ${g(Manifest.permission.BLUETOOTH_CONNECT)}")
        }
        if (Build.VERSION.SDK_INT >= 33) l.add("أجهزة قريبة ${g(Manifest.permission.NEARBY_WIFI_DEVICES)}")
        return l.joinToString(" • ")
    }

    private fun failing() = advStatus.startsWith("فشل") || discStatus.startsWith("فشل")

    /** يبدأ البحث، أو يعيده إذا كان فاشلاً (مثلاً بعد منح إذن ناقص). */
    fun ensureSearch() { if (!started) start() else if (failing()) restartSearch() }

    fun openAppSettings() {
        runCatching {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun openSettings(kind: String) {
        val action = when (kind) {
            "loc" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "bt" -> Settings.ACTION_BLUETOOTH_SETTINGS
            else -> Settings.ACTION_WIFI_SETTINGS
        }
        runCatching { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun rename(n: String) {
        val v = n.trim()
        if (v.length < 2 || v == myName) return
        myName = v; prefs.edit().putString("name", v).apply()
        restartSearch()
    }

    fun connectByCode(raw: String) {
        val c = raw.mapNotNull { ch -> Character.digit(ch, 10).takeIf { it >= 0 } }.joinToString("")
        if (c.length != 6) { toast("الرقم يتكون من 6 أرقام"); return }
        if (c == myCode) { toast("هذا رقم جهازك أنت"); return }
        val p = found.find { it.code == c }
        if (p != null) {
            codeStatus = "جارٍ الاتصال بـ ${p.name}…"
            connect(p)
        } else {
            pendingCode = c
            codeStatus = "جارٍ البحث عن الجهاز $c… تأكد أن ناولني مفتوح عليه"
            if (!started) start()
        }
    }

    fun cancelCode() { pendingCode = null; codeStatus = "" }

    fun connect(p: Peer) {
        client.requestConnection(advName(), p.id, conn).addOnFailureListener { toast("تعذر الاتصال بـ ${p.name}") }
    }
    fun accept(id: String) { requests.removeAll { it.first == id }; client.acceptConnection(id, pcb) }
    fun reject(id: String) { requests.removeAll { it.first == id }; client.rejectConnection(id) }
    fun disconnect(p: Peer) { client.disconnectFromEndpoint(p.id); dropPeer(p.id) }

    // ───────── استقبال ─────────
    private val pcb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            if (p.type == Payload.Type.BYTES) {
                onBytes(id, String(p.asBytes() ?: return))
            } else if (p.type == Payload.Type.FILE) {
                files[p.id] = p
                if (transfers.none { it.id == p.id }) transfers.add(Transfer(p.id, "ملف", false, id))
            } else if (p.type == Payload.Type.STREAM) {
                if (id in callPeers || id in calling) voice.play(id, p) else client.cancelPayload(p.id)
            }
        }

        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {
            val t = transfers.find { it.id == u.payloadId } ?: return
            when (u.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS ->
                    if (u.totalBytes > 0) t.progress = u.bytesTransferred.toFloat() / u.totalBytes
                PayloadTransferUpdate.Status.SUCCESS ->
                    if (t.mine) { t.targets.remove(id); if (t.targets.isEmpty()) finishSent(t, true) }
                    else { t.completed = true; trySave(t) }
                else -> {
                    if (t.mine) { t.targets.remove(id); if (t.targets.isEmpty()) finishSent(t, false) }
                    else {
                        transfers.remove(t); files.remove(t.id)
                        addMsg(Msg("e", false, peerName(t.peerId), "⚠️ لم يكتمل: ${t.name}"))
                    }
                }
            }
        }
    }

    private fun finishSent(t: Transfer, ok: Boolean) {
        transfers.remove(t)
        val k = kindOf(t.name, mimeOf(t.name))
        addMsg(if (ok) Msg("s", true, "أنا", "${t.name}  ←  ${t.toNames}", null, k)
               else Msg("e", true, "أنا", "⚠️ لم يكتمل إرسال: ${t.name}"))
    }

    private fun onBytes(id: String, s: String) {
        val from = peerName(id)
        when {
            s.startsWith("T|") -> {
                val text = s.drop(2)
                addMsg(Msg("t", false, from, text))
                if (!foreground) notifyUser("رسالة من $from", text.take(80))
            }
            s.startsWith("F|") -> runCatching {
                val (pid, sz, n) = s.drop(2).split("|", limit = 3)
                val pidL = pid.toLong()
                val t = transfers.find { it.id == pidL } ?: Transfer(pidL, "ملف", false, id).also { transfers.add(it) }
                t.name = safeName(n); t.size = sz.toLongOrNull() ?: 0L; t.named = true
                if (!foreground) notifyUser("ملف وارد من $from", t.name)
                trySave(t)
            }
            s.startsWith("C|") -> onCtl(id, s.drop(2))
        }
    }

    private fun notifyUser(title: String, text: String) = runCatching {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("req", "تنبيهات ناولني", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(2, Notification.Builder(ctx, "req").setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setContentIntent(pi).setAutoCancel(true).build())
    }

    private fun trySave(t: Transfer) {
        if (!t.mine && t.completed && t.named && t.accepted) {
            transfers.remove(t); files.remove(t.id)?.let { save(it, t.name, peerName(t.peerId)) }
        }
    }

    fun acceptFile(t: Transfer) { t.accepted = true; trySave(t) }
    fun rejectFile(t: Transfer) {
        client.cancelPayload(t.id); transfers.remove(t); files.remove(t.id)
        addMsg(Msg("e", false, peerName(t.peerId), "🚫 رفضت: ${t.name}"))
    }

    // ───────── إرسال ─────────
    fun targets(): List<String> = selected.filter { id -> connected.any { it.id == id } }

    fun sendText(t: String) {
        val ids = targets()
        if (ids.isEmpty()) { toast("اختر جهازاً متصلاً أولاً"); return }
        val b = "T|$t".toByteArray()
        if (b.size > 32000) { toast("الرسالة أطول من المسموح"); return }
        client.sendPayload(ids, Payload.fromBytes(b))
        addMsg(Msg("t", true, "أنا", t))
    }

    /** ملفات واردة من «مشاركة» خارج التطبيق: تنتظر حتى يتصل جهاز. */
    fun enqueue(l: List<Uri>) {
        l.forEach { u ->
            runCatching { ctx.contentResolver.openFileDescriptor(u, "r") }.getOrNull()?.let { held[u] = it }
            heldNames[u] = nameOf(u)
        }
        queue.addAll(l)
        val ids = targets()
        if (ids.isNotEmpty()) flush(ids)
    }

    fun flush(ids: List<String>) { queue.toList().forEach { sendFile(it, ids) }; queue.clear() }

    fun sendNow(l: List<Uri>) {
        val ids = targets()
        if (ids.isEmpty()) { toast("اختر جهازاً متصلاً أولاً"); return }
        l.forEach { sendFile(it, ids) }
    }

    private fun sendFile(u: Uri, ids: List<String>) {
        val pfd = held.remove(u) ?: runCatching { ctx.contentResolver.openFileDescriptor(u, "r") }.getOrNull()
        val n = heldNames.remove(u) ?: nameOf(u)
        if (pfd == null) { addMsg(Msg("e", true, "أنا", "⚠️ تعذر فتح الملف: $n")); return }
        val p = Payload.fromFile(pfd)
        val t = Transfer(p.id, n, true, "")
        t.targets.addAll(ids)
        t.toNames = ids.joinToString("، ") { peerName(it) }
        transfers.add(t)
        client.sendPayload(ids, Payload.fromBytes("F|${p.id}|${pfd.statSize}|$n".toByteArray()))
        client.sendPayload(ids, p)
    }

    fun cancel(t: Transfer) {
        client.cancelPayload(t.id); transfers.remove(t); files.remove(t.id)
        addMsg(Msg("e", t.mine, if (t.mine) "أنا" else peerName(t.peerId), "⚠️ أُلغي: ${t.name}"))
    }

    // ───────── مشاركة التطبيق نفسه ─────────
    private fun apkUri(): Uri? = runCatching {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val out = File(dir, "Nawelny.apk")
        File(ctx.applicationInfo.sourceDir).copyTo(out, overwrite = true)
        FileProvider.getUriForFile(ctx, "com.nawelny.app.files", out)
    }.getOrNull()

    private fun splitWarning() {
        if (!ctx.applicationInfo.splitSourceDirs.isNullOrEmpty())
            toast("هذه نسخة مثبّتة من متجر (Split APK) وقد لا تعمل وحدها على جهاز آخر")
    }

    /** يفتح قائمة المشاركة: بلوتوث، واتساب، Quick Share، أي تطبيق. */
    fun shareApp() {
        val u = apkUri() ?: run { toast("تعذر تجهيز ملف التطبيق"); return }
        splitWarning()
        val i = Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive")
            .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri("", u)
        ctx.startActivity(Intent.createChooser(i, "مشاركة تطبيق ناولني").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun sendAppToPeers() {
        val u = apkUri() ?: run { toast("تعذر تجهيز ملف التطبيق"); return }
        splitWarning()
        sendNow(listOf(u))
    }

    // ───────── فتح / نسخ / تثبيت ─────────
    fun open(link: String) {
        val uri = Uri.parse(link)
        val mime = ctx.contentResolver.getType(uri) ?: "*/*"
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { toast("لا يوجد تطبيق لفتح هذا الملف") }
    }

    fun openLink(link: String) {
        val uri = Uri.parse(link)
        if (uri.scheme != "http" && uri.scheme != "https") return
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { toast("لا يوجد متصفح لفتح الرابط") }
    }

    fun copy(text: String) {
        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("ناولني", text))
        Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
    }

    fun install(link: String) {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            toast("اسمح لـ ناولني بتثبيت التطبيقات ثم اضغط تثبيت مرة أخرى")
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(link), "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { toast("تعذر بدء التثبيت") }
    }

    // ───────── المكالمات ─────────
    private fun sendCtl(id: String, c: String) { client.sendPayload(id, Payload.fromBytes("C|$c".toByteArray())) }
    private fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun callSelected() {
        val ids = targets().filter { it !in callPeers && it !in calling }
        if (ids.isEmpty()) { toast("اختر جهازاً متصلاً أولاً"); return }
        ids.forEach { sendCtl(it, "ring"); calling.add(it) }
    }

    fun acceptCall() {
        val id = ringing ?: return
        ringing = null
        sendCtl(id, "acc")
        beginCall(id)
    }

    fun declineCall() { ringing?.let { sendCtl(it, "dec") }; ringing = null }

    private fun beginCall(id: String) {
        calling.remove(id)
        if (!hasMic()) { sendCtl(id, "dec"); toast("إذن الميكروفون مطلوب للمكالمات"); return }
        val first = !voice.active
        if (id !in callPeers) callPeers.add(id)
        if (first) {
            startSvc(true)
            voice.muted = muted
            voice.begin()
            voice.setSpeaker(speaker)
        }
        voice.addPeer(id)
    }

    fun endCall() {
        (callPeers.toList() + calling.toList()).forEach { sendCtl(it, "end") }
        callPeers.toList().forEach { voice.removePeer(it) }
        callPeers.clear(); calling.clear()
        voice.end()
        if (connected.isNotEmpty()) startSvc(false)
    }

    private fun dropCall(id: String) {
        calling.remove(id); callPeers.remove(id); voice.removePeer(id)
        if (ringing == id) ringing = null
        if (voice.active && callPeers.isEmpty() && calling.isEmpty()) {
            voice.end()
            if (connected.isNotEmpty()) startSvc(false)
        }
    }

    private fun onCtl(id: String, c: String) {
        when (c) {
            "ring" -> {
                if (id in callPeers) return
                ringing = id
                if (!foreground) notifyUser("مكالمة واردة", peerName(id))
            }
            "acc" -> beginCall(id)
            "dec" -> { calling.remove(id); toast("${peerName(id)} لم يرد على المكالمة") }
            "end" -> dropCall(id)
        }
    }

    fun muteMic(b: Boolean) { muted = b; voice.muted = b }
    fun setSpeakerOn(b: Boolean) { speaker = b; voice.setSpeaker(b) }

    // ───────── تصنيف وحفظ الملفات الواردة ─────────
    private val docExt = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "ods", "odp", "epub")

    private fun nameOf(u: Uri): String = runCatching {
        ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }
    }.getOrNull() ?: "ملف"

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext == "apk") return "application/vnd.android.package-archive"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun kindOf(name: String, mime: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            ext == "apk" -> "apk"
            ext == "aab" -> "aab"
            mime.startsWith("image/") -> "image"
            mime.startsWith("video/") -> "video"
            mime.startsWith("audio/") -> "audio"
            ext in docExt -> "doc"
            else -> "file"
        }
    }

    private fun save(p: Payload, name: String, from: String) {
        Thread {
            val mime = mimeOf(name)
            val kind = kindOf(name, mime)
            val base = when (kind) {
                "image" -> Environment.DIRECTORY_PICTURES
                "video" -> Environment.DIRECTORY_MOVIES
                "audio" -> Environment.DIRECTORY_MUSIC
                "doc" -> Environment.DIRECTORY_DOCUMENTS
                else -> Environment.DIRECTORY_DOWNLOADS
            }
            val src = p.asFile()?.asParcelFileDescriptor()
            try {
                if (src == null) throw IllegalStateException("no file")
                val link: String
                if (Build.VERSION.SDK_INT >= 29) {
                    val collection = when (kind) {
                        "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                        "doc" -> MediaStore.Files.getContentUri("external")
                        else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    }
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.MIME_TYPE, mime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "$base/ناولني")
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val u = ctx.contentResolver.insert(collection, cv) ?: throw IllegalStateException("insert")
                    ctx.contentResolver.openOutputStream(u)!!.use { o ->
                        FileInputStream(src.fileDescriptor).use { it.copyTo(o) }
                    }
                    ctx.contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                    link = u.toString()
                } else {
                    val d = File(Environment.getExternalStoragePublicDirectory(base), "ناولني")
                    d.mkdirs()
                    var f = File(d, name)
                    var k = 1
                    while (f.exists()) {
                        f = File(d, name.substringBeforeLast('.', name) + " ($k)" +
                            (if (name.contains('.')) "." + name.substringAfterLast('.') else ""))
                        k++
                    }
                    FileOutputStream(f).use { o -> FileInputStream(src.fileDescriptor).use { it.copyTo(o) } }
                    MediaScannerConnection.scanFile(ctx, arrayOf(f.path), arrayOf(mime), null)
                    link = FileProvider.getUriForFile(ctx, "com.nawelny.app.files", f).toString()
                }
                addMsg(Msg("f", false, from, name, link, kind))
            } catch (e: Exception) {
                addMsg(Msg("e", false, from, "⚠️ تعذر حفظ: $name"))
            } finally {
                runCatching { src?.close() }
            }
        }.start()
    }
}
