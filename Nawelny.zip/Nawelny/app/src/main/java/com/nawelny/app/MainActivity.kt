package com.nawelny.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream

data class Peer(val id: String, val name: String)
data class Msg(val text: String, val mine: Boolean, val uri: String? = null)

class Transfer(val id: Long, name: String, val mine: Boolean) {
    var name by mutableStateOf(name)
    var progress by mutableStateOf(0f)
    var named by mutableStateOf(false)
    var accepted by mutableStateOf(mine)
    var size = 0L
    var completed = false
}

class Hub(private val ctx: Context) {
    private val client = Nearby.getConnectionsClient(ctx)
    private val service = "com.nawelny.app"
    private val prefs = ctx.getSharedPreferences("nawelny", Context.MODE_PRIVATE)
    var myName by mutableStateOf(prefs.getString("name", null)
        ?: ("ناولني-" + (1000..9999).random()).also { prefs.edit().putString("name", it).apply() })
    var foreground = false
    val peers = mutableStateListOf<Peer>()
    val msgs = mutableStateListOf<Msg>()
    val queue = mutableStateListOf<Uri>()
    var peer by mutableStateOf<Peer?>(null)
    var incoming by mutableStateOf<Pair<String, ConnectionInfo>?>(null)
    val transfers = mutableStateListOf<Transfer>()
    private val files = HashMap<Long, Payload>()
    private val pendingNames = HashMap<String, String>()
    private val held = HashMap<Uri, android.os.ParcelFileDescriptor>()
    private val heldNames = HashMap<Uri, String>()

    private fun safeName(n: String): String =
        File(n.replace("\\", "/")).name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_")
            .trim('.', ' ').ifBlank { "ملف" }.take(120)

    private fun histFile(p: Peer) =
        File(ctx.filesDir, "h_" + p.name.replace(Regex("[^\\p{L}\\p{N}-]"), "_") + ".txt")

    private fun addMsg(m: Msg) {
        msgs.add(m)
        peer?.let { p ->
            histFile(p).appendText((if (m.mine) "1" else "0") +
                m.text.replace("\\", "\\\\").replace("\n", "\\n") + (m.uri?.let { "\u0001$it" } ?: "") + "\n")
        }
    }

    private fun load(p: Peer) {
        msgs.clear()
        val f = histFile(p)
        if (f.exists()) f.readLines().forEach { l ->
            if (l.length > 1) {
                val parts = l.drop(1).split('\u0001', limit = 2)
                msgs.add(Msg(
                    Regex("\\\\(.)").replace(parts[0]) { if (it.groupValues[1] == "n") "\n" else it.groupValues[1] },
                    l[0] == '1', parts.getOrNull(1)))
            }
        }
    }

    private fun stopSvc() { ctx.stopService(Intent(ctx, TransferService::class.java)) }

    private val conn = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            pendingNames[id] = info.endpointName; incoming = id to info
            if (!foreground) notifyUser("طلب اتصال", "${info.endpointName} يريد الاتصال بك")
        }
        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            incoming = null
            if (r.status.isSuccess) {
                val np = Peer(id, pendingNames[id] ?: "جهاز قريب")
                peer = np
                load(np)
                runCatching { ctx.startForegroundService(Intent(ctx, TransferService::class.java)) }
                client.stopAdvertising(); client.stopDiscovery()
                flush()
            }
        }
        override fun onDisconnected(id: String) { if (peer?.id == id) { peer = null; transfers.clear(); files.clear(); stopSvc(); start() } }
    }

    private val pcb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            if (p.type == Payload.Type.BYTES) {
                val s = String(p.asBytes()!!)
                if (s.startsWith("T|")) addMsg(Msg(s.drop(2), false))
                else if (s.startsWith("F|")) {
                    val (pid, sz, n) = s.drop(2).split("|", limit = 3)
                    val pidL = pid.toLong()
                    val t = transfers.find { it.id == pidL } ?: Transfer(pidL, "ملف", false).also { transfers.add(it) }
                    t.name = safeName(n); t.size = sz.toLongOrNull() ?: 0L; t.named = true
                    if (!foreground) notifyUser("ملف وارد", t.name)
                    trySave(t)
                }
            } else if (p.type == Payload.Type.FILE) {
                files[p.id] = p
                if (transfers.none { it.id == p.id }) transfers.add(Transfer(p.id, "ملف", false))
            }
        }

        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {
            val t = transfers.find { it.id == u.payloadId } ?: return
            when (u.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS ->
                    if (u.totalBytes > 0) t.progress = u.bytesTransferred.toFloat() / u.totalBytes
                PayloadTransferUpdate.Status.SUCCESS ->
                    if (t.mine) { transfers.remove(t); addMsg(Msg("📤 تم إرسال: ${t.name}", true)) }
                    else { t.completed = true; trySave(t) }
                else -> {
                    transfers.remove(t); files.remove(t.id)
                    addMsg(Msg("⚠️ لم يكتمل: ${t.name}", t.mine))
                }
            }
        }
    }

    private fun notifyUser(title: String, text: String) = runCatching {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("req", "طلبات ناولني", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(2, Notification.Builder(ctx, "req").setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setContentIntent(pi).setAutoCancel(true).build())
    }

    private fun trySave(t: Transfer) {
        if (!t.mine && t.completed && t.named && t.accepted) {
            transfers.remove(t); files.remove(t.id)?.let { save(it, t.name) }
        }
    }

    fun acceptFile(t: Transfer) { t.accepted = true; trySave(t) }
    fun rejectFile(t: Transfer) {
        client.cancelPayload(t.id); transfers.remove(t); files.remove(t.id)
        addMsg(Msg("🚫 رفضت: ${t.name}", false))
    }

    fun rename(n: String) {
        val v = n.trim()
        if (v.length < 2 || v == myName) return
        myName = v; prefs.edit().putString("name", v).apply()
        if (peer == null) { client.stopAdvertising(); client.stopDiscovery(); start() }
    }

    fun clearHistory() {
        ctx.filesDir.listFiles { f -> f.name.startsWith("h_") }?.forEach { it.delete() }
        msgs.clear()
    }

    fun start() {
        if (peer != null) return
        peers.clear()
        val s = Strategy.P2P_CLUSTER
        client.startAdvertising(myName, service, conn, AdvertisingOptions.Builder().setStrategy(s).build())
        client.startDiscovery(service, object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(id: String, i: DiscoveredEndpointInfo) { if (peers.none { it.id == id }) peers.add(Peer(id, i.endpointName)) }
            override fun onEndpointLost(id: String) { peers.removeAll { it.id == id } }
        }, DiscoveryOptions.Builder().setStrategy(s).build())
    }

    fun connect(p: Peer) { client.requestConnection(myName, p.id, conn) }
    fun accept(id: String) { incoming = null; client.acceptConnection(id, pcb) }
    fun reject(id: String) { incoming = null; client.rejectConnection(id) }
    fun disconnect() { peer?.let { client.disconnectFromEndpoint(it.id) }; peer = null; transfers.clear(); files.clear(); stopSvc(); start() }

    fun sendText(t: String) {
        val id = peer?.id ?: return
        val b = "T|$t".toByteArray()
        if (b.size > 32000) { addMsg(Msg("⚠️ الرسالة أطول من المسموح", true)); return }
        client.sendPayload(id, Payload.fromBytes(b))
        addMsg(Msg(t, true))
    }

    fun enqueue(l: List<Uri>) {
        l.forEach { u ->
            runCatching { ctx.contentResolver.openFileDescriptor(u, "r") }.getOrNull()?.let { held[u] = it }
            heldNames[u] = nameOf(u)
        }
        queue.addAll(l)
        if (peer != null) flush()
    }

    fun flush() { queue.toList().forEach { sendFile(it) }; queue.clear() }

    fun sendFile(u: Uri) {
        val id = peer?.id ?: return
        val pfd = held.remove(u) ?: runCatching { ctx.contentResolver.openFileDescriptor(u, "r") }.getOrNull()
        val n = heldNames.remove(u) ?: nameOf(u)
        if (pfd == null) { addMsg(Msg("⚠️ تعذر فتح الملف: $n", true)); return }
        val p = Payload.fromFile(pfd)
        transfers.add(Transfer(p.id, n, true))
        client.sendPayload(id, Payload.fromBytes("F|${p.id}|${pfd.statSize}|$n".toByteArray()))
        client.sendPayload(id, p)
    }

    fun cancel(t: Transfer) {
        client.cancelPayload(t.id); transfers.remove(t); files.remove(t.id)
        addMsg(Msg("⚠️ أُلغي: ${t.name}", t.mine))
    }

    fun open(link: String) {
        val uri = Uri.parse(link)
        val mime = ctx.contentResolver.getType(uri) ?: "*/*"
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { Toast.makeText(ctx, "لا يوجد تطبيق لفتح هذا الملف", Toast.LENGTH_LONG).show() }
    }

    private fun nameOf(u: Uri): String = runCatching {
        ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }
    }.getOrNull() ?: "ملف"

    private fun save(p: Payload, name: String) {
        Thread {
            val src = p.asFile()!!.asParcelFileDescriptor()
            var link: String? = null
            val out: OutputStream? = if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/ناولني")
                }
                val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                link = u?.toString()
                u?.let { ctx.contentResolver.openOutputStream(it) }
            } else {
                val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ناولني")
                d.mkdirs()
                var f = File(d, name)
                var k = 1
                while (f.exists()) {
                    f = File(d, name.substringBeforeLast('.', name) + " ($k)" +
                        (if (name.contains('.')) "." + name.substringAfterLast('.') else ""))
                    k++
                }
                link = FileProvider.getUriForFile(ctx, "com.nawelny.app.files", f).toString()
                FileOutputStream(f)
            }
            out?.use { o -> FileInputStream(src.fileDescriptor).use { it.copyTo(o) } }
            addMsg(Msg("📥 تم استلام: $name\nاضغط للفتح", false, link))
        }.start()
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var hub: Hub
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        hub = (application as NawelnyApp).hub
        handle(intent)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF00A884))) { App(hub) }
            }
        }
    }
    override fun onStart() { super.onStart(); hub.foreground = true }
    override fun onStop() { super.onStop(); hub.foreground = false }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }

    @Suppress("DEPRECATION")
    private fun handle(i: Intent?) {
        when (i?.action) {
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { hub.enqueue(listOf(it)) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { hub.enqueue(it) }
        }
    }
}

fun fmt(b: Long) = if (b >= 1_048_576) "%.1f م.ب".format(b / 1048576.0) else "${b / 1024} ك.ب"

fun perms(): Array<String> = buildList {
    if (Build.VERSION.SDK_INT >= 31) {
        add(Manifest.permission.BLUETOOTH_ADVERTISE); add(Manifest.permission.BLUETOOTH_CONNECT); add(Manifest.permission.BLUETOOTH_SCAN)
    }
    if (Build.VERSION.SDK_INT >= 33) { add(Manifest.permission.NEARBY_WIFI_DEVICES); add(Manifest.permission.POST_NOTIFICATIONS) }
    if (Build.VERSION.SDK_INT <= 32) add(Manifest.permission.ACCESS_FINE_LOCATION)
    if (Build.VERSION.SDK_INT <= 28) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
}.toTypedArray()

@Composable
fun App(hub: Hub) {
    var ok by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        ok = r.filterKeys { it != Manifest.permission.POST_NOTIFICATIONS }.values.all { it }
        if (ok) hub.start()
    }
    LaunchedEffect(Unit) { launcher.launch(perms()) }
    hub.incoming?.let { (id, info) ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("طلب اتصال") },
            text = { Text("${info.endpointName}\nرمز التحقق: ${info.authenticationDigits}\n(يجب أن يتطابق على الجهازين)") },
            confirmButton = { TextButton({ hub.accept(id) }) { Text("قبول") } },
            dismissButton = { TextButton({ hub.reject(id) }) { Text("رفض") } }
        )
    }
    hub.transfers.firstOrNull { !it.mine && !it.accepted && it.named }?.let { t ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("ملف وارد") },
            text = { Text("${t.name}\n${fmt(t.size)}") },
            confirmButton = { TextButton({ hub.acceptFile(t) }) { Text("قبول") } },
            dismissButton = { TextButton({ hub.rejectFile(t) }) { Text("رفض") } }
        )
    }
    if (hub.peer == null) Home(hub, ok) else Chat(hub)
}

@Composable
fun Home(hub: Hub, ok: Boolean) {
    var showSettings by remember { mutableStateOf(false) }
    if (showSettings) {
        var n by remember { mutableStateOf(hub.myName) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("الإعدادات") },
            text = {
                Column {
                    OutlinedTextField(n, { if (it.length <= 20) n = it }, label = { Text("اسم جهازك") }, singleLine = true)
                    TextButton({ hub.clearHistory() }) { Text("🗑 حذف كل سجلات المحادثات") }
                }
            },
            confirmButton = { TextButton({ hub.rename(n); showSettings = false }) { Text("حفظ") } },
            dismissButton = { TextButton({ showSettings = false }) { Text("إغلاق") } }
        )
    }
    Column(Modifier.fillMaxSize().background(Color(0xFFF4FBF9)).padding(20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ناولني", Modifier.weight(1f), style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            TextButton({ showSettings = true }) { Text("⚙️ الإعدادات") }
        }
        Text("جهازك ظاهر للقريبين باسم: ${hub.myName}")
        if (hub.queue.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Card { Text("📎 ${hub.queue.size} ملف جاهز للإرسال — اختر جهازاً", Modifier.padding(16.dp)) }
        }
        Spacer(Modifier.height(20.dp))
        Text("الأجهزة القريبة", style = MaterialTheme.typography.titleMedium)
        if (!ok) Text("يلزم السماح بالأذونات ليعمل التطبيق")
        else if (hub.peers.isEmpty()) Text("جارٍ البحث… افتح ناولني على الجهاز الآخر")
        LazyColumn {
            items(hub.peers) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { hub.connect(p) }) {
                    Text("📱 ${p.name}", Modifier.padding(18.dp))
                }
            }
        }
    }
}

@Composable
fun Chat(hub: Hub) {
    var t by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { l -> l.forEach { hub.sendFile(it) } }
    Column(Modifier.fillMaxSize().background(Color(0xFFF4FBF9)).padding(12.dp)) {
        Row(Modifier.padding(top = 24.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🟢 ${hub.peer?.name}", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            TextButton({ hub.disconnect() }) { Text("قطع الاتصال") }
        }
        hub.transfers.filter { it.mine || it.accepted }.forEach { t ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text((if (t.mine) "📤 " else "📥 ") + t.name + "  " + (t.progress * 100).toInt() + "%", maxLines = 1)
                    LinearProgressIndicator(progress = { t.progress }, modifier = Modifier.fillMaxWidth())
                }
                TextButton({ hub.cancel(t) }) { Text("إلغاء") }
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(hub.msgs) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.Start else Arrangement.End) {
                    Surface(shape = RoundedCornerShape(14.dp), color = if (m.mine) Color(0xFFD9FDD3) else Color.White,
                        shadowElevation = 1.dp, modifier = Modifier.padding(4.dp).clickable(enabled = m.uri != null) { m.uri?.let { hub.open(it) } }) { Text(m.text, Modifier.padding(10.dp)) }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton({ pick.launch("*/*") }) { Text("📎") }
            OutlinedTextField(t, { if (it.length <= 5000) t = it }, Modifier.weight(1f), placeholder = { Text("اكتب رسالة") })
            Spacer(Modifier.width(6.dp))
            Button({ if (t.isNotBlank()) { hub.sendText(t.trim()); t = "" } }) { Text("إرسال") }
        }
    }
}
