package com.nawelny.app

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF2EB872)
private val CardShape = RoundedCornerShape(20.dp)
private val SectionGap = 28.dp          // المسافة بين الأقسام الكبيرة
private val InnerGap = 12.dp            // المسافة داخل الكارت

/** زر كبسولة موحّد: نفس الارتفاع والشكل لكل الأزرار الثانوية. */
@Composable
fun PillButton(
    label: String,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    enabled: Boolean = true,
    height: Dp = 48.dp,
    leading: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    val container = if (filled) Blue else MaterialTheme.colorScheme.primaryContainer
    val content = if (filled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onPrimaryContainer
    Box(
        modifier = modifier
            .height(height)
            .alpha(if (enabled) 1f else 0.5f)
            .clip(shape)
            .background(container)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (leading != null) { leading(); Spacer(Modifier.width(8.dp)) }
            Text(label, color = content, fontWeight = FontWeight.Medium, fontSize = 15.sp, maxLines = 1)
        }
    }
}

/** «إعادة البحث» بأيقونة تدور عند الضغط لتدل على أن البحث جارٍ. */
@Composable
fun SearchPill(modifier: Modifier = Modifier, onClick: () -> Unit) {
    val rot = remember { Animatable(0f) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        if (tick > 0) {
            rot.snapTo(0f)
            rot.animateTo(720f, tween(1500, easing = LinearEasing))
            rot.snapTo(0f)
        }
    }
    PillButton(
        label = "إعادة البحث", modifier = modifier,
        leading = { Icon(Icons.Filled.Refresh, null, Modifier.size(20.dp).rotate(rot.value), tint = MaterialTheme.colorScheme.onPrimaryContainer) }
    ) { tick++; onClick() }
}

/** أيقونة موجات لاسلكية متحركة (3 أقواس تنبض بالتتابع). */
@Composable
fun WaveIcon(color: Color, modifier: Modifier = Modifier.size(30.dp)) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(
        initialValue = 0f, targetValue = 4f,
        animationSpec = infiniteRepeatable(tween(1700, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    Canvas(modifier) {
        val w = size.width
        val cx = w / 2f
        val cy = size.height * 0.84f
        val sw = w * 0.09f
        drawCircle(color, radius = sw * 1.2f, center = Offset(cx, cy))
        for (i in 1..3) {
            val r = w * 0.2f * i
            val a = (1f - kotlin.math.abs(phase - i)).coerceIn(0.22f, 1f)
            drawArc(
                color = color.copy(alpha = a), startAngle = 225f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(cx - r, cy - r), size = Size(r * 2, r * 2),
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String, topGap: Dp = SectionGap) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = topGap, bottom = 10.dp))
}

// ───────────────── شاشة الاتصال (إرسال / استلام) ─────────────────
@Composable
fun ConnectScreen(hub: Hub, ok: Boolean, requestPerms: () -> Unit, title: String, onBack: () -> Unit) {
    val avail = hub.found.filter { f -> hub.connected.none { it.id == f.id } }
    val outgoing = hub.transfers.filter { it.mine }
    var codeIn by remember { mutableStateOf("") }
    var showQr by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    Column(Modifier.fillMaxSize()) {
        TopBar(title, onBack)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {

            // ── وضع الاتصال
            item {
                Text("جهازك ظاهر للقريبين باسم: ${hub.myName}")
                Spacer(Modifier.height(12.dp))
                Text("وضع الاتصال", style = MaterialTheme.typography.labelMedium, color = SubC)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                    Chip("🚀 Wi-Fi Direct", hub.connMode == 2) { hub.chooseMode(2) }
                    Chip("⚡ سريع", hub.connMode == 1) { hub.chooseMode(1) }
                    Chip("👥 عدة أجهزة", hub.connMode == 0) { hub.chooseMode(0) }
                }
                Text(when (hub.connMode) {
                    2 -> "اتصال Wi-Fi Direct مباشر بأعلى سرعة، لجهاز أو أكثر. اضغط على الجهاز، ثم يوافق الطرف الآخر على الدعوة التي تظهر على شاشته. الاتصال بالرقم/QR غير متاح في هذا الوضع. قد ينقطع الإنترنت مؤقتاً."
                    1 -> "جهاز واحد بسرعة عالية عبر Nearby. يجب أن يكون الجهاز الآخر على نفس الوضع."
                    else -> "عدة أجهزة معاً لكن بسرعة أقل. يجب أن يكون الجهاز الآخر على نفس الوضع."
                }, style = MaterialTheme.typography.bodySmall, color = SubC)
            }

            // ── الكارت 1: جهازك وحدك
            item {
                SectionTitle("جهازك", topGap = 20.dp)
                Card(Modifier.fillMaxWidth(), shape = CardShape, colors = CardDefaults.cardColors(containerColor = CardC)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("أعطِ هذا الرقم للطرف الآخر", style = MaterialTheme.typography.labelMedium, color = SubC)
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(hub.myCode, Modifier.weight(1f), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Blue)
                            PillButton("📋 نسخ", Modifier.width(104.dp)) { hub.copy(hub.myCode) }
                        }
                        Text(hub.myName, style = MaterialTheme.typography.bodyMedium, color = SubC)
                        Spacer(Modifier.height(InnerGap + 4.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PillButton(if (showQr) "إخفاء QR" else "🔳 عرض QR", Modifier.weight(1f)) { showQr = !showQr }
                            PillButton("📷 مسح QR", Modifier.weight(1f)) {
                                scanQr(ctx, { hub.connectFromQr(it) }, { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() })
                            }
                        }
                        AnimatedVisibility(showQr) {
                            Box(Modifier.fillMaxWidth().padding(top = 18.dp), contentAlignment = Alignment.Center) {
                                QrImage(hub.qrPayload(), Modifier.size(200.dp))
                            }
                        }
                    }
                }
            }

            // ── الكارت 2: الاتصال اليدوي (منفصل)
            item {
                SectionTitle("اتصال يدوي", topGap = 20.dp)
                Card(Modifier.fillMaxWidth(), shape = CardShape, colors = CardDefaults.cardColors(containerColor = CardC)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("اكتب رقم الجهاز الآخر (6 أرقام)", style = MaterialTheme.typography.labelMedium, color = SubC)
                        Spacer(Modifier.height(InnerGap))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                codeIn, { v -> if (v.length <= 6 && v.all { it.isDigit() }) codeIn = v },
                                Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(28.dp),
                                placeholder = { Text("000000") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                            PillButton("اتصال", Modifier.width(104.dp), filled = true, height = 56.dp, enabled = codeIn.length == 6) {
                                hub.connectByCode(codeIn)
                            }
                        }
                        if (hub.codeStatus.isNotEmpty()) Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(hub.codeStatus, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            TextButton({ hub.cancelCode() }) { Text("إلغاء") }
                        }
                    }
                }
            }

            // ── الأزرار الثانوية: كبسولتان متساويتان
            item {
                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SearchPill(Modifier.weight(1f)) {
                        hub.resetAsked(); requestPerms(); hub.refreshChecks(); hub.autoFix(); hub.restartSearch()
                    }
                    PillButton("🔵 استلام بلوتوث", Modifier.weight(1f)) { hub.makeDiscoverable() }
                }
                if (hub.discStatus.startsWith("فشل"))
                    Text("⚠️ فشل البحث عن الأجهزة", color = Color(0xFFD32F2F), modifier = Modifier.padding(top = 10.dp))
                if (hub.advStatus.startsWith("فشل"))
                    Text("⚠️ فشل الاتصال", color = Color(0xFFD32F2F), modifier = Modifier.padding(top = 2.dp))
                if (hub.queue.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Card(shape = CardShape) { Text("📎 ${hub.queue.size} ملف جاهز للإرسال — اتصل بجهاز وسيبدأ الإرسال تلقائياً", Modifier.padding(16.dp)) }
                }
                outgoing.forEach { TransferRow(hub, it) }
            }

            // ── الأجهزة المتصلة
            item {
                SectionTitle("الأجهزة المتصلة (${hub.connected.size})")
                if (hub.connected.isEmpty()) Text("لا يوجد", color = SubC) else TargetsBar(hub)
            }
            items(hub.connected, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = CardShape, colors = CardDefaults.cardColors(containerColor = CardC)) {
                    Row(Modifier.padding(start = 18.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🟢 ${p.name}", Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        TextButton({ hub.disconnect(p) }) { Text("قطع") }
                    }
                }
            }

            // ── الأجهزة القريبة (مسافة أوسع)
            item {
                SectionTitle("الأجهزة القريبة", topGap = 36.dp)
                if (!ok) Text("يلزم السماح بالأذونات ليعمل التطبيق")
                else if (avail.isEmpty()) Text("جارٍ البحث… افتح ناولني على الجهاز الآخر وتأكد أنه على نفس وضع الاتصال", color = SubC)
            }
            items(avail, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { hub.connectNow(p) },
                    shape = CardShape, colors = CardDefaults.cardColors(containerColor = CardC)) {
                    Row(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        WaveIcon(Green)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text("متاح وقريب — اضغط للاتصال", style = MaterialTheme.typography.bodySmall, color = SubC)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(32.dp)) }
        }
    }
}
