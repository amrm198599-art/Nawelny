package com.nawelny.app

import android.Manifest
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Patterns
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.location.LocationManagerCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

data class Peer(val id: String, val name: String, val code: String = "")

/** type: t رسالة نصية | f ملف مستلم | s ملف مُرسل | e حدث/خطأ */
data class Msg(
    val type: String, val mine: Boolean, val from: String, val text: String,
    val uri: String? = null, val kind: String? = null, val time: Long = System.currentTimeMillis()
)

class Transfer(val id: Long, name: String, val mine: Boolean, val peerId: String) {
    var name by mutableStateOf(name)
    var progress by mutableStateOf(0f)
    var named by mutableStateOf(false)
    var accepted by mutableStateOf(mine)
    var size = 0L
    var completed = false
    var temp: File? = null   // ملف مؤقت وارد عبر Wi-Fi Direct
    val targets = mutableSetOf<String>()
    var toNames = ""
}

fun iconOf(kind: String?) = when (kind) {
    "image" -> "🖼"; "video" -> "🎬"; "audio" -> "🎵"; "apk", "aab" -> "📦"; "doc" -> "📄"; else -> "📁"
}

fun placeOf(kind: String?) = when (kind) {
    "image" -> "معرض الصور"; "video" -> "معرض الفيديو"; "audio" -> "الموسيقى"; "doc" -> "المستندات"; else -> "التنزيلات"
}

fun firstLink(t: String): String? {
    val m = Patterns.WEB_URL.matcher(t)
    while (m.find()) {
        val u = m.group()
        if (u.contains("://")) return u
        if (u.startsWith("www.", ignoreCase = true) || u.contains("/")) return "https://$u"
    }
    return null
}

const val PLAY_URL = "https://play.google.com/store/apps/details?id=com.waleednawelny.app"

class Hub(private val ctx: Context) {
    private val client = Nearby.getConnectionsClient(ctx)
    private val voice = Voice(ctx) { ids, b -> sendBytes(ids, b) }
    private val service = "com.nawelny.app"
    private val prefs = ctx.getSharedPreferences("nawelny", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())

    var myName by mutableStateOf(prefs.getString("name", null)
        ?: ("ناولني-" + (1000..9999).random()).also { prefs.edit().putString("name", it).apply() })
    var foreground = false
    var soundsOn by mutableStateOf(prefs.getBoolean("sounds", true))
    fun toggleSounds(b: Boolean) { soundsOn = b; prefs.edit().putBoolean("sounds", b).apply(); if (!b) { sounds.stopRing(); sounds.stopRingback() } }
    private val sounds = Sounds(ctx) { soundsOn }
    /** 0 = عدة أجهزة (Nearby Cluster)، 1 = سريع (Nearby نقطة لنقطة)، 2 = Wi-Fi Direct مباشر. */
    var connMode by mutableStateOf(prefs.getInt("mode", if (prefs.getBoolean("fast", true)) 1 else 0))
    private val direct: Boolean get() = connMode == 2
    private fun strategy() = if (connMode == 1) Strategy.P2P_POINT_TO_POINT else Strategy.P2P_CLUSTER
    fun chooseMode(m: Int) {
        if (m == connMode) return
        connMode = m
        prefs.edit().putInt("mode", m).apply()
        runCatching { client.stopAllEndpoints() }
        wd.stop()
        connected.toList().forEach { dropPeer(it.id) }
        restartSearch()
    }

    // ───────── وسيط Wi-Fi Direct ─────────
    private val uid: String = prefs.getString("uid", null)
        ?: java.util.UUID.randomUUID().toString().take(12).also { prefs.edit().putString("uid", it).apply() }

    private val wdEvents = object : WdEvents {
        override fun identity() = Triple(uid, myName, myCode)
        override fun onPeers(list: List<Peer>) = ui { if (direct) { found.clear(); found.addAll(list) } }
        override fun onState(ok: Boolean, msg: String) = ui { discStatus = if (ok) "يعمل ✅" else "فشل ❌ $msg"; if (!ok) logEv("Wi-Fi Direct: $msg") }
        override fun onError(msg: String) = ui { logEv(msg); toast(msg) }
        override fun onConnected(id: String, name: String) = ui {
            pendingNames[id] = name
            logEv("اتصال Wi-Fi Direct مع $name")
            if (connected.none { it.id == id }) connected.add(Peer(id, name))
            if (id !in selected) selected.add(id)
            codeStatus = ""
            startSvc(voice.active)
            acquireLocks()
            flush(listOf(id))
        }
        override fun onDisconnected(id: String) = ui { logEv("انقطع الاتصال بـ ${peerName(id)}"); dropPeer(id) }
        override fun onBytes(id: String, data: ByteArray) = ui { onRemoteBytes(id, data) }
        override fun onFileProgress(id: String, fid: Long, received: Long) = ui {
            transfers.find { it.id == fid }?.let { if (it.size > 0) it.progress = (received.toFloat() / it.size).coerceAtMost(1f) }
        }
        override fun onFileDone(id: String, fid: Long, file: File) = ui {
            val t = transfers.find { it.id == fid } ?: Transfer(fid, "ملف", false, id).also { transfers.add(it) }
            t.temp = file; t.completed = true; trySave(t)
        }
        override fun onFileFailed(id: String, fid: Long) = ui {
            transfers.find { it.id == fid }?.let {
                transfers.remove(it)
                addMsg(Msg("e", false, peerName(id), "⚠️ لم يكتمل: ${it.name}"))
            }
        }
    }
    private val wd by lazy { WdTransport(ctx, wdEvents) }

    /** يرسل بايتات عبر الوسيط المختار. */
    private fun sendBytes(ids: List<String>, b: ByteArray) {
        if (ids.isEmpty()) return
        if (direct) wd.send(ids, b)
        else client.sendPayload(ids, Payload.fromBytes(b)).addOnFailureListener { logEv("فشل الإرسال: ${it.message}") }
    }

    var themeMode by mutableStateOf(prefs.getInt("theme", 0))   // 0 تلقائي، 1 فاتح، 2 داكن
    fun setTheme(i: Int) { themeMode = i; prefs.edit().putInt("theme", i).apply() }
    val version: String = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""

    /** رقم الجهاز (6 أرقام) يظهر للآخرين ليتصلوا به مباشرة. */
    val myCode: String = prefs.getString("code", null)
        ?: (100000..999999).random().toString().also { prefs.edit().putString("code", it).apply() }
    var codeStatus by mutableStateOf("")
    private var pendingCode: String? = null
    private fun advName() = "$myName#$myCode"
    private fun parseName(s: String): Pair<String, String> {
        val m = Regex("^(.*)#(\\d{6})$").find(s)
        return if (m != null) m.groupValues[1] to m.groupValues[2] else s to ""
    }

    val found = mutableStateListOf<Peer>()
    val connected = mutableStateListOf<Peer>()
    val selected = mutableStateListOf<String>()
    val msgs = mutableStateListOf<Msg>()
    val queue = mutableStateListOf<Uri>()
    val requests = mutableStateListOf<Pair<String, ConnectionInfo>>()
    val transfers = mutableStateListOf<Transfer>()

    val callPeers = mutableStateListOf<String>()
    val calling = mutableStateListOf<String>()
    var ringing by mutableStateOf<String?>(null)
    var muted by mutableStateOf(false)
    var speaker by mutableStateOf(true)
    val inCall: Boolean get() = callPeers.isNotEmpty() || calling.isNotEmpty()

    var advStatus by mutableStateOf("…")
    var discStatus by mutableStateOf("…")
    val warnings = mutableStateListOf<String>()
    private var started = false
    private val files = HashMap<Long, Payload>()
    private val pendingNames = HashMap<String, String>()
    private val outgoing = mutableSetOf<String>()
    private val retries = HashMap<String, Int>()
    private val held = HashMap<Uri, android.os.ParcelFileDescriptor>()
    private val heldNames = HashMap<Uri, String>()

    init { loadHistory() }

    private fun ui(f: () -> Unit) { if (Looper.myLooper() == Looper.getMainLooper()) f() else main.post(f) }
    private fun toast(s: String) = ui { Toast.makeText(ctx, s, Toast.LENGTH_LONG).show() }

    fun peerName(id: String): String =
        connected.find { it.id == id }?.name ?: pendingNames[id] ?: "جهاز قريب"

    private fun safeName(n: String): String =
        File(n.replace("\\", "/")).name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_")
            .trim('.', ' ').ifBlank { "ملف" }.take(120)

    // ───────── السجل ─────────
    private val histFile get() = File(ctx.filesDir, "h_room.txt")

    private fun clean(s: String) = s.replace("\u0002", "").replace("\\", "\\\\").replace("\n", "\\n")
    private fun unclean(s: String) =
        Regex("\\\\(.)").replace(s) { if (it.groupValues[1] == "n") "\n" else it.groupValues[1] }

    private fun addMsg(m: Msg) = ui {
        msgs.add(m)
        runCatching {
            histFile.appendText(listOf(m.type, if (m.mine) "1" else "0", m.time.toString(), clean(m.from),
                m.kind ?: "", m.uri ?: "", clean(m.text)).joinToString("\u0002") + "\n")
        }
    }

    private fun loadHistory() {
        val f = histFile
        if (!f.exists()) return
        runCatching {
            f.readLines().forEach { l ->
                val p = l.split('\u0002', limit = 7)
                if (p.size == 7) msgs.add(Msg(p[0], p[1] == "1", unclean(p[3]), unclean(p[6]),
                    p[5].ifBlank { null }, p[4].ifBlank { null }, p[2].toLongOrNull() ?: 0L))
            }
        }
    }

    fun clearHistory() {
        ctx.filesDir.listFiles { f -> f.name.startsWith("h_") }?.forEach { it.delete() }
        msgs.clear()
    }

    // ───────── الاتصال ─────────
    private fun startSvc(call: Boolean) {
        runCatching { ctx.startForegroundService(Intent(ctx, TransferService::class.java).putExtra("call", call)) }
    }
    private fun stopSvc() { ctx.stopService(Intent(ctx, TransferService::class.java)); releaseLocks() }

    // أقفال تُبقي الواي فاي والمعالج يعملان بأقصى أداء أثناء الاتصال (أثبت وأبعد مدى ممكن للجهاز).
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        runCatching {
            if (wifiLock == null) {
                val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                wifiLock = ctx.applicationContext.getSystemService(WifiManager::class.java).createWifiLock(mode, "nawelny:wifi")
            }
            if (wakeLock == null) wakeLock = ctx.getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nawelny:cpu")
            if (wifiLock?.isHeld == false) wifiLock?.acquire()
            if (wakeLock?.isHeld == false) wakeLock?.acquire(4 * 60 * 60 * 1000L)
        }
    }

    private fun releaseLocks() {
        runCatching { wifiLock?.takeIf { it.isHeld }?.release() }
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
    }

    private val conn = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            pendingNames[id] = parseName(info.endpointName).first
            logEv("طلب اتصال: ${pendingNames[id]}")
            if (id in outgoing) { accept(id); return }   // أنا من بدأ الاتصال فلا داعي لسؤالي
            requests.add(id to info)
            if (!foreground) notifyUser("طلب اتصال", "${pendingNames[id]} يريد الاتصال بك")
        }
        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            requests.removeAll { it.first == id }
            codeStatus = ""
            logEv("نتيجة الاتصال: ${r.status.statusCode} ${r.status.statusMessage ?: ""}")
            val mine = outgoing.remove(id)
            if (!r.status.isSuccess) {
                toast("فشل الاتصال (${r.status.statusCode})")
                if (mine && r.status.statusCode != ConnectionsStatusCodes.STATUS_CONNECTION_REJECTED)
                    found.find { it.id == id }?.let { retryConnect(it) }
            } else retries.remove(id)
            if (r.status.isSuccess) {
                if (connected.none { it.id == id }) connected.add(Peer(id, pendingNames[id] ?: "جهاز قريب"))
                if (id !in selected) selected.add(id)
                startSvc(voice.active)
                acquireLocks()
                flush(listOf(id))
            }
        }
        override fun onDisconnected(id: String) { logEv("انقطع الاتصال بـ ${peerName(id)}"); dropPeer(id) }
    }

    private fun dropPeer(id: String) {
        connected.removeAll { it.id == id }
        selected.remove(id)
        transfers.filter { !it.mine && it.peerId == id }.forEach { files.remove(it.id); transfers.remove(it) }
        transfers.filter { it.mine }.forEach { it.targets.remove(id); if (it.targets.isEmpty()) transfers.remove(it) }
        dropCall(id)
        if (connected.isEmpty()) stopSvc()
    }

    private fun okCode(e: Exception): Boolean {
        val m = e.message ?: ""
        return m.startsWith("8001") || m.startsWith("8002")
    }

    fun start() {
        if (started) return
        started = true
        advStatus = "…"; discStatus = "…"
        if (direct) {
            // Wi-Fi Direct: لا نبدأ بدون الإذن المطلوب (NEARBY_WIFI_DEVICES على 13+ أو الموقع الدقيق قبلها) لمنع SecurityException
            if (!hasWifiDirectPermission(ctx)) { started = false; advStatus = "فشل ❌ الإذن ناقص"; return }
            advStatus = "يعمل ✅"
            runCatching { wd.start() }.onFailure { started = false; advStatus = "فشل ❌ ${it.message}" }
            return
        }
        val s = strategy()
        client.startAdvertising(advName(), service, conn, AdvertisingOptions.Builder().setStrategy(s).build())
            .addOnSuccessListener { advStatus = "يعمل ✅" }
            .addOnFailureListener { advStatus = if (okCode(it)) "يعمل ✅" else "فشل ❌ ${it.message}" }
        client.startDiscovery(service, object : EndpointDiscoveryCallback() {
            override fun onEndpointFound(id: String, i: DiscoveredEndpointInfo) {
                val (n, c) = parseName(i.endpointName)
                val peer = Peer(id, n, c)
                logEv("وُجد جهاز: $n")
                found.removeAll { it.id == id }; found.add(peer)
                if (c.isNotEmpty() && c == pendingCode) {
                    pendingCode = null
                    codeStatus = "تم العثور على $n — جارٍ الاتصال…"
                    connectNow(peer)
                }
            }
            override fun onEndpointLost(id: String) { found.removeAll { it.id == id } }
        }, DiscoveryOptions.Builder().setStrategy(s).build())
            .addOnSuccessListener { discStatus = "يعمل ✅" }
            .addOnFailureListener { discStatus = if (okCode(it)) "يعمل ✅" else "فشل ❌ ${it.message}" }
    }

    fun restartSearch() {
        runCatching { client.stopAdvertising(); client.stopDiscovery() }
        wd.stop()
        found.clear(); started = false
        start()
    }

    /** يفحص الموقع والبلوتوث والواي فاي، لأن Nearby لا يعمل بدونها. */
    fun refreshChecks() {
        permTick++
        val had = warnings.isNotEmpty()
        warnings.clear()
        runCatching {
            val lm = ctx.getSystemService(LocationManager::class.java)
            if (lm != null && !LocationManagerCompat.isLocationEnabled(lm)) warnings.add("loc")
            val bt = ctx.getSystemService(BluetoothManager::class.java)?.adapter
            if (bt != null && !bt.isEnabled) warnings.add("bt")
            val wm = ctx.applicationContext.getSystemService(WifiManager::class.java)
            if (wm != null && !wm.isWifiEnabled) warnings.add("wifi")
        }
        if (started && ((had && warnings.isEmpty()) || failing())) restartSearch()
    }

    var permTick by mutableStateOf(0)

    /** سجل أحداث الاتصال لمعرفة سبب أي مشكلة. */
    val log = mutableStateListOf<String>()
    private fun logEv(s: String) = ui {
        log.add(fmtTime(System.currentTimeMillis()) + "  " + s)
        while (log.size > 8) log.removeAt(0)
    }

    /** حالة الأذونات كما يراها التطبيق نفسه. */
    @Suppress("DEPRECATION")
    fun permReport(): String {
        fun g(p: String) = if (ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED) "✅" else "❌"
        val l = mutableListOf("أندرويد ${Build.VERSION.SDK_INT}")
        l.add("موقع تقريبي ${g(Manifest.permission.ACCESS_COARSE_LOCATION)}")
        l.add("موقع دقيق ${g(Manifest.permission.ACCESS_FINE_LOCATION)}")
        if (Build.VERSION.SDK_INT >= 31) {
            l.add("بلوتوث مسح ${g(Manifest.permission.BLUETOOTH_SCAN)}")
            l.add("بلوتوث بث ${g(Manifest.permission.BLUETOOTH_ADVERTISE)}")
            l.add("بلوتوث اتصال ${g(Manifest.permission.BLUETOOTH_CONNECT)}")
        }
        if (Build.VERSION.SDK_INT >= 33) l.add("أجهزة قريبة ${g(Manifest.permission.NEARBY_WIFI_DEVICES)}")
        val lm = ctx.getSystemService(LocationManager::class.java)
        val gps = lm != null && LocationManagerCompat.isLocationEnabled(lm)
        l.add("خدمة الموقع (GPS) " + if (gps) "✅" else "❌ مغلقة")
        val mode = runCatching {
            ctx.getSystemService(AppOpsManager::class.java)
                .checkOpNoThrow(AppOpsManager.OPSTR_COARSE_LOCATION, android.os.Process.myUid(), ctx.packageName)
        }.getOrNull()
        l.add("سماح النظام للموقع: " + when (mode) {
            null -> "؟"
            AppOpsManager.MODE_ALLOWED, 4 -> "✅"
            else -> "❌ مرفوض من النظام ($mode)"
        })
        return l.joinToString(" • ")
    }

    private fun failing() = advStatus.startsWith("فشل") || discStatus.startsWith("فشل")

    /** يبدأ البحث، أو يعيده إذا كان فاشلاً (مثلاً بعد منح إذن ناقص). */
    fun ensureSearch() { if (!started) start() else if (failing()) restartSearch() }

    private val asked = mutableSetOf<String>()
    fun resetAsked() { asked.clear() }

    /** يفتح بنفسه شاشة الإعدادات المطلوبة (الموقع ثم البلوتوث ثم الواي فاي)، واحدة في كل مرة. */
    fun autoFix() {
        if (!requiredGranted(ctx)) return
        asked.retainAll(warnings.toSet())
        val next = warnings.firstOrNull { it !in asked } ?: return
        asked.add(next)
        toast(when (next) {
            "loc" -> "فعّل الموقع (GPS) ثم ارجع للتطبيق"
            "bt" -> "فعّل البلوتوث ثم ارجع للتطبيق"
            else -> "فعّل الواي فاي ثم ارجع للتطبيق"
        })
        openSettings(next)
    }

    /** يفتح صفحة أذونات التطبيق (على شاومي يفتح محرر الأذونات مباشرة). */
    fun openPermissionPage() {
        toast("اسمح بإذن «الموقع» ثم ارجع للتطبيق")
        val pkg = ctx.packageName
        val classes = listOf("com.miui.permcenter.permissions.PermissionsEditorActivity",
            "com.miui.permcenter.permissions.AppPermissionsEditorActivity")
        for (cls in classes) {
            val ok = runCatching {
                ctx.startActivity(Intent("miui.intent.action.APP_PERM_EDITOR").setClassName("com.miui.securitycenter", cls)
                    .putExtra("extra_pkgname", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }.isSuccess
            if (ok) return
        }
        openAppSettings()
    }

    fun openAppSettings() {
        runCatching {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun openSettings(kind: String) {
        val action = when (kind) {
            "loc" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "bt" -> Settings.ACTION_BLUETOOTH_SETTINGS
            else -> Settings.ACTION_WIFI_SETTINGS
        }
        runCatching { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun rename(n: String) {
        val v = n.trim()
        if (v.length < 2 || v == myName) return
        myName = v; prefs.edit().putString("name", v).apply()
        restartSearch()
    }

    fun connectByCode(raw: String) {
        if (direct) { toast("الاتصال بالرقم أو QR غير متاح في وضع Wi-Fi Direct — اختر الجهاز من القائمة"); return }
        val c = raw.mapNotNull { ch -> Character.digit(ch, 10).takeIf { it >= 0 } }.joinToString("")
        if (c.length != 6) { toast("الرقم يتكون من 6 أرقام"); return }
        if (c == myCode) { toast("هذا رقم جهازك أنت"); return }
        val p = found.find { it.code == c }
        if (p != null) {
            codeStatus = "جارٍ الاتصال بـ ${p.name}…"
            connectNow(p)
        } else {
            pendingCode = c
            codeStatus = "جارٍ البحث عن الجهاز $c… تأكد أن ناولني مفتوح عليه"
            if (!started) start()
        }
    }

    fun qrPayload() = "NAWELNY:$myCode:$myName"

    fun connectFromQr(raw: String) {
        val parts = raw.split(":")
        if (parts.size >= 2 && parts[0] == "NAWELNY") connectByCode(parts[1])
        else toast("رمز QR غير صالح لـ ناولني")
    }

    fun openSupport() {
        val ok = runCatching {
            ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$SUPPORT_EMAIL"))
                .putExtra(Intent.EXTRA_SUBJECT, "دعم تطبيق ناولني (الإصدار $version)")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.isSuccess
        if (!ok) copy(SUPPORT_EMAIL)
    }

    fun cancelCode() { pendingCode = null; codeStatus = "" }

    fun connectNow(p: Peer) {
        if (direct) {
            logEv("دعوة Wi-Fi Direct إلى ${p.name}")
            toast("بانتظار موافقة الجهاز الآخر على الدعوة…")
            wd.connectTo(p.id)
            return
        }
        retries.remove(p.id); connect(p)
    }

    private fun connect(p: Peer) {
        outgoing.add(p.id)
        client.requestConnection(advName(), p.id, conn).addOnFailureListener {
            outgoing.remove(p.id)
            logEv("فشل طلب الاتصال: ${it.message}")
            if (it.message?.startsWith("8003") == true) return@addOnFailureListener   // متصل بالفعل
            toast("تعذر الاتصال بـ ${p.name}: ${it.message}")
            retryConnect(p)
        }
    }

    /** عند تصادم طلبين متزامنين نعيد المحاولة بعد تأخير عشوائي قصير. */
    private fun retryConnect(p: Peer) {
        val n = retries[p.id] ?: 0
        if (n >= 2 || connected.any { it.id == p.id }) return
        retries[p.id] = n + 1
        logEv("إعادة محاولة الاتصال بـ ${p.name}")
        main.postDelayed({ if (connected.none { it.id == p.id }) connect(p) }, (1000L..3000L).random())
    }

    fun accept(id: String) { requests.removeAll { it.first == id }; client.acceptConnection(id, pcb).addOnFailureListener { logEv("فشل القبول: ${it.message}"); toast("فشل قبول الاتصال: ${it.message}") } }
    fun reject(id: String) { requests.removeAll { it.first == id }; client.rejectConnection(id) }
    fun disconnect(p: Peer) { if (direct) wd.disconnect(p.id) else client.disconnectFromEndpoint(p.id); dropPeer(p.id) }

    // ───────── استقبال ─────────
    private val pcb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            if (p.type == Payload.Type.BYTES) {
                val b = p.asBytes() ?: return
                onRemoteBytes(id, b)
            } else if (p.type == Payload.Type.FILE) {
                files[p.id] = p
                if (transfers.none { it.id == p.id }) transfers.add(Transfer(p.id, "ملف", false, id))
            } else if (p.type == Payload.Type.STREAM) {
                client.cancelPayload(p.id)   // بث قديم لم يعد مستخدماً
            }
        }

        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {
            val t = transfers.find { it.id == u.payloadId } ?: return
            when (u.status) {
                PayloadTransferUpdate.Status.IN_PROGRESS ->
                    if (u.totalBytes > 0) t.progress = u.bytesTransferred.toFloat() / u.totalBytes
                PayloadTransferUpdate.Status.SUCCESS ->
                    if (t.mine) { t.targets.remove(id); if (t.targets.isEmpty()) finishSent(t, true) }
                    else { t.completed = true; trySave(t) }
                else -> {
                    if (t.mine) { t.targets.remove(id); if (t.targets.isEmpty()) finishSent(t, false) }
                    else {
                        transfers.remove(t); files.remove(t.id)
                        addMsg(Msg("e", false, peerName(t.peerId), "⚠️ لم يكتمل: ${t.name}"))
                    }
                }
            }
        }
    }

    private fun finishSent(t: Transfer, ok: Boolean) {
        transfers.remove(t)
        val k = kindOf(t.name, mimeOf(t.name))
        addMsg(if (ok) Msg("s", true, "أنا", "${t.name}  ←  ${t.toNames}", null, k)
               else Msg("e", true, "أنا", "⚠️ لم يكتمل إرسال: ${t.name}"))
    }

    private fun onRemoteBytes(id: String, b: ByteArray) {
        if (b.isNotEmpty() && b[0] == 1.toByte()) {
            if (id in callPeers || id in calling) voice.playFrame(id, b)   // إطار صوت
        } else onBytes(id, String(b))
    }

    private fun onBytes(id: String, s: String) {
        val from = peerName(id)
        when {
            s.startsWith("T|") -> {
                val text = s.drop(2)
                addMsg(Msg("t", false, from, text))
                if (foreground) sounds.message() else notifyUser("رسالة من $from", text.take(80), "msgs")
            }
            s.startsWith("F|") -> runCatching {
                val (pid, sz, n) = s.drop(2).split("|", limit = 3)
                val pidL = pid.toLong()
                val t = transfers.find { it.id == pidL } ?: Transfer(pidL, "ملف", false, id).also { transfers.add(it) }
                t.name = safeName(n); t.size = sz.toLongOrNull() ?: 0L; t.named = true
                if (!foreground) notifyUser("ملف وارد من $from", t.name)
                trySave(t)
            }
            s.startsWith("X|") -> wd.cancelFile(s.drop(2).toLongOrNull() ?: 0L, id)   // الطرف الآخر رفض/ألغى ملفاً
            s.startsWith("C|") -> onCtl(id, s.drop(2))
        }
    }

    private fun notifyUser(title: String, text: String, channel: String = "req") = runCatching {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val ch = when (channel) {
            "msgs" -> NotificationChannel("msgs", "الرسائل", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(Uri.parse("android.resource://${ctx.packageName}/${R.raw.msg_tone}"),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            }
            "calls" -> NotificationChannel("calls", "المكالمات", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null); enableVibration(false)   // النغمة تُشغَّل من التطبيق نفسه
            }
            else -> NotificationChannel("req", "تنبيهات ناولني", NotificationManager.IMPORTANCE_HIGH)
        }
        nm.createNotificationChannel(ch)
        val pi = PendingIntent.getActivity(ctx, 1, Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)
        val nid = when (channel) { "msgs" -> 3; "calls" -> 4; else -> 2 }
        nm.notify(nid, Notification.Builder(ctx, channel).setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setContentIntent(pi).setAutoCancel(true).build())
    }

    private fun trySave(t: Transfer) {
        if (!t.mine && t.completed && t.named && t.accepted) {
            transfers.remove(t)
            val tmp = t.temp
            if (tmp != null) saveTemp(tmp, t.name, peerName(t.peerId))
            else files.remove(t.id)?.let { save(it, t.name, peerName(t.peerId)) }
        }
    }

    fun acceptFile(t: Transfer) { t.accepted = true; trySave(t) }
    fun rejectFile(t: Transfer) {
        dropTransfer(t)
        transfers.remove(t); files.remove(t.id)
        addMsg(Msg("e", false, peerName(t.peerId), "🚫 رفضت: ${t.name}"))
    }

    // ───────── إرسال ─────────
    fun targets(): List<String> = selected.filter { id -> connected.any { it.id == id } }

    fun sendText(t: String) {
        val ids = targets()
        if (ids.isEmpty()) { toast("اختر جهازاً متصلاً أولاً"); return }
        val b = "T|$t".toByteArray()
        if (b.size > 32000) { toast("الرسالة أطول من المسموح"); return }
        sendBytes(ids, b)
        addMsg(Msg("t", true, "أنا", t))
    }

    /** ملفات واردة من «مشاركة» خارج التطبيق: تنتظر حتى يتصل جهاز. */
    fun enqueue(l: List<Uri>) {
        l.forEach { u ->
            runCatching { ctx.contentResolver.openFileDescriptor(u, "r") }.getOrNull()?.let { held[u] = it }
            heldNames[u] = nameOf(u)
        }
        queue.addAll(l)
        val ids = targets()
        if (ids.isNotEmpty()) flush(ids)
    }

    fun flush(ids: List<String>) { queue.toList().forEach { sendFile(it, ids) }; queue.clear() }

    fun sendNow(l: List<Uri>) {
        val ids = targets()
        if (ids.isEmpty()) { toast("اختر جهازاً متصلاً أولاً"); return }
        l.forEach { sendFile(it, ids) }
    }

    private fun sendFile(u: Uri, ids: List<String>) {
        val pfd = held.remove(u) ?: runCatching { ctx.contentResolver.openFileDescriptor(u, "r") }.getOrNull()
        val n = heldNames.remove(u) ?: nameOf(u)
        if (pfd == null) { addMsg(Msg("e", true, "أنا", "⚠️ تعذر فتح الملف: $n")); return }
        if (direct) { sendFileDirect(pfd, n, ids); return }
        val p = Payload.fromFile(pfd)
        val t = Transfer(p.id, n, true, "")
        t.targets.addAll(ids)
        t.toNames = ids.joinToString("، ") { peerName(it) }
        transfers.add(t)
        client.sendPayload(ids, Payload.fromBytes("F|${p.id}|${pfd.statSize}|$n".toByteArray()))
        client.sendPayload(ids, p).addOnFailureListener { logEv("فشل إرسال الملف: ${it.message}") }
    }

    /** يلغي نقل ملف عبر الوسيط المناسب. */
    private fun dropTransfer(t: Transfer) {
        if (direct) {
            if (t.mine) wd.cancelFile(t.id)
            else { wd.dropIncoming(t.peerId, t.id); sendBytes(listOf(t.peerId), "X|${t.id}".toByteArray()); t.temp?.delete() }
        } else client.cancelPayload(t.id)
    }

    private fun sendFileDirect(pfd: android.os.ParcelFileDescriptor, n: String, ids: List<String>) {
        val fid = java.util.Random().nextLong()
        val size = pfd.statSize
        val t = Transfer(fid, n, true, "")
        t.targets.addAll(ids)
        t.toNames = ids.joinToString("، ") { peerName(it) }
        transfers.add(t)
        wd.sendFile(ids, fid, "F|$fid|$size|$n".toByteArray(), pfd,
            { sent -> ui { if (size > 0) t.progress = (sent.toFloat() / size).coerceAtMost(1f) } },
            { ok, failed -> ui { if (t in transfers) finishSent(t, ok.isNotEmpty() && failed.isEmpty()) } })
    }

    fun cancel(t: Transfer) {
        dropTransfer(t)
        transfers.remove(t); files.remove(t.id)
        addMsg(Msg("e", t.mine, if (t.mine) "أنا" else peerName(t.peerId), "⚠️ أُلغي: ${t.name}"))
    }

    // ───────── البلوتوث ─────────
    private fun btShare(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        i.type = "*/*"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        val clip = ClipData.newRawUri("", uris[0])
        uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
        i.clipData = clip
        val ok = runCatching { ctx.startActivity(Intent(i).setPackage("com.android.bluetooth")) }.isSuccess
        if (!ok) ctx.startActivity(Intent.createChooser(i, "إرسال عبر البلوتوث").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** يرسل الملفات المحددة عبر مشاركة البلوتوث الخاصة بالنظام. */
    fun pickBluetooth() {
        val items = picks.toList()
        Thread {
            val uris = items.mapNotNull { m -> if (m.kind == "app") copyApk(m) else m.uri }
            ui { btShare(uris) }
        }.start()
    }

    fun shareAppBluetooth() {
        val u = apkUri() ?: run { toast("تعذر تجهيز ملف التطبيق"); return }
        splitWarning()
        btShare(listOf(u))
    }

    /** يجعل الجهاز ظاهراً للبلوتوث لاستقبال الملفات من هاتف آخر. */
    fun makeDiscoverable() {
        runCatching {
            ctx.startActivity(Intent(android.bluetooth.BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                .putExtra(android.bluetooth.BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { openSettings("bt") }
    }

    // ───────── تحديد الملفات للإرسال ─────────
    val picks = mutableStateListOf<MediaItem>()

    fun togglePick(m: MediaItem) {
        val i = picks.indexOfFirst { it.key == m.key }
        if (i >= 0) picks.removeAt(i) else picks.add(m)
    }

    private fun sizeOf(u: Uri): Long = runCatching {
        ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getLong(c.getColumnIndexOrThrow(OpenableColumns.SIZE)) else 0L
        }
    }.getOrNull() ?: 0L

    /** ملفات اختارها المستخدم من منتقي النظام. */
    fun addPicked(l: List<Uri>) {
        l.forEach { u ->
            val k = u.toString()
            if (picks.none { it.key == k }) picks.add(MediaItem(k, 0, nameOf(u), sizeOf(u), u, "file"))
        }
    }

    private fun copyApk(m: MediaItem): Uri? = runCatching {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val out = File(dir, safeName(m.name).ifBlank { m.pkg ?: "app" } + ".apk")
        File(m.apkPath!!).copyTo(out, overwrite = true)
        FileProvider.getUriForFile(ctx, ctx.packageName + ".files", out)
    }.getOrNull()

    /** يجهّز المحدد للإرسال: يُرسل فوراً للأجهزة المتصلة، أو ينتظر حتى يتصل جهاز. */
    fun stagePicks() {
        val items = picks.toList()
        picks.clear()
        Thread {
            val uris = items.mapNotNull { m -> if (m.kind == "app") copyApk(m) else m.uri }
            ui { enqueue(uris) }
        }.start()
    }

    // ───────── مشاركة التطبيق نفسه ─────────
    private fun apkUri(): Uri? = runCatching {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val out = File(dir, "Nawelny.apk")
        File(ctx.applicationInfo.sourceDir).copyTo(out, overwrite = true)
        FileProvider.getUriForFile(ctx, ctx.packageName + ".files", out)
    }.getOrNull()

    private fun splitWarning() {
        if (!ctx.applicationInfo.splitSourceDirs.isNullOrEmpty())
            toast("هذه نسخة مثبّتة من متجر (Split APK) وقد لا تعمل وحدها على جهاز آخر")
    }

    /** مشاركة التطبيق: رابط التطبيق على Google Play (بدل ملف APK) عبر أي تطبيق: واتساب، رسائل، بلوتوث… */
    fun shareApp() {
        val text = "حمّل تطبيق ناولني لنقل الملفات بين الهواتف بدون إنترنت:\n$PLAY_URL"
        val i = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_SUBJECT, "ناولني").putExtra(Intent.EXTRA_TEXT, text)
        runCatching { ctx.startActivity(Intent.createChooser(i, "مشاركة تطبيق ناولني").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { toast("تعذر فتح قائمة المشاركة") }
    }

    /** مشاركة ملف APK نفسه (للحالات بدون إنترنت). */
    fun shareApkFile() {
        val u = apkUri() ?: run { toast("تعذر تجهيز ملف التطبيق"); return }
        splitWarning()
        val i = Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive")
            .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri("", u)
        ctx.startActivity(Intent.createChooser(i, "مشاركة تطبيق ناولني").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun sendAppToPeers() {
        val u = apkUri() ?: run { toast("تعذر تجهيز ملف التطبيق"); return }
        splitWarning()
        sendNow(listOf(u))
    }

    // ───────── فتح / نسخ / تثبيت ─────────
    fun open(link: String) {
        val uri = Uri.parse(link)
        val mime = ctx.contentResolver.getType(uri) ?: "*/*"
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { toast("لا يوجد تطبيق لفتح هذا الملف") }
    }

    fun openLink(link: String) {
        val uri = Uri.parse(link)
        if (uri.scheme != "http" && uri.scheme != "https") return
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { toast("لا يوجد متصفح لفتح الرابط") }
    }

    fun copy(text: String) {
        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("ناولني", text))
        Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
    }

    fun install(link: String) {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            toast("اسمح لـ ناولني بتثبيت التطبيقات ثم اضغط تثبيت مرة أخرى")
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(link), "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { toast("تعذر بدء التثبيت") }
    }

    // ───────── المكالمات ─────────
    private fun sendCtl(id: String, c: String) { sendBytes(listOf(id), "C|$c".toByteArray()) }
    private fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun syncSounds() {
        if (ringing != null) sounds.startRing() else sounds.stopRing()
        if (calling.isNotEmpty() && callPeers.isEmpty()) sounds.startRingback() else sounds.stopRingback()
    }

    fun callSelected() {
        val ids = targets().filter { it !in callPeers && it !in calling }
        if (ids.isEmpty()) { toast("اختر جهازاً متصلاً أولاً"); return }
        ids.forEach { sendCtl(it, "ring"); calling.add(it) }
        syncSounds()
    }

    fun acceptCall() {
        val id = ringing ?: return
        ringing = null
        syncSounds()
        sendCtl(id, "acc")
        beginCall(id)
    }

    fun declineCall() { ringing?.let { sendCtl(it, "dec") }; ringing = null; syncSounds() }

    private fun beginCall(id: String) {
        calling.remove(id)
        syncSounds()
        if (!hasMic()) { sendCtl(id, "dec"); toast("إذن الميكروفون مطلوب للمكالمات"); return }
        val first = !voice.active
        if (id !in callPeers) callPeers.add(id)
        syncSounds()
        if (first) {
            startSvc(true)
            voice.muted = muted
            voice.begin()
            voice.setSpeaker(speaker)
        }
        voice.addPeer(id)
    }

    fun endCall() {
        (callPeers.toList() + calling.toList()).forEach { sendCtl(it, "end") }
        callPeers.toList().forEach { voice.removePeer(it) }
        callPeers.clear(); calling.clear()
        syncSounds()
        voice.end()
        if (connected.isNotEmpty()) startSvc(false)
    }

    private fun dropCall(id: String) {
        calling.remove(id); callPeers.remove(id); voice.removePeer(id)
        if (ringing == id) ringing = null
        syncSounds()
        if (voice.active && callPeers.isEmpty() && calling.isEmpty()) {
            voice.end()
            if (connected.isNotEmpty()) startSvc(false)
        }
    }

    private fun onCtl(id: String, c: String) {
        when (c) {
            "ring" -> {
                if (id in callPeers) return
                ringing = id
                syncSounds()
                if (!foreground) notifyUser("مكالمة واردة", peerName(id), "calls")
            }
            "acc" -> beginCall(id)
            "dec" -> { calling.remove(id); syncSounds(); toast("${peerName(id)} لم يرد على المكالمة") }
            "end" -> dropCall(id)
        }
    }

    fun muteMic(b: Boolean) { muted = b; voice.muted = b }
    fun setSpeakerOn(b: Boolean) { speaker = b; voice.setSpeaker(b) }

    // ───────── تصنيف وحفظ الملفات الواردة ─────────
    private val docExt = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "ods", "odp", "epub")

    private fun nameOf(u: Uri): String = runCatching {
        ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }
    }.getOrNull() ?: "ملف"

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext == "apk") return "application/vnd.android.package-archive"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun kindOf(name: String, mime: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            ext == "apk" -> "apk"
            ext == "aab" -> "aab"
            mime.startsWith("image/") -> "image"
            mime.startsWith("video/") -> "video"
            mime.startsWith("audio/") -> "audio"
            ext in docExt -> "doc"
            else -> "file"
        }
    }

    private fun save(p: Payload, name: String, from: String) = save(p.asFile()?.asParcelFileDescriptor(), name, from, null)

    private fun saveTemp(tmp: File, name: String, from: String) {
        val pfd = runCatching { android.os.ParcelFileDescriptor.open(tmp, android.os.ParcelFileDescriptor.MODE_READ_ONLY) }.getOrNull()
        save(pfd, name, from) { tmp.delete() }
    }

    private fun save(src: android.os.ParcelFileDescriptor?, name: String, from: String, after: (() -> Unit)?) {
        Thread {
            val mime = mimeOf(name)
            val kind = kindOf(name, mime)
            val base = when (kind) {
                "image" -> Environment.DIRECTORY_PICTURES
                "video" -> Environment.DIRECTORY_MOVIES
                "audio" -> Environment.DIRECTORY_MUSIC
                "doc" -> Environment.DIRECTORY_DOCUMENTS
                else -> Environment.DIRECTORY_DOWNLOADS
            }
            try {
                if (src == null) throw IllegalStateException("no file")
                val link: String
                if (Build.VERSION.SDK_INT >= 29) {
                    val collection = when (kind) {
                        "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                        "doc" -> MediaStore.Files.getContentUri("external")
                        else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    }
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.MIME_TYPE, mime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "$base/ناولني")
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val u = ctx.contentResolver.insert(collection, cv) ?: throw IllegalStateException("insert")
                    ctx.contentResolver.openOutputStream(u)!!.use { o ->
                        FileInputStream(src.fileDescriptor).use { it.copyTo(o) }
                    }
                    ctx.contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                    link = u.toString()
                } else {
                    val d = File(Environment.getExternalStoragePublicDirectory(base), "ناولني")
                    d.mkdirs()
                    var f = File(d, name)
                    var k = 1
                    while (f.exists()) {
                        f = File(d, name.substringBeforeLast('.', name) + " ($k)" +
                            (if (name.contains('.')) "." + name.substringAfterLast('.') else ""))
                        k++
                    }
                    FileOutputStream(f).use { o -> FileInputStream(src.fileDescriptor).use { it.copyTo(o) } }
                    MediaScannerConnection.scanFile(ctx, arrayOf(f.path), arrayOf(mime), null)
                    link = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f).toString()
                }
                addMsg(Msg("f", false, from, name, link, kind))
            } catch (e: Exception) {
                addMsg(Msg("e", false, from, "⚠️ تعذر حفظ: $name"))
            } finally {
                runCatching { src?.close() }
                after?.invoke()
            }
        }.start()
    }
}
