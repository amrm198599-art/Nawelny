package com.nawelny.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat

@Suppress("DEPRECATION")
class MainActivity : ComponentActivity() {
    private lateinit var hub: Hub
    override fun onCreate(b: Bundle?) {
        // Edge-to-Edge: يجب قبل super.onCreate. إجباري على أندرويد 15 ويعمل على 8.0+ عبر androidx.
        enableEdgeToEdge()
        super.onCreate(b)
        hub = (application as NawelnyApp).hub
        Ads.init(application)
        handle(intent)
        setContent {
            val dark = when (hub.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme) {
                    val bg = MaterialTheme.colorScheme.background
                    // أشرطة النظام شفافة، ولون أيقوناتها يتبع المظهر الذي يختاره المستخدم (وليس مظهر النظام فقط)
                    SideEffect {
                        runCatching {
                            enableEdgeToEdge(
                                statusBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark },
                                navigationBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark }
                            )
                        }
                    }
                    Surface(Modifier.fillMaxSize(), color = bg) {
                        // safeDrawingPadding = شريط الحالة + شريط التنقل + الحواف المقطوعة (Notch) + لوحة المفاتيح
                        Box(Modifier.fillMaxSize().safeDrawingPadding()) { App(hub) }
                    }
                }
            }
        }
    }
    override fun onStart() {
        super.onStart(); hub.foreground = true; hub.refreshChecks()
        if (requiredGranted(this)) { hub.autoFix(); hub.ensureSearch() }
    }
    override fun onStop() { super.onStop(); hub.foreground = false }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }

    @Suppress("DEPRECATION")
    private fun handle(i: Intent?) {
        when (i?.action) {
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { hub.enqueue(listOf(it)) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { hub.enqueue(it) }
        }
    }
}

fun fmt(b: Long) = if (b >= 1_048_576) "%.1f م.ب".format(b / 1048576.0) else "${b / 1024} ك.ب"

fun perms(): Array<String> = buildList {
    if (Build.VERSION.SDK_INT >= 31) {
        add(Manifest.permission.BLUETOOTH_ADVERTISE); add(Manifest.permission.BLUETOOTH_CONNECT); add(Manifest.permission.BLUETOOTH_SCAN)
    }
    if (Build.VERSION.SDK_INT >= 33) { add(Manifest.permission.NEARBY_WIFI_DEVICES); add(Manifest.permission.POST_NOTIFICATIONS) }
    add(Manifest.permission.ACCESS_COARSE_LOCATION); add(Manifest.permission.ACCESS_FINE_LOCATION)
    if (Build.VERSION.SDK_INT <= 28) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    add(Manifest.permission.RECORD_AUDIO)
}.toTypedArray()

fun requiredGranted(ctx: Context): Boolean = perms().filter { it !in optionalPerms }
    .all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

private val optionalPerms: Set<String> = buildSet {
    add(Manifest.permission.POST_NOTIFICATIONS); add(Manifest.permission.RECORD_AUDIO)
    // أندرويد 13+: NEARBY_WIFI_DEVICES يغني عن الموقع (neverForLocation). أقل من 13: الموقع الدقيق إلزامي لـ Wi-Fi Direct.
    if (Build.VERSION.SDK_INT >= 33) { add(Manifest.permission.ACCESS_FINE_LOCATION); add(Manifest.permission.ACCESS_COARSE_LOCATION) }
}

@Composable
fun App(hub: Hub) {
    val ctx = LocalContext.current
    var reqTick by remember { mutableStateOf(0) }
    val ok = remember(hub.permTick, reqTick) { requiredGranted(ctx) }
    var tab by remember { mutableStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        reqTick++
        if (requiredGranted(ctx)) { hub.refreshChecks(); hub.autoFix(); hub.ensureSearch() }
        else hub.openPermissionPage()   // يفتح صفحة أذونات التطبيق تلقائياً
    }
    // كل طلب إذن محمي: لا انهيار إن لم توجد واجهة طلب الأذونات أو كانت الشاشة قيد الإغلاق
    val safeRequest = { runCatching { launcher.launch(perms()) }; Unit }
    LaunchedEffect(Unit) { safeRequest() }

    var pendingMic by remember { mutableStateOf<(() -> Unit)?>(null) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingMic?.invoke()
        else Toast.makeText(ctx, "إذن الميكروفون مطلوب للمكالمات", Toast.LENGTH_LONG).show()
        pendingMic = null
    }
    val withMic: (() -> Unit) -> Unit = { action ->
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) action()
        else { pendingMic = action; micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
    }

    hub.requests.firstOrNull()?.let { (id, info) ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("طلب اتصال") },
            text = { Text("${hub.peerName(id)}\nرمز التحقق: ${info.authenticationDigits}\n(يجب أن يتطابق على الجهازين)") },
            confirmButton = { TextButton({ hub.accept(id) }) { Text("قبول") } },
            dismissButton = { TextButton({ hub.reject(id) }) { Text("رفض") } }
        )
    }
    hub.transfers.firstOrNull { !it.mine && !it.accepted && it.named }?.let { t ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("ملف وارد من ${hub.peerName(t.peerId)}") },
            text = { Text("${iconOf(null)} ${t.name}\n${fmt(t.size)}") },
            confirmButton = { TextButton({ hub.acceptFile(t) }) { Text("قبول") } },
            dismissButton = { TextButton({ hub.rejectFile(t) }) { Text("رفض") } }
        )
    }
    hub.ringing?.let { id ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("📞 مكالمة واردة") },
            text = { Text(hub.peerName(id)) },
            confirmButton = { TextButton({ withMic { hub.acceptCall() } }) { Text("رد") } },
            dismissButton = { TextButton({ hub.declineCall() }) { Text("رفض") } }
        )
    }

    var screen by remember { mutableStateOf("home") }
    val act = ctx.findActivity()
    // الرجوع من شاشة اتصال: إعلان بيني بشروط (كل 3 مرات، فاصل دقيقتين، وبدون نقل أو مكالمة جارية)
    val adExit = { Ads.onScreenExit(act, hub.transfers.isEmpty() && !hub.inCall) }
    BackHandler(enabled = screen != "home") {
        if (screen == "send" || screen == "recv") adExit()
        screen = if (screen == "send") "pick" else "home"
    }
    val reqPerms = safeRequest
    val bannerScreens = setOf("home", "recv", "files")
    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (screen) {
                "home" -> HomeScreen(hub) { screen = it }
                "pick" -> PickScreen(hub, { screen = "home" }) { hub.stagePicks(); screen = "send" }
                "send" -> ConnectScreen(hub, ok, reqPerms, "إرسال") { adExit(); screen = "home" }
                "recv" -> ConnectScreen(hub, ok, reqPerms, "استلام") { adExit(); screen = "home" }
                "files" -> FilesScreen(hub) { screen = "home" }
                "about" -> InfoScreen("عن ناولني", ABOUT, hub) { screen = "home" }
                "privacy" -> InfoScreen("سياسة الخصوصية", PRIVACY, hub) { screen = "home" }
                "chat" -> Column(Modifier.fillMaxSize()) { TopBar("رسائل") { screen = "home" }; ChatTab(hub, Modifier.weight(1f)) }
                else -> Column(Modifier.fillMaxSize()) { TopBar("مكالمات") { screen = "home" }; CallsTab(hub, withMic, Modifier.weight(1f)) }
            }
        }
        if (screen in bannerScreens && Ads.enabled()) BannerAd()
    }
}
