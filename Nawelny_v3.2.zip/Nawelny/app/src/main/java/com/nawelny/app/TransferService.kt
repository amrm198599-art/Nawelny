package com.nawelny.app

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build

class TransferService : Service() {
    override fun onBind(i: Intent?) = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val call = i?.getBooleanExtra("call", false) == true
        val ch = "nawelny"
        runCatching {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(ch, "ناولني", NotificationManager.IMPORTANCE_LOW))
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle(if (call) "مكالمة صوتية جارية" else "ناولني متصل")
            .setContentText(if (call) "اضغط للعودة للمكالمة" else "التبادل مستمر مع الأجهزة القريبة")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(pi).setOngoing(true).build()

        // أندرويد 14+ يرفض نوع الخدمة إن لم يكن الإذن الموافق ممنوحاً (SecurityException) فنتحقق قبل الطلب،
        // وإن فشل كل شيء نوقف الخدمة بهدوء بدل الانهيار.
        val started = runCatching {
            if (Build.VERSION.SDK_INT >= 29) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (call && mic && Build.VERSION.SDK_INT >= 30) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                startForeground(1, n, type)
            } else startForeground(1, n)
        }.recoverCatching {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(1, n)
        }.isSuccess
        if (!started) { stopSelf(); return START_NOT_STICKY }
        return START_NOT_STICKY
    }
}
