plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
// رقم الإصدار يتغير تلقائياً مع كل Run في GitHub Actions (GITHUB_RUN_NUMBER يزيد وحده كل مرة)
val runNumber: Int? = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
val versionCodeBase = 100   // يضمن أن الرقم أكبر من أي إصدار رُفع سابقاً
val versionBase = "3.2"

android {
    namespace = "com.nawelny.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.waleednawelny.app"
        minSdk = 26
        targetSdk = 36
        versionCode = if (runNumber != null) versionCodeBase + runNumber else 18
        versionName = if (runNumber != null) "$versionBase.$runNumber" else versionBase
    }
    signingConfigs {
        create("release") {
            val ks = System.getenv("KEYSTORE_FILE")
            if (ks != null) {
                storeFile = file(ks)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            } else {
                storeFile = file("nawelny.jks")
                storePassword = "nawelny123"
                keyAlias = "nawelny"
                keyPassword = "nawelny123"
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    buildFeatures { compose = true; buildConfig = true }
    lint { abortOnError = false; checkReleaseBuilds = false }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
    implementation("com.google.zxing:core:3.5.3")
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
