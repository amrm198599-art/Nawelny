package com.nawelny.app

import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.lazy.grid.items as gridItems

val Blue: Color
    @Composable get() = MaterialTheme.colorScheme.primary
val Bg: Color
    @Composable get() = MaterialTheme.colorScheme.background
val CardC: Color
    @Composable get() = MaterialTheme.colorScheme.surface
val SubC: Color
    @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant
val TextC: Color
    @Composable get() = MaterialTheme.colorScheme.onSurface

val LightScheme = lightColorScheme(
    primary = Color(0xFF2F6FDB), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE6F7), onPrimaryContainer = Color(0xFF1B2A41),
    background = Color(0xFFF3EDE0), onBackground = Color(0xFF2E2A24),
    surface = Color(0xFFFBF7EC), onSurface = Color(0xFF2E2A24),
    surfaceVariant = Color(0xFFEAE3D3), onSurfaceVariant = Color(0xFF766E60),
    outline = Color(0xFFCBC2AF)
)
val DarkScheme = darkColorScheme(
    primary = Color(0xFF6AA6FF), onPrimary = Color(0xFF06223F),
    primaryContainer = Color(0xFF27456E), onPrimaryContainer = Color(0xFFDCE8FF),
    background = Color(0xFF14181F), onBackground = Color(0xFFE8E6E1),
    surface = Color(0xFF1D232C), onSurface = Color(0xFFE8E6E1),
    surfaceVariant = Color(0xFF283040), onSurfaceVariant = Color(0xFF9AA3AF),
    outline = Color(0xFF3A4350)
)

fun fmtTime(t: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))

// ───────────────── عناصر مشتركة ─────────────────
@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("→", fontSize = 28.sp, modifier = Modifier.clickable(onClick = onBack).padding(8.dp))
        Spacer(Modifier.width(8.dp))
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Chip(label: String, on: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (on) Blue else CardC,
        shadowElevation = 1.dp,
        modifier = Modifier.padding(horizontal = 3.dp).clickable(onClick = onClick)
    ) {
        Text(label, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = if (on) MaterialTheme.colorScheme.onPrimary else TextC, maxLines = 1)
    }
}

/** اختيار الأجهزة المستهدفة (الكل أو أجهزة محددة). */
@Composable
fun TargetsBar(hub: Hub) {
    if (hub.connected.isEmpty()) {
        Text("لا توجد أجهزة متصلة", color = SubC, modifier = Modifier.padding(vertical = 8.dp))
    } else {
        val all = hub.connected.all { it.id in hub.selected }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("إلى: ")
            Chip("الكل", all) {
                if (all) hub.selected.clear()
                else hub.connected.forEach { if (it.id !in hub.selected) hub.selected.add(it.id) }
            }
            hub.connected.forEach { p ->
                Chip(p.name, p.id in hub.selected) {
                    if (p.id in hub.selected) hub.selected.remove(p.id) else hub.selected.add(p.id)
                }
            }
        }
    }
}

@Composable
fun TransferRow(hub: Hub, t: Transfer) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text((if (t.mine) "📤 " else "📥 ") + t.name + "  " + (t.progress * 100).toInt() + "%", maxLines = 1)
            LinearProgressIndicator(progress = { t.progress }, modifier = Modifier.fillMaxWidth())
        }
        TextButton({ hub.cancel(t) }) { Text("إلغاء") }
    }
}

@Composable
fun SettingsDialog(hub: Hub, onNav: (String) -> Unit, onClose: () -> Unit) {
    var n by remember { mutableStateOf(hub.myName) }
    var tech by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("الإعدادات") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(n, { if (it.length <= 20) n = it }, label = { Text("اسم جهازك") }, singleLine = true)
                Spacer(Modifier.height(10.dp))
                Text("المظهر", style = MaterialTheme.typography.labelMedium, color = SubC)
                Row(Modifier.padding(vertical = 4.dp)) {
                    listOf("تلقائي", "فاتح", "داكن").forEachIndexed { i, l -> Chip(l, hub.themeMode == i) { hub.setTheme(i) } }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🔔 نغمات المكالمات والرسائل", Modifier.weight(1f))
                    Switch(hub.soundsOn, { hub.toggleSounds(it) })
                }
                Text("حالة الإعلانات:\n${Ads.status}", fontSize = 11.sp, color = SubC, modifier = Modifier.padding(vertical = 6.dp))
                TextButton({ hub.clearHistory() }) { Text("🗑 حذف سجل الرسائل والملفات") }
                TextButton({ onNav("about") }) { Text("ℹ️ عن ناولني") }
                TextButton({ onNav("privacy") }) { Text("🔒 سياسة الخصوصية") }
                TextButton({ hub.openSupport() }) { Text("✉️ الدعم الفني") }
                TextButton({ tech = !tech }) { Text(if (tech) "إخفاء التفاصيل التقنية" else "🔧 التفاصيل التقنية") }
                if (tech) {
                    val tick = hub.permTick
                    Text(hub.permReport() + "\nالبث: ${hub.advStatus}\nالبحث: ${hub.discStatus}\n" + hub.log.joinToString("\n"),
                        style = MaterialTheme.typography.bodySmall, color = SubC)
                }
                Text("الإصدار ${hub.version}", style = MaterialTheme.typography.bodySmall, color = SubC)
            }
        },
        confirmButton = { TextButton({ hub.rename(n); onClose() }) { Text("حفظ") } },
        dismissButton = { TextButton(onClose) { Text("إغلاق") } }
    )
}

// ───────────────── الرئيسية ─────────────────
@Composable
fun BigCircle(icon: String, label: String, badge: Int, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(4.dp)) {
        Box {
            Surface(shape = CircleShape, color = Blue, shadowElevation = 6.dp, modifier = Modifier.size(92.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(icon, fontSize = 36.sp) }
            }
            if (badge > 0) Surface(shape = CircleShape, color = Color(0xFFE53935), modifier = Modifier.align(Alignment.TopEnd)) {
                Text(badge.toString(), color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(label, fontSize = 17.sp, color = TextC)
    }
}

@Composable
fun Tile(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = CardC, shadowElevation = 1.dp, modifier = modifier.clickable(onClick = onClick)) {
        Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 26.sp)
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
fun HomeScreen(hub: Hub, nav: (String) -> Unit) {
    var settings by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var gate by remember { mutableStateOf<String?>(null) }
    val homeCtx = LocalContext.current
    // الرسائل والمكالمات: تُفتح ساعة كاملة بعد مشاهدة إعلان مكافأة (اختياري، بموافقة المستخدم)
    val openGated = { dest: String -> if (Ads.featureUnlocked()) nav(dest) else gate = dest }
    gate?.let { dest ->
        AlertDialog(
            onDismissRequest = { gate = null },
            title = { Text("🎁 افتح ${if (dest == "chat") "الرسائل" else "المكالمات"}") },
            text = { Text("شاهد إعلاناً قصيراً لاستخدام الرسائل والمكالمات لمدة ساعة كاملة.") },
            confirmButton = {
                Button({
                    gate = null
                    Ads.showRewarded(homeCtx.findActivity(),
                        onReward = { Ads.grantFeature(); nav(dest) },
                        onUnavailable = {
                            // إن لم يتوفر إعلان (لا إنترنت أو لم يُحمَّل) لا نحجب الميزة عن المستخدم
                            Toast.makeText(homeCtx, "الإعلان غير متاح الآن، يمكنك الاستخدام مؤقتاً", Toast.LENGTH_SHORT).show()
                            nav(dest)
                        })
                }) { Text("مشاهدة الإعلان") }
            },
            dismissButton = { TextButton({ gate = null }) { Text("إلغاء") } }
        )
    }
    if (settings) SettingsDialog(hub, { settings = false; nav(it) }) { settings = false }
    if (menu) AddMenuDialog(hub) { menu = false }
    val received = hub.msgs.count { it.type == "f" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            // زر + (أعلى اليمين): رقم الجهاز، مشاركة التطبيق، بلوتوث
            Box(Modifier.size(46.dp).clip(CircleShape).background(Blue).clickable { menu = true }, contentAlignment = Alignment.Center) {
                Text("+", color = MaterialTheme.colorScheme.onPrimary, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Surface(shape = RoundedCornerShape(50), color = Blue) {
                Text("ناولني", Modifier.padding(horizontal = 24.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold, fontSize = 24.sp)
            }
            Spacer(Modifier.weight(1f))
            TextButton({ settings = true }) { Text("⚙️", fontSize = 24.sp) }
        }
        Spacer(Modifier.height(36.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            BigCircle("📂", "ملفات", received) { nav("files") }
            BigCircle("📥", "استلام", 0) { nav("recv") }
            BigCircle("📤", "إرسال", 0) { nav("pick") }
        }
        Spacer(Modifier.height(32.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("💬", "رسائل", Modifier.weight(1f)) { openGated("chat") }
            Tile("📞", "مكالمات", Modifier.weight(1f)) { openGated("calls") }
        }
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth().clickable { nav("recv") }, colors = CardDefaults.cardColors(containerColor = CardC)) {
            Column(Modifier.padding(16.dp)) {
                Text("الأجهزة المتصلة (${hub.connected.size})", fontWeight = FontWeight.Bold)
                if (hub.connected.isEmpty()) Text("لا يوجد — اضغط «استلام» أو «إرسال» للاتصال بجهاز", color = SubC, fontSize = 13.sp)
                else hub.connected.forEach { Text("🟢 ${it.name}", Modifier.padding(top = 4.dp)) }
            }
        }
        // مساحة الإعلان الدائم (تحت الأجهزة المتصلة)، بعيدة عن الأزرار لتجنب النقر بالخطأ
        if (Ads.enabled()) {
            Spacer(Modifier.height(28.dp))
            Text("إعلان", Modifier.fillMaxWidth(), fontSize = 12.sp, color = SubC, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            RectangleAd()
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** قائمة زر +: رقم الجهاز، مشاركة التطبيق (رابط Google Play)، وإرسال التطبيق بالبلوتوث. */
@Composable
fun AddMenuDialog(hub: Hub, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClose) { Text("إغلاق") } },
        title = { Text("المزيد") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardC)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("🔢 رقم جهازك", style = MaterialTheme.typography.labelMedium, color = SubC)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(hub.myCode, Modifier.weight(1f), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Blue)
                            TextButton({ hub.copy(hub.myCode) }) { Text("📋 نسخ") }
                        }
                        Text("الاسم: ${hub.myName}", style = MaterialTheme.typography.bodySmall, color = SubC)
                    }
                }
                Card(Modifier.fillMaxWidth().clickable { onClose(); hub.shareApp() }, colors = CardDefaults.cardColors(containerColor = CardC)) {
                    Text("📲 شارك التطبيق", Modifier.padding(16.dp), fontWeight = FontWeight.Medium)
                }
                Card(Modifier.fillMaxWidth().clickable { onClose(); hub.shareAppBluetooth() }, colors = CardDefaults.cardColors(containerColor = CardC)) {
                    Text("🔵 بلوتوث", Modifier.padding(16.dp), fontWeight = FontWeight.Medium)
                }
            }
        }
    )
}

// ───────────────── تحديد الملفات ─────────────────
@Composable
fun CheckMark(sel: Boolean, modifier: Modifier) {
    Box(modifier.padding(4.dp).size(22.dp).clip(CircleShape)
        .background(if (sel) Blue else Color.White.copy(alpha = 0.75f))
        .border(1.5.dp, if (sel) Blue else SubC, CircleShape), contentAlignment = Alignment.Center) {
        if (sel) Text("✓", color = MaterialTheme.colorScheme.onPrimary, fontSize = 14.sp)
    }
}

@Composable
fun Thumb(m: MediaItem, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(Thumbs.get(m.key), m.key) {
        if (value == null) value = withContext(Dispatchers.IO) { loadThumb(ctx, m)?.also { Thumbs.put(m.key, it) } }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(if (m.kind == "app") "📦" else iconOf(m.kind), fontSize = 22.sp)
    }
}

@Composable
fun PickCell(hub: Hub, m: MediaItem, square: Boolean) {
    val sel = hub.picks.any { it.key == m.key }
    Column(Modifier.padding(4.dp).clickable { hub.togglePick(m) }, horizontalAlignment = Alignment.CenterHorizontally) {
        if (square) {
            Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
                Thumb(m, Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)))
                if (m.kind == "video") Text("▶", color = Color.White, fontSize = 18.sp, modifier = Modifier.align(Alignment.Center))
                CheckMark(sel, Modifier.align(Alignment.TopStart))
            }
        } else {
            Box(Modifier.size(64.dp)) {
                Thumb(m, Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)))
                CheckMark(sel, Modifier.align(Alignment.TopStart))
            }
            Text(m.name, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
            Text(fmt(m.size), fontSize = 11.sp, color = SubC)
        }
    }
}

@Composable
fun PickRow(hub: Hub, m: MediaItem) {
    val sel = hub.picks.any { it.key == m.key }
    Row(Modifier.fillMaxWidth().clickable { hub.togglePick(m) }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(iconOf(m.kind), fontSize = 26.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(m.name, maxLines = 1)
            Text(fmt(m.size), fontSize = 12.sp, color = SubC)
        }
        CheckMark(sel, Modifier)
    }
}

@Composable
fun PickScreen(hub: Hub, onBack: () -> Unit, onNext: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf("image") }
    var permTick by remember { mutableStateOf(0) }
    // صور/فيديو على أندرويد 13+: منتقي الصور فقط (بدون READ_MEDIA_IMAGES/VIDEO)
    val pickerOnly = android.os.Build.VERSION.SDK_INT >= 33 && (tab == "image" || tab == "video")
    val needsPerm = tab == "audio" || (android.os.Build.VERSION.SDK_INT < 33 && (tab == "image" || tab == "video"))
    val granted = remember(permTick) { mediaGranted(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permTick++ }
    LaunchedEffect(tab) { if (needsPerm && !mediaGranted(ctx)) runCatching { launcher.launch(mediaPerms()) } }
    val sys = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { hub.addPicked(it) }
    // منتقي الصور الرسمي: يعمل بدون أي إذن على كل الهواتف (أندرويد 4.4+ عبر Google Play services)
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { hub.addPicked(it) }
    val openPhotoPicker = {
        val t: ActivityResultContracts.PickVisualMedia.VisualMediaType =
            if (tab == "video") ActivityResultContracts.PickVisualMedia.VideoOnly else ActivityResultContracts.PickVisualMedia.ImageOnly
        runCatching { photoPicker.launch(androidx.activity.result.PickVisualMediaRequest(t)) }
            .onFailure { runCatching { sys.launch(if (tab == "video") "video/*" else "image/*") } }
        Unit
    }
    var data by remember { mutableStateOf<List<MediaItem>?>(null) }
    LaunchedEffect(tab, granted, pickerOnly) {
        data = null
        data = withContext(Dispatchers.IO) {
            when (tab) {
                "app" -> loadApps(ctx)
                "image" -> if (pickerOnly) emptyList() else queryMedia(ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image")
                "video" -> if (pickerOnly) emptyList() else queryMedia(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video")
                "audio" -> queryMedia(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio")
                else -> emptyList()
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("تحديد الملفات", onBack)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
            listOf("audio" to "موسيقى", "image" to "صور", "app" to "تطبيقات", "video" to "فيديوهات", "file" to "ملفات").forEach { (k, l) ->
                Column(Modifier.clickable { tab = k }.padding(horizontal = 14.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(l, fontSize = 17.sp, fontWeight = if (tab == k) FontWeight.Bold else FontWeight.Normal,
                        color = if (tab == k) TextC else SubC)
                    Box(Modifier.padding(top = 4.dp).height(3.dp).width(24.dp).background(if (tab == k) Blue else Color.Transparent))
                }
            }
        }
        if ((tab == "image" || tab == "video") && !pickerOnly) {
            OutlinedButton(openPhotoPicker, Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), shape = RoundedCornerShape(50)) {
                Text(if (tab == "video") "🎬 اختيار فيديوهات من المعرض" else "🖼 اختيار صور من المعرض")
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val list = data
            when {
                tab == "file" -> Column(Modifier.fillMaxSize().padding(16.dp)) {
                    Button({ sys.launch("*/*") }, Modifier.fillMaxWidth()) { Text("📁 تصفح الملفات واختيارها") }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn { items(hub.picks.filter { it.kind == "file" }, key = { it.key }) { PickRow(hub, it) } }
                }
                pickerOnly -> Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("اختر من معرضك بأمان — لا يحتاج إذناً", color = SubC)
                    Spacer(Modifier.height(10.dp))
                    Button(openPhotoPicker, Modifier.fillMaxWidth()) {
                        Text(if (tab == "video") "🎬 اختيار فيديوهات من المعرض" else "🖼 اختيار صور من المعرض")
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn { items(hub.picks.filter { it.kind == "file" }, key = { it.key }) { PickRow(hub, it) } }
                }
                needsPerm && !granted -> Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("يلزم السماح بالوصول للوسائط لعرضها", color = SubC)
                    Spacer(Modifier.height(8.dp))
                    Button({ launcher.launch(mediaPerms()) }) { Text("السماح") }
                    if (tab == "image" || tab == "video") TextButton(openPhotoPicker) { Text("أو اختر من المعرض بدون إذن") }
                    TextButton({ hub.openAppSettings() }) { Text("فتح إعدادات التطبيق") }
                }
                list == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                list.isEmpty() -> Text("لا يوجد شيء هنا", color = SubC, modifier = Modifier.align(Alignment.Center))
                tab == "audio" -> LazyColumn { items(list, key = { it.key }) { PickRow(hub, it) } }
                else -> LazyVerticalGrid(columns = GridCells.Fixed(if (tab == "app") 4 else 3), contentPadding = PaddingValues(8.dp)) {
                    gridItems(list, key = { it.key }) { PickCell(hub, it, tab != "app") }
                }
            }
        }
        Surface(shadowElevation = 8.dp, color = CardC) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("تم تحديد ${hub.picks.size} ملف (ملفات)", Modifier.weight(1f))
                OutlinedButton({ hub.pickBluetooth() }, enabled = hub.picks.isNotEmpty(), shape = RoundedCornerShape(12.dp)) { Text("🔵 بلوتوث") }
                Spacer(Modifier.width(8.dp))
                Button(onNext, enabled = hub.picks.isNotEmpty(), shape = RoundedCornerShape(12.dp)) { Text("التالي") }
            }
        }
    }
}

// ───────────────── الملفات المستلمة ─────────────────
private fun group(kind: String?) = when (kind) {
    "apk", "aab" -> "app"; "audio" -> "audio"; "image" -> "image"; "video" -> "video"; "doc" -> "doc"; else -> "file"
}

@Composable
fun FilesScreen(hub: Hub, onBack: () -> Unit) {
    var cat by remember { mutableStateOf<String?>(null) }
    val files = hub.msgs.filter { it.type == "f" }
    val cats = listOf("app" to ("📦" to "تطبيقات"), "audio" to ("🎵" to "موسيقى"), "image" to ("🖼" to "صور"),
        "video" to ("🎬" to "فيديوهات"), "doc" to ("📄" to "مستندات"), "file" to ("📁" to "ملفات أخرى"))
    val colors = listOf(Color(0xFF3B9BFF), Color(0xFFFF5A5A), Color(0xFF45C36B), Color(0xFF8A5CF6), Color(0xFFFF9A2E), Color(0xFF7A869A))
    val incoming = hub.transfers.filter { !it.mine && it.accepted }
    Column(Modifier.fillMaxSize()) {
        TopBar(cats.firstOrNull { it.first == cat }?.second?.second ?: "ملفاتي المستلمة") { if (cat != null) cat = null else onBack() }
        if (cat == null) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardC)) {
                    Column(Modifier.padding(12.dp)) {
                        cats.chunked(3).forEachIndexed { r, row ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                row.forEachIndexed { c, (k, v) ->
                                    val n = files.count { group(it.kind) == k }
                                    Column(Modifier.weight(1f).clickable { cat = k }, horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(Modifier.size(64.dp).clip(RoundedCornerShape(18.dp)).background(colors[r * 3 + c]), contentAlignment = Alignment.Center) {
                                            Text(v.first, fontSize = 30.sp)
                                        }
                                        Text(v.second, Modifier.padding(top = 6.dp), fontSize = 15.sp)
                                        Text(n.toString(), fontSize = 13.sp, color = SubC)
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                incoming.forEach { TransferRow(hub, it) }
                hub.msgs.filter { it.type == "e" && !it.mine }.takeLast(3).asReversed().forEach {
                    Text(it.text, Modifier.padding(vertical = 2.dp), color = SubC)
                }
            }
        } else {
            val shown = files.filter { group(it.kind) == cat }.asReversed()
            LazyColumn(Modifier.padding(horizontal = 16.dp)) {
                if (shown.isEmpty()) item { Text("لا يوجد شيء هنا بعد", color = SubC, modifier = Modifier.padding(8.dp)) }
                items(shown) { m ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = CardC)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${iconOf(m.kind)} ${m.text}")
                            Text("من ${m.from} • ${fmtTime(m.time)} • ${placeOf(m.kind)}", style = MaterialTheme.typography.bodySmall, color = SubC)
                            val pad = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            when (m.kind) {
                                "apk" -> TextButton({ m.uri?.let { hub.install(it) } }, contentPadding = pad) { Text("⬇️ تثبيت") }
                                "aab" -> Text("ملف AAB لا يُثبَّت مباشرة على الهاتف", style = MaterialTheme.typography.bodySmall)
                                else -> TextButton({ m.uri?.let { hub.open(it) } }, contentPadding = pad) { Text("فتح") }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ───────────────── رسائل ─────────────────
@Composable
fun ChatTab(hub: Hub, modifier: Modifier) {
    var t by remember { mutableStateOf("") }
    val list = hub.msgs.filter { it.type == "t" }
    val state = rememberLazyListState()
    LaunchedEffect(list.size) { if (list.isNotEmpty()) state.animateScrollToItem(list.size - 1) }
    Column(modifier.padding(horizontal = 12.dp)) {
        TargetsBar(hub)
        LazyColumn(Modifier.weight(1f), state = state) {
            items(list) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.Start else Arrangement.End) {
                    Surface(shape = RoundedCornerShape(14.dp), color = if (m.mine) MaterialTheme.colorScheme.primaryContainer else CardC,
                        shadowElevation = 1.dp, modifier = Modifier.padding(4.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            if (!m.mine) Text(m.from, style = MaterialTheme.typography.labelSmall, color = Blue)
                            Text(m.text)
                            Text(fmtTime(m.time), style = MaterialTheme.typography.labelSmall, color = SubC)
                            val link = firstLink(m.text)
                            val pad = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            Row {
                                if (link != null) TextButton({ hub.openLink(link) }, contentPadding = pad) { Text("🔗 فتح الرابط") }
                                TextButton({ hub.copy(m.text) }, contentPadding = pad) { Text("📋 نسخ") }
                            }
                        }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            OutlinedTextField(t, { if (it.length <= 5000) t = it }, Modifier.weight(1f), placeholder = { Text("اكتب رسالة") })
            Spacer(Modifier.width(6.dp))
            Button({ if (t.isNotBlank()) { hub.sendText(t.trim()); t = "" } }) { Text("إرسال") }
        }
    }
}

// ───────────────── مكالمات ─────────────────
@Composable
fun CallsTab(hub: Hub, withMic: (() -> Unit) -> Unit, modifier: Modifier) {
    Column(modifier.padding(16.dp)) {
        TargetsBar(hub)
        Spacer(Modifier.height(8.dp))
        Button({ withMic { hub.callSelected() } }, enabled = hub.connected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
            Text(if (hub.inCall) "➕ إضافة المحددين للمكالمة" else "📞 اتصال صوتي بالمحدد")
        }
        if (hub.inCall) {
            Spacer(Modifier.height(16.dp))
            Text("🎙 مكالمة جارية", style = MaterialTheme.typography.titleMedium)
            hub.callPeers.forEach { Text("🟢 ${hub.peerName(it)}", Modifier.padding(vertical = 2.dp)) }
            hub.calling.forEach { Text("⏳ جارٍ الاتصال بـ ${hub.peerName(it)}", Modifier.padding(vertical = 2.dp), color = SubC) }
            Spacer(Modifier.height(12.dp))
            Row {
                OutlinedButton({ hub.muteMic(!hub.muted) }, Modifier.weight(1f).padding(4.dp)) {
                    Text(if (hub.muted) "🔇 مكتوم" else "🎙 الميكروفون")
                }
                OutlinedButton({ hub.setSpeakerOn(!hub.speaker) }, Modifier.weight(1f).padding(4.dp)) {
                    Text(if (hub.speaker) "🔊 مكبّر الصوت" else "📱 السماعة")
                }
            }
            Button({ hub.endCall() }, Modifier.fillMaxWidth().padding(4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) { Text("إنهاء المكالمة") }
        } else {
            Spacer(Modifier.height(12.dp))
            Text("المكالمة تعمل مباشرة بين الأجهزة القريبة بدون إنترنت.", color = SubC)
        }
    }
}
