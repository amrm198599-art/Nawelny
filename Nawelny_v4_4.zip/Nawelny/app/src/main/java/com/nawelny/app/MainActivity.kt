package com.nawelny.app

import android.Manifest
import android.content.Context
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.res.Configuration
import android.util.Rational
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

@Suppress("DEPRECATION")
class MainActivity : ComponentActivity() {
    private lateinit var hub: Hub
    override fun onCreate(b: Bundle?) {
        // Edge-to-Edge: يجب قبل super.onCreate. إجباري على أندرويد 15 ويعمل على 8.0+ عبر androidx.
        enableEdgeToEdge()
        super.onCreate(b)
        hub = (application as NawelnyApp).hub
        Ads.init(application)
        handle(intent)
        setContent {
            val dark = when (hub.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme) {
                    val bg = MaterialTheme.colorScheme.background
                    // أشرطة النظام شفافة، ولون أيقوناتها يتبع المظهر الذي يختاره المستخدم (وليس مظهر النظام فقط)
                    SideEffect {
                        runCatching {
                            enableEdgeToEdge(
                                statusBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark },
                                navigationBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark }
                            )
                        }
                    }
                    Surface(Modifier.fillMaxSize(), color = bg) {
                        // safeDrawingPadding = شريط الحالة + شريط التنقل + الحواف المقطوعة (Notch) + لوحة المفاتيح
                        Box(Modifier.fillMaxSize().safeDrawingPadding()) { App(hub) }
                    }
                }
            }
        }
    }
    override fun onStart() {
        super.onStart(); hub.foreground = true; hub.refreshChecks()
        if (hub.shareAdPending) { hub.shareAdPending = false; Ads.onShare(this) }
        if (requiredGranted(this)) { hub.autoFix(); hub.ensureSearch() }
    }
    override fun onStop() { super.onStop(); hub.foreground = false }

    // نافذة صورة داخل صورة: عند الخروج من التطبيق أثناء مكالمة تستمر المكالمة في نافذة صغيرة
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (hub.inCall) runCatching {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(1, 1)).build())
        }
    }
    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        hub.inPip = isInPictureInPictureMode
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }

    @Suppress("DEPRECATION")
    private fun handle(i: Intent?) {
        when (i?.action) {
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { hub.enqueue(listOf(it)) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { hub.enqueue(it) }
        }
    }
}

fun fmt(b: Long) = if (b >= 1_048_576) "%.1f م.ب".format(b / 1048576.0) else "${b / 1024} ك.ب"

fun perms(): Array<String> = buildList {
    if (Build.VERSION.SDK_INT >= 31) {
        add(Manifest.permission.BLUETOOTH_ADVERTISE); add(Manifest.permission.BLUETOOTH_CONNECT); add(Manifest.permission.BLUETOOTH_SCAN)
    }
    if (Build.VERSION.SDK_INT >= 33) { add(Manifest.permission.NEARBY_WIFI_DEVICES); add(Manifest.permission.POST_NOTIFICATIONS) }
    add(Manifest.permission.ACCESS_COARSE_LOCATION); add(Manifest.permission.ACCESS_FINE_LOCATION)
    if (Build.VERSION.SDK_INT <= 28) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    add(Manifest.permission.RECORD_AUDIO)
}.toTypedArray()

fun requiredGranted(ctx: Context): Boolean = perms().filter { it !in optionalPerms }
    .all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

private val optionalPerms: Set<String> = buildSet {
    add(Manifest.permission.POST_NOTIFICATIONS); add(Manifest.permission.RECORD_AUDIO)
    // أندرويد 13+: NEARBY_WIFI_DEVICES يغني عن الموقع (neverForLocation). أقل من 13: الموقع الدقيق إلزامي لـ Wi-Fi Direct.
    if (Build.VERSION.SDK_INT >= 33) { add(Manifest.permission.ACCESS_FINE_LOCATION); add(Manifest.permission.ACCESS_COARSE_LOCATION) }
}

@Composable
fun App(hub: Hub) {
    val ctx = LocalContext.current
    var reqTick by remember { mutableStateOf(0) }
    val ok = remember(hub.permTick, reqTick) { requiredGranted(ctx) }
    var tab by remember { mutableStateOf(0) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        reqTick++
        if (requiredGranted(ctx)) { hub.refreshChecks(); hub.autoFix(); hub.ensureSearch() }
        else hub.openPermissionPage()   // يفتح صفحة أذونات التطبيق تلقائياً
    }
    // كل طلب إذن محمي: لا انهيار إن لم توجد واجهة طلب الأذونات أو كانت الشاشة قيد الإغلاق
    val safeRequest = { runCatching { launcher.launch(perms()) }; Unit }
    LaunchedEffect(Unit) { safeRequest() }

    var pendingMic by remember { mutableStateOf<(() -> Unit)?>(null) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingMic?.invoke()
        else Toast.makeText(ctx, "إذن الميكروفون مطلوب للمكالمات", Toast.LENGTH_LONG).show()
        pendingMic = null
    }
    val withMic: (() -> Unit) -> Unit = { action ->
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) action()
        else { pendingMic = action; micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
    }

    hub.requests.firstOrNull()?.let { (id, info) ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("طلب اتصال") },
            text = { Text("${hub.peerName(id)}\nرمز التحقق: ${info.authenticationDigits}\n(يجب أن يتطابق على الجهازين)") },
            confirmButton = { TextButton({ hub.accept(id) }) { Text("قبول") } },
            dismissButton = { TextButton({ hub.reject(id) }) { Text("رفض") } }
        )
    }
    hub.transfers.firstOrNull { !it.mine && !it.accepted && it.named }?.let { t ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("ملف وارد من ${hub.peerName(t.peerId)}") },
            text = { Text("${iconOf(null)} ${t.name}\n${fmt(t.size)}") },
            confirmButton = { TextButton({ hub.acceptFile(t) }) { Text("قبول") } },
            dismissButton = { TextButton({ hub.rejectFile(t) }) { Text("رفض") } }
        )
    }
    hub.ringing?.let { id ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("📞 مكالمة واردة") },
            text = { Text(hub.peerName(id)) },
            confirmButton = { TextButton({
                if (Ads.featureUnlocked()) withMic { hub.acceptCall() }
                else Ads.showRewardedWait(ctx.findActivity(),
                    onReward = { Ads.grantFeature(); withMic { hub.acceptCall() } },
                    onUnavailable = { Toast.makeText(ctx, "شاهد الإعلان للرد على المكالمة، تعذر تحميله الآن", Toast.LENGTH_LONG).show() })
            }) { Text("رد") } },
            dismissButton = { TextButton({ hub.declineCall() }) { Text("رفض") } }
        )
    }

    if (hub.inPip) { PipCall(hub); return }
    var screen by remember { mutableStateOf("home") }
    var backTo by remember { mutableStateOf("home") }
    var gate by remember { mutableStateOf<String?>(null) }
    // الرسائل/المكالمات تُفتح من شاشة الاستلام/الإرسال ثم يرجع المستخدم إليها
    val navTo: (String) -> Unit = { dest ->
        backTo = if ((dest == "chat" || dest == "calls") && (screen == "recv" || screen == "send")) screen else "home"
        screen = dest
    }
    val openFeature: (String) -> Unit = { dest -> if (Ads.featureUnlocked()) navTo(dest) else gate = dest }
    FeatureGate(gate, { gate = null }, navTo)
    val act = ctx.findActivity()
    // إعلان بيني بعد كل مشاركة مكتملة (وبعد انتهاء بقية الملفات الجارية)
    LaunchedEffect(hub.shareTick) { if (hub.shareTick > 0 && hub.transfers.isEmpty()) Ads.onShare(act) }
    // شاشة التقييم: أول فتح ثم كل 3 أيام، وتتوقف نهائياً بعد التقييم
    var showRating by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(5000)
        if (Rating.shouldShow(ctx)) { Rating.markShown(ctx); showRating = true }
    }
    if (showRating) RatingDialog { showRating = false }
    // الرجوع من شاشة اتصال: إعلان بيني بشروط (كل 3 مرات، فاصل دقيقتين، وبدون نقل أو مكالمة جارية)
    val adExit = { Ads.onScreenExit(act, hub.transfers.isEmpty() && !hub.inCall) }
    BackHandler(enabled = screen != "home") {
        if (screen in setOf("send", "recv", "files", "chat", "calls", "pick")) adExit()
        screen = if (screen == "send") "pick" else if (screen == "chat" || screen == "calls") backTo else "home"
    }
    val reqPerms = safeRequest
    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (screen) {
                "home" -> HomeScreen(hub) { navTo(it) }
                "pick" -> PickScreen(hub, { screen = "home" }) { hub.stagePicks(); screen = "send" }
                "send" -> ConnectScreen(hub, ok, reqPerms, "إرسال", false, openFeature) { adExit(); screen = "home" }
                "recv" -> ConnectScreen(hub, ok, reqPerms, "استلام", true, openFeature) { adExit(); screen = "home" }
                "files" -> FilesScreen(hub) { adExit(); screen = "home" }
                "about" -> InfoScreen("عن ناولني", ABOUT, hub) { screen = "home" }
                "privacy" -> InfoScreen("سياسة الخصوصية", PRIVACY, hub) { screen = "home" }
                "chat" -> Column(Modifier.fillMaxSize()) { TopBar("رسائل") { adExit(); screen = backTo }; ChatTab(hub, Modifier.weight(1f)) }
                else -> Column(Modifier.fillMaxSize()) { TopBar("مكالمات") { adExit(); screen = backTo }; CallsTab(hub, withMic, Modifier.weight(1f)) }
            }
        }
        if (Ads.enabled()) BannerAd()   // بانر دائم في كل الشاشات
    }
}

/** واجهة مصغّرة داخل نافذة الصورة داخل صورة أثناء المكالمة. */
@Composable
fun PipCall(hub: Hub) {
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = androidx.compose.ui.Alignment.Center) {
        Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
            Text("📞", fontSize = 22.sp)
            Text(hub.callPeers.firstOrNull()?.let { hub.peerName(it) } ?: "مكالمة", fontSize = 12.sp, maxLines = 1)
            Spacer(Modifier.height(6.dp))
            Button({ hub.endCall() }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) { Text("إنهاء", fontSize = 11.sp) }
        }
    }
}
