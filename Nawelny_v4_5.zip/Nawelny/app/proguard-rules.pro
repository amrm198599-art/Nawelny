# قواعد R8 لتطبيق ناولني
# مكتبات Compose وPlay Services وZXing وAdMob تأتي بقواعدها الخاصة (consumer rules).
-keepattributes SourceFile,LineNumberTable,*Annotation*,Signature,InnerClasses,EnclosingMethod
-renamesourcefileattribute SourceFile
-keep class com.nawelny.app.NawelnyApp { *; }
-keep class com.nawelny.app.TransferService { *; }
-keep class com.nawelny.app.MainActivity { *; }
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
