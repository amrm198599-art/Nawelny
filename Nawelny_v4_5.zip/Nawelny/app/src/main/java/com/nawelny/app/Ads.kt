package com.nawelny.app

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.ContextWrapper
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback

/** معرّفات AdMob. نسخة debug تستخدم معرّفات Google التجريبية لتجنّب النقرات غير الصالحة على حسابك. */
object AdIds {
    // App ID (موجود في AndroidManifest.xml): ca-app-pub-9932315898148137~8767644167
    val BANNER: String get() =
        if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/9214589741" else "ca-app-pub-9932315898148137/9009372657"
    val INTERSTITIAL: String get() =
        if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/1033173712" else "ca-app-pub-9932315898148137/8007282175"
    // وحدة "إعلان بيني مقابل مكافأة" (Rewarded Interstitial) كما في لوحة AdMob
    val REWARDED: String get() =
        if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/5354046379" else "ca-app-pub-9932315898148137/4551700000"
}

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

/**
 * مدير الإعلانات: تهيئة آمنة في خيط خلفي، تحميل مسبق، وإعادة تحميل بعد كل عرض.
 * كل الاستدعاءات محمية بـ runCatching حتى لا ينهار التطبيق بسبب أي إعلان.
 * لا يحتفظ بأي Activity (تجنّب تسرب الذاكرة)، والـ callbacks تعمل بسياق التطبيق فقط.
 */
object Ads {
    private const val PREFS = "nawelny_ads"
    private const val KEY_FREE_UNTIL = "free_until"
    private const val MIN_GAP_MS = 60_000L      // أقل فاصل بين إعلانين بينيين
    private const val EVERY_N_EXITS = 2         // إعلان بيني كل مرتين خروج من شاشة

    private val main = Handler(Looper.getMainLooper())
    private var appCtx: Context? = null
    @Volatile private var started = false

    private var ready by mutableStateOf(false)

    /** آخر حالة للإعلانات (تظهر في الإعدادات) لمعرفة سبب عدم الظهور: كود الخطأ ورسالته. */
    var status by mutableStateOf("لم تبدأ التهيئة بعد")
        private set
    private val statusMap = linkedMapOf<String, String>()
    fun report(kind: String, msg: String) {
        main.post {
            statusMap[kind] = msg
            status = statusMap.entries.joinToString("\n") { "${it.key}: ${it.value}" }
        }
    }
    fun reportError(kind: String, e: LoadAdError) = report(kind, "فشل (${e.code}) ${e.message}")
    private var freeUntil by mutableLongStateOf(0L)

    private var interstitial: InterstitialAd? = null
    private var loadingInterstitial = false
    private var rewarded: RewardedInterstitialAd? = null
    private var loadingRewarded = false
    private var exits = 0
    private var lastShown = 0L

    /** الإعلانات تظهر دائماً بعد اكتمال تهيئة AdMob. */
    fun enabled(): Boolean = ready   // الإعلانات دائمة: لا توجد فترة إخفاء

    fun init(app: Application) {
        if (started) return
        started = true
        appCtx = app.applicationContext
        freeUntil = runCatching { app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_FREE_UNTIL, 0L) }.getOrDefault(0L)
        // التهيئة في خيط خلفي كما توصي Google لتفادي تعليق الواجهة
        Thread {
            runCatching {
                MobileAds.initialize(app) { _ ->
                    main.post {
                        ready = true
                        report("التهيئة", "تمت ✅")
                        appCtx?.let { loadInterstitial(it); loadRewarded(it) }
                    }
                }
            }
        }.start()
        // إن تأخرت التهيئة نعرض الإعلانات على أي حال بعد 8 ثوانٍ
        main.postDelayed({ if (!ready) { ready = true; appCtx?.let { loadInterstitial(it); loadRewarded(it) } } }, 8000)
    }

    // ───────── بيني ─────────
    private fun loadInterstitial(c: Context) {
        if (loadingInterstitial || interstitial != null) return
        loadingInterstitial = true
        runCatching {
            InterstitialAd.load(c, AdIds.INTERSTITIAL, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { loadingInterstitial = false; interstitial = ad; report("البيني", "جاهز ✅") }
                override fun onAdFailedToLoad(e: LoadAdError) {
                    loadingInterstitial = false; interstitial = null; reportError("البيني", e)
                    main.postDelayed({ appCtx?.let { loadInterstitial(it) } }, 60_000)   // إعادة محاولة بعد دقيقة
                }
            })
        }.onFailure { loadingInterstitial = false }
    }

    /** يُستدعى عند الرجوع من شاشة اتصال. [idle] = لا نقل ملفات ولا مكالمة جارية. */
    fun onScreenExit(activity: Activity?, idle: Boolean) {
        if (activity == null || !idle || !enabled()) return
        exits++
        if (exits % EVERY_N_EXITS != 0) return
        if (SystemClock.elapsedRealtime() - lastShown < MIN_GAP_MS) return
        showInterstitial(activity)
    }

    private const val SHARE_GAP_MS = 15_000L
    /** يُستدعى بعد كل مشاركة مكتملة (إرسال/استلام): إعلان بيني بفاصل 15 ثانية فقط لتفادي التكرار داخل الدفعة الواحدة. */
    fun onShare(activity: Activity?) {
        if (activity == null || !enabled()) return
        if (SystemClock.elapsedRealtime() - lastShown < SHARE_GAP_MS) return
        showInterstitial(activity)
    }

    private fun showInterstitial(activity: Activity) {
        val ad = interstitial ?: run { appCtx?.let { loadInterstitial(it) }; return }
        if (activity.isFinishing || activity.isDestroyed) return
        interstitial = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() { lastShown = SystemClock.elapsedRealtime() }
            override fun onAdDismissedFullScreenContent() { appCtx?.let { loadInterstitial(it) } }
            override fun onAdFailedToShowFullScreenContent(e: AdError) { appCtx?.let { loadInterstitial(it) } }
        }
        runCatching { ad.show(activity) }.onFailure { appCtx?.let { c -> loadInterstitial(c) } }
    }

    // ───────── مكافأة ─────────
    private fun loadRewarded(c: Context) {
        if (loadingRewarded || rewarded != null) return
        loadingRewarded = true
        runCatching {
            RewardedInterstitialAd.load(c, AdIds.REWARDED, AdRequest.Builder().build(), object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) { loadingRewarded = false; rewarded = ad; report("المكافأة", "جاهز ✅") }
                override fun onAdFailedToLoad(e: LoadAdError) {
                    loadingRewarded = false; rewarded = null; reportError("المكافأة", e)
                    main.postDelayed({ appCtx?.let { loadRewarded(it) } }, 60_000)
                }
            })
        }.onFailure { loadingRewarded = false }
    }

    /** يعرض إعلان المكافأة. [onReward] تُنفَّذ فقط عند إكمال المشاهدة، و[onUnavailable] إن لم يكن الإعلان جاهزاً. */
    fun showRewarded(activity: Activity?, onReward: () -> Unit, onUnavailable: () -> Unit) {
        val ad = rewarded
        if (activity == null || ad == null || activity.isFinishing || activity.isDestroyed) {
            appCtx?.let { loadRewarded(it) }
            onUnavailable(); return
        }
        rewarded = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { appCtx?.let { loadRewarded(it) } }
            override fun onAdFailedToShowFullScreenContent(e: AdError) { appCtx?.let { loadRewarded(it) } }
        }
        runCatching { ad.show(activity) { _ -> onReward() } }
            .onFailure { appCtx?.let { c -> loadRewarded(c) }; onUnavailable() }
    }

    /** يعرض المكافأة وإن لم تكن جاهزة يطلب تحميلها وينتظر حتى 12 ثانية ثم يعرضها. لا يمنح المكافأة إلا بإكمال المشاهدة. */
    fun showRewardedWait(activity: Activity?, onReward: () -> Unit, onUnavailable: () -> Unit) {
        if (rewarded != null) { showRewarded(activity, onReward, onUnavailable); return }
        appCtx?.let { loadRewarded(it) }
        var waited = 0
        val poll = object : Runnable {
            override fun run() {
                when {
                    rewarded != null -> showRewarded(activity, onReward, onUnavailable)
                    waited >= 12_000 -> onUnavailable()
                    else -> { waited += 500; main.postDelayed(this, 500) }
                }
            }
        }
        main.postDelayed(poll, 500)
    }

    // ───────── فتح الرسائل والمكالمات بإعلان مكافأة ─────────
    private const val KEY_FEAT_UNTIL = "feat_until"
    private const val FEATURE_MINUTES = 15   // مدة فتح الرسائل/المكالمات بعد إعلان المكافأة (اجعلها 0 ليُطلب إعلان في كل مرة)
    private var featUntil by mutableLongStateOf(0L)

    /** هل الرسائل والمكالمات مفتوحة الآن (بعد مشاهدة إعلان المكافأة)؟ */
    fun featureUnlocked(): Boolean = System.currentTimeMillis() < featUntil ||
        System.currentTimeMillis() < (appCtx?.let { runCatching { it.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_FEAT_UNTIL, 0L) }.getOrDefault(0L) } ?: 0L)

    fun grantFeature() {
        val until = System.currentTimeMillis() + FEATURE_MINUTES * 60_000L
        featUntil = until
        runCatching { appCtx?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)?.edit()?.putLong(KEY_FEAT_UNTIL, until)?.apply() }
    }

    /** يمنح فترة بدون إعلانات (بعد مشاهدة إعلان المكافأة). */
    fun grantAdFree(hours: Int) {
        val until = System.currentTimeMillis() + hours * 3_600_000L
        freeUntil = until
        runCatching { appCtx?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)?.edit()?.putLong(KEY_FREE_UNTIL, until)?.apply() }
    }
}

/** بانر متكيّف مع عرض الشاشة، مرتبط بدورة حياة الشاشة (pause/resume/destroy) لتجنّب التسرب. */
@Composable
fun BannerAd(modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val widthDp = maxWidth.value.toInt()
        if (widthDp > 0) key(widthDp) { BannerInner(widthDp, Modifier.fillMaxWidth()) }
    }
}

@Composable
private fun BannerInner(widthDp: Int, modifier: Modifier) {
    var view by remember { mutableStateOf<AdView?>(null) }

    AndroidView(
        modifier = modifier,
        factory = { c ->
            AdView(c).apply {
                runCatching {
                    setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(c, widthDp))
                    adUnitId = AdIds.BANNER
                    adListener = object : AdListener() {
                        override fun onAdLoaded() { Ads.report("البانر", "ظهر ✅") }
                        override fun onAdFailedToLoad(e: LoadAdError) { Ads.reportError("البانر", e) }
                    }
                    loadAd(AdRequest.Builder().build())
                }
                view = this
            }
        }
    )

    AdViewLifecycle(view)
}

/** إعلان مستطيل متوسط (300×250) للمساحة الفارغة في الشاشة الرئيسية. */
@Composable
fun RectangleAd(modifier: Modifier = Modifier) {
    var view by remember { mutableStateOf<AdView?>(null) }
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        AndroidView(factory = { c ->
            AdView(c).apply {
                runCatching {
                    setAdSize(AdSize.MEDIUM_RECTANGLE)
                    adUnitId = AdIds.BANNER
                    adListener = object : AdListener() {
                        override fun onAdLoaded() { Ads.report("البانر", "ظهر ✅") }
                        override fun onAdFailedToLoad(e: LoadAdError) { Ads.reportError("البانر", e) }
                    }
                    loadAd(AdRequest.Builder().build())
                }
                view = this
            }
        })
    }
    AdViewLifecycle(view)
}

/** يربط الإعلان بدورة حياة الشاشة: pause/resume ثم destroy عند الخروج لمنع التسرب. */
@Composable
private fun AdViewLifecycle(view: AdView?) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle, view) {
        val v = view
        val obs = LifecycleEventObserver { _, e ->
            runCatching {
                when (e) {
                    Lifecycle.Event.ON_PAUSE -> v?.pause()
                    Lifecycle.Event.ON_RESUME -> v?.resume()
                    else -> Unit
                }
            }
        }
        lifecycle.addObserver(obs)
        onDispose {
            lifecycle.removeObserver(obs)
            runCatching { v?.destroy() }
        }
    }
}
