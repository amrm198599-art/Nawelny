package com.nawelny.app

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private val Green = Color(0xFF2EB872)
private val CardShape = RoundedCornerShape(16.dp)

/** زر كبسولة موحّد وصغير. */
@Composable
fun PillButton(
    label: String,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    enabled: Boolean = true,
    height: Dp = 38.dp,
    leading: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    val container = if (filled) Blue else MaterialTheme.colorScheme.primaryContainer
    val content = if (filled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onPrimaryContainer
    Box(
        modifier = modifier
            .height(height)
            .alpha(if (enabled) 1f else 0.5f)
            .clip(shape)
            .background(container)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (leading != null) { leading(); Spacer(Modifier.width(6.dp)) }
            Text(label, color = content, fontWeight = FontWeight.Medium, fontSize = 13.sp, maxLines = 1)
        }
    }
}

/** دائرة بحرف أول الاسم (مثل صور الأجهزة في شيرت). */
@Composable
private fun Avatar(name: String, size: Dp, modifier: Modifier = Modifier) {
    val palette = listOf(0xFF2F6FDB, 0xFF2EB872, 0xFFFF9A2E, 0xFF8A5CF6, 0xFFE5484D, 0xFF0EA5A5).map { Color(it) }
    val c = palette[(name.hashCode() and 0x7fffffff) % palette.size]
    Box(modifier.size(size).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
        Text(tr(name).trim().take(1).ifEmpty { "؟" }, color = Color.White, fontSize = (size.value * 0.42f).sp, fontWeight = FontWeight.Bold)
    }
}

/** رادار متحرك: دوائر تتوسع من مركز الجهاز أثناء البحث. */
@Composable
private fun Radar(color: Color, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2800, easing = LinearEasing), RepeatMode.Restart),
        label = "p"
    )
    Canvas(modifier) {
        val maxR = size.minDimension / 2f
        drawCircle(color.copy(alpha = 0.07f), radius = maxR * 0.3f, center = center)
        for (i in 0..2) {
            val f = (p + i / 3f) % 1f
            drawCircle(
                color.copy(alpha = (1f - f) * 0.35f),
                radius = maxR * (0.3f + 0.7f * f), center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}

/** أيقونة إجراء صغيرة (40dp) مع تسمية قصيرة تحتها. */
@Composable
private fun ActionIcon(label: String, modifier: Modifier = Modifier, icon: @Composable () -> Unit, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) { icon() }
        Spacer(Modifier.height(3.dp))
        Text(label, fontSize = 11.sp, maxLines = 1, color = TextC)
    }
}

@Composable
private fun MiniIcon(emoji: String, onClick: () -> Unit) {
    Box(Modifier.size(32.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) { Text(emoji, fontSize = 15.sp) }
}

@Composable
private fun ModeChip(label: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(32.dp).clip(RoundedCornerShape(16.dp))
            .background(if (on) Blue else CardC).clickable(onClick = onClick).padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 12.sp, maxLines = 1, color = if (on) MaterialTheme.colorScheme.onPrimary else TextC)
    }
}

@Composable
private fun SectionTitle(text: String, topGap: Dp = 14.dp) {
    Text(text, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = topGap, bottom = 6.dp))
}

// ───────────────── شاشة الاتصال (إرسال / استلام) على طريقة شيرت ─────────────────
@Composable
fun ConnectScreen(
    hub: Hub, ok: Boolean, requestPerms: () -> Unit, title: String,
    receive: Boolean, openFeature: (String) -> Unit, onBack: () -> Unit
) {
    val avail = hub.found.filter { f -> hub.connected.none { it.id == f.id } }
    val shown = avail.take(5)
    val rest = avail.drop(5)
    val moving = hub.transfers.filter { it.mine || it.accepted }
    var codeIn by remember { mutableStateOf("") }
    var showQr by remember { mutableStateOf(false) }
    var manual by remember { mutableStateOf(false) }
    val rot = remember { Animatable(0f) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        if (tick > 0) {
            rot.snapTo(0f)
            rot.animateTo(720f, tween(1500, easing = LinearEasing))
            rot.snapTo(0f)
        }
    }
    val ctx = LocalContext.current
    val rescan: () -> Unit = {
        tick++
        hub.resetAsked(); requestPerms(); hub.refreshChecks(); hub.autoFix(); hub.restartSearch()
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(title, onBack)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 2.dp)) {

            // ── وضع الاتصال (شرائح صغيرة)
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ModeChip("🚀 Wi-Fi Direct", hub.connMode == 2, Modifier.weight(1.3f)) { hub.chooseMode(2) }
                    ModeChip("⚡ سريع", hub.connMode == 1, Modifier.weight(1f)) { hub.chooseMode(1) }
                    ModeChip("👥 عدة أجهزة", hub.connMode == 0, Modifier.weight(1.1f)) { hub.chooseMode(0) }
                }
                Text(
                    when (hub.connMode) {
                        2 -> "Wi-Fi Direct بأعلى سرعة. اضغط على الجهاز ثم يوافق الطرف الآخر. لا يدعم الرقم/QR، وقد ينقطع الإنترنت مؤقتاً."
                        1 -> "جهاز واحد بسرعة عالية. يجب أن يكون الجهاز الآخر على نفس الوضع."
                        else -> "عدة أجهزة معاً بسرعة أقل. يجب أن يكون الجهاز الآخر على نفس الوضع."
                    },
                    fontSize = 11.sp, color = SubC, modifier = Modifier.padding(top = 6.dp)
                )
            }

            // ── الرادار + الأجهزة القريبة حول جهازك
            item {
                Box(Modifier.fillMaxWidth().height(270.dp), contentAlignment = Alignment.Center) {
                    Radar(Blue, Modifier.size(260.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Avatar(hub.myName, 60.dp)
                        Spacer(Modifier.height(4.dp))
                        Text(hub.myName, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                    val slots = listOf(210.0, 330.0, 150.0, 30.0, 270.0)
                    shown.forEachIndexed { i, p ->
                        val a = Math.toRadians(slots[i])
                        Column(
                            Modifier.offset(x = (cos(a) * 112).dp, y = (sin(a) * 100).dp)
                                .width(76.dp).clip(RoundedCornerShape(12.dp)).clickable { hub.connectNow(p) },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Avatar(p.name, 46.dp)
                            Text(p.name, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
                        }
                    }
                }
                Text(
                    when {
                        !ok -> "يلزم السماح بالأذونات ليعمل التطبيق"
                        avail.isNotEmpty() -> "اضغط على جهاز للاتصال به"
                        receive -> "في انتظار المرسل… افتح «إرسال» على الجهاز الآخر"
                        else -> "جارٍ البحث عن أجهزة قريبة… افتح «استلام» على الجهاز الآخر"
                    },
                    Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 12.sp, color = SubC
                )
                if (hub.discStatus.startsWith("فشل"))
                    Text("⚠️ فشل البحث عن الأجهزة", Modifier.fillMaxWidth().padding(top = 4.dp), textAlign = TextAlign.Center, fontSize = 12.sp, color = Color(0xFFD32F2F))
                if (hub.advStatus.startsWith("فشل"))
                    Text("⚠️ فشل الاتصال", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 12.sp, color = Color(0xFFD32F2F))
            }

            // ── صف أيقونات الإجراءات (صغيرة)
            item {
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    ActionIcon("عرض QR", Modifier.weight(1f), { Text("🔳", fontSize = 18.sp) }) { showQr = !showQr }
                    ActionIcon("مسح QR", Modifier.weight(1f), { Text("📷", fontSize = 18.sp) }) {
                        scanQr(ctx, { hub.connectFromQr(it) }, { Toast.makeText(ctx, tr(it), Toast.LENGTH_LONG).show() })
                    }
                    ActionIcon("بلوتوث", Modifier.weight(1f), { Text("🔵", fontSize = 18.sp) }) { hub.makeDiscoverable() }
                    ActionIcon("إعادة البحث", Modifier.weight(1f), {
                        Icon(Icons.Filled.Refresh, null, Modifier.size(20.dp).rotate(rot.value), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    }) { rescan() }
                }
            }

            // ── رقم الجهاز + QR (كارت واحد مضغوط)
            item {
                Spacer(Modifier.height(10.dp))
                Column(Modifier.fillMaxWidth().clip(CardShape).background(CardC).padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("رقم جهازك — أعطه للطرف الآخر", fontSize = 11.sp, color = SubC)
                            Text(hub.myCode, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Blue, letterSpacing = 2.sp)
                        }
                        PillButton("📋 نسخ") { hub.copy(hub.myCode) }
                    }
                    AnimatedVisibility(showQr) {
                        Box(Modifier.fillMaxWidth().padding(top = 12.dp), contentAlignment = Alignment.Center) {
                            QrImage(hub.qrPayload(), Modifier.size(170.dp))
                        }
                    }
                }
            }

            // ── الاتصال برقم الجهاز (قسم قابل للطي)
            item {
                Spacer(Modifier.height(8.dp))
                Column(Modifier.fillMaxWidth().clip(CardShape).background(CardC)) {
                    Row(Modifier.fillMaxWidth().clickable { manual = !manual }.padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("اتصال برقم الجهاز", Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text(if (manual) "▴" else "▾", fontSize = 14.sp, color = SubC)
                    }
                    AnimatedVisibility(manual || hub.codeStatus.isNotEmpty()) {
                        Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                BasicTextField(
                                    value = codeIn,
                                    onValueChange = { v -> if (v.length <= 6 && v.all { it.isDigit() }) codeIn = v },
                                    singleLine = true,
                                    textStyle = TextStyle(color = TextC, fontSize = 16.sp, textAlign = TextAlign.Center, letterSpacing = 3.sp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    cursorBrush = SolidColor(Blue),
                                    modifier = Modifier.weight(1f).height(42.dp),
                                    decorationBox = { inner ->
                                        Box(
                                            Modifier.fillMaxSize().border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(21.dp)).padding(horizontal = 12.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (codeIn.isEmpty()) Text("000000", color = SubC, fontSize = 16.sp, letterSpacing = 3.sp)
                                            inner()
                                        }
                                    }
                                )
                                PillButton("اتصال", Modifier.width(84.dp), filled = true, height = 42.dp, enabled = codeIn.length == 6) {
                                    hub.connectByCode(codeIn)
                                }
                            }
                            if (hub.codeStatus.isNotEmpty()) Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(hub.codeStatus, Modifier.weight(1f), fontSize = 12.sp)
                                TextButton({ hub.cancelCode() }) { Text("إلغاء", fontSize = 12.sp) }
                            }
                        }
                    }
                }
            }

            // ── الرسائل والمكالمات
            item {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("💬 رسائل نصية", Modifier.weight(1f)) { openFeature("chat") }
                    PillButton("📞 مكالمات", Modifier.weight(1f)) { openFeature("calls") }
                }
            }

            // ── ملفات جاهزة وتقدّم النقل
            if (hub.queue.isNotEmpty() || moving.isNotEmpty()) item {
                Spacer(Modifier.height(8.dp))
                if (hub.queue.isNotEmpty())
                    Text("📎 ${hub.queue.size} ملف جاهز للإرسال — اتصل بجهاز وسيبدأ الإرسال تلقائياً", fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth().clip(CardShape).background(CardC).padding(12.dp))
                moving.forEach { TransferRow(hub, it) }
            }

            // ── الأجهزة المتصلة
            item { SectionTitle("الأجهزة المتصلة (${hub.connected.size})", 16.dp) }
            if (hub.connected.isEmpty()) item { Text("لا يوجد جهاز متصل", fontSize = 12.sp, color = SubC) }
            else item { TargetsBar(hub) }
            items(hub.connected, key = { it.id }) { p ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(CardShape).background(CardC).padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(p.name, 34.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("🟢 متصل", fontSize = 11.sp, color = Green)
                    }
                    MiniIcon("💬") { hub.selected.clear(); hub.selected.add(p.id); openFeature("chat") }
                    Spacer(Modifier.width(6.dp))
                    MiniIcon("📞") { hub.selected.clear(); hub.selected.add(p.id); openFeature("calls") }
                    TextButton({ hub.disconnect(p) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("قطع", fontSize = 12.sp) }
                }
            }

            // ── باقي الأجهزة القريبة (أكثر من 5)
            if (rest.isNotEmpty()) {
                item { SectionTitle("أجهزة قريبة أخرى") }
                items(rest, key = { it.id }) { p ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(CardShape).background(CardC)
                            .clickable { hub.connectNow(p) }.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(p.name, 34.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("متاح — اضغط للاتصال", fontSize = 11.sp, color = SubC)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
