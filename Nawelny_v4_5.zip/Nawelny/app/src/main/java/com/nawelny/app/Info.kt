package com.nawelny.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

const val SUPPORT_EMAIL = "waleedmmh789@gmail.com"

class Sec(val h: String, val lines: List<String>)

@Composable
fun InfoScreen(title: String, secs: List<Sec>, hub: Hub, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar(title, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            secs.forEach { s ->
                Text(s.h, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Blue,
                    modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
                s.lines.forEach { Text(it, Modifier.padding(vertical = 3.dp), lineHeight = 22.sp) }
            }
            Spacer(Modifier.height(20.dp))
            OutlinedButton({ hub.openSupport() }) { Text("✉️ تواصل مع الدعم: $SUPPORT_EMAIL") }
            Spacer(Modifier.height(28.dp))
        }
    }
}

val ABOUT = listOf(
    Sec("ما هو ناولني؟", listOf(
        "ناولني تطبيق لنقل الملفات والتواصل بين الهواتف القريبة من بعضها، مباشرةً ودون الحاجة إلى إنترنت أو باقة بيانات.",
        "يعتمد على خدمة Nearby Connections من Google عبر البلوتوث والواي فاي بين الأجهزة، دون المرور بأي خادم."
    )),
    Sec("ماذا يقدّم؟", listOf(
        "• إرسال واستلام الصور والفيديوهات والموسيقى والمستندات وأي ملف.",
        "• إرسال التطبيقات (APK) واستلامها، ثم تثبيتها من التنزيلات أو مدير الملفات.",
        "• الاتصال بأكثر من هاتف في الوقت نفسه.",
        "• ثلاثة أوضاع للاتصال: «Wi-Fi Direct» اتصال مباشر بين الهواتف بأعلى سرعة نقل وأقل تأخير للصوت، و«سريع» و«عدة أجهزة» عبر Nearby. يجب أن يكون الجهازان على نفس الوضع.",
        "• رسائل نصية بين الأجهزة المتصلة، مع نسخ النص ولصقه وحذف الرسائل وفتح الروابط بنقرة.",
        "• مكالمات صوتية مباشرة بين الأجهزة دون إنترنت، مع كتم الميكروفون وتبديل مكبّر الصوت وإضافة أجهزة أثناء المكالمة.",
        "• الاتصال برقم الجهاز المكوّن من 6 أرقام أو بمسح رمز QR.",
        "• توزيع الملفات المستلمة تلقائياً في مكانها الطبيعي: الصور في معرض الصور، والفيديو في معرض الفيديو، والموسيقى والمستندات في مجلداتها، وباقي الملفات في التنزيلات.",
        "• مشاركة رابط التطبيق على Google Play بأي وسيلة، وإرسال الملفات عبر مشاركة البلوتوث الخاصة بالنظام.",
        "• نغمات للمكالمات والرسائل، ومظهر كلاسيكي مريح للعين مع وضع داكن."
    )),
    Sec("كيف تستخدمه؟", listOf(
        "1. شغّل البلوتوث والواي فاي وخدمة الموقع على الهاتفين، وافتح ناولني عليهما.",
        "2. على الهاتف المُرسِل اضغط «إرسال»، اختر الملفات ثم «التالي».",
        "3. اختر الجهاز القريب من القائمة، أو أدخل رقمه، أو امسح رمز QR الخاص به، وتأكد من تطابق رمز التحقق على الجهازين.",
        "4. على الهاتف المستقبِل اضغط «استلام» ووافق على الملفات الواردة.",
        "5. تجد كل ما استلمته في «ملفات» داخل التطبيق، مصنّفاً حسب النوع."
    )),
    Sec("المسافة والأداء", listOf(
        "المدى يتوقف على الهاتفين والعوائق والوسيلة التي يختارها النظام تلقائياً. عبر البلوتوث يكون المدى عادةً بضعة أمتار، وعند التحويل إلى الواي فاي يزداد في الأماكن المفتوحة إلى عشرات الأمتار، وقد يقترب من 100 متر مع رؤية مباشرة وبلا جدران، دون ضمان لذلك.",
        "لأفضل أداء: قرّب الهاتفين قدر الإمكان، وأبقِ الواي فاي مفتوحاً، وتجنّب العوائق السميكة.",
        "أثناء الاتصال يعمل التطبيق بإشعار دائم ويُبقي الواي فاي في وضع الأداء العالي لتقليل الانقطاع."
    )),
    Sec("الدعم الفني", listOf(
        "للاستفسار أو الإبلاغ عن مشكلة أو اقتراح ميزة، راسلنا على: waleedmmh789@gmail.com"
    ))
)

val PRIVACY = listOf(
    Sec("مقدمة", listOf(
        "خصوصيتك مهمة. ناولني يعمل مباشرةً بين الهواتف، ولا نملك خوادم تستقبل بياناتك، ولا ننشئ حسابات للمستخدمين.",
        "توضح هذه السياسة ما يتعامل معه التطبيق وكيف نحميه. آخر تحديث: 27 نوفمبر 2026."
    )),
    Sec("ما الذي يتعامل معه التطبيق؟", listOf(
        "• اسم جهازك ورقمه (6 أرقام): يظهران للأجهزة القريبة التي تشغّل ناولني فقط، ويمكنك تغيير الاسم من الإعدادات.",
        "• الملفات والرسائل والصوت الذي ترسله: تنتقل مباشرةً إلى الأجهزة التي تقبل الاتصال بها فقط، ولا تمر بأي خادم تابع لنا.",
        "• سجل الرسائل النصية وقائمة الملفات المستلمة: يُحفظان على جهازك فقط. يمكنك حذف أي رسالة أو مسح كل الرسائل من شاشة الرسائل نفسها، أو مسح السجل من الإعدادات.",
        "• الحافظة: عند الضغط على «نسخ» يضع التطبيق النص المختار في الحافظة، وعند الضغط على «لصق» يقرأ الحافظة مرة واحدة ليضع نصها في خانة الرسالة. لا يقرأ التطبيق الحافظة في أي وقت آخر.",
        "• التقييم: تظهر شاشة تقييم عند أول فتح ثم كل 3 أيام حتى تقيّم. نحفظ على جهازك فقط تاريخ آخر ظهور وهل قيّمت. زر التقييم يفتح صفحة التطبيق في Google Play ويتم التقييم هناك وفق سياسات Google، ولا يصلنا منه أي بيان عنك.",
        "• الملفات المستلمة: تُحفظ في مجلدات جهازك (الصور، الفيديو، الموسيقى، المستندات، التنزيلات) داخل مجلد «ناولني»، وتبقى لك تتحكم فيها. لا يحتفظ التطبيق بنسخ منها داخل ملفاته، وتُحذف أي نسخة مؤقتة بعد انتهاء النقل."
    )),
    Sec("ما الذي لا نفعله؟", listOf(
        "• لا نجمع بيانات شخصية بأنفسنا، ولا نملك خوادم تستقبل ملفاتك أو رسائلك أو مكالماتك.",
        "• لا نستخدم أدوات تحليل أو تتبّع خاصة بنا (الإعلانات من Google AdMob موضّحة أدناه).",
        "• لا نبيع بياناتك ولا نشاركها مع أطراف ثالثة.",
        "• لا نسجّل المكالمات ولا نحتفظ بنسخة منها."
    )),
    Sec("الأذونات ولماذا يطلبها التطبيق", listOf(
        "• الموقع والأجهزة القريبة والبلوتوث والواي فاي: يشترطها نظام أندرويد للبحث عن الأجهزة القريبة والاتصال بها. لا يقرأ التطبيق موقعك الجغرافي ولا يحفظه.",
        "• الميكروفون: لإجراء المكالمات الصوتية فقط، ولا يعمل إلا أثناء المكالمة.",
        "• الصور والفيديو والموسيقى (أو التخزين في الإصدارات القديمة): لعرض ملفاتك لتختار ما ترسله.",
        "• الإشعارات: للتنبيه بالرسائل والمكالمات وطلبات الاتصال.",
        "• تثبيت التطبيقات: لا يطلب التطبيق إذن التثبيت. لتثبيت ملف APK مستلم تفتحه بنفسك من التنزيلات أو مدير الملفات.",
        "• الشبكة المحلية: في وضع Wi-Fi Direct يتصل الجهازان ببعضهما مباشرةً عبر شبكة محلية بينهما فقط، ولا يُرسل أي شيء إلى الإنترنت.",
        "• الخدمة التي تعمل في المقدمة: لإبقاء الاتصال والمكالمة والنقل شغّالة أثناء استخدام تطبيقات أخرى.",
        "• نافذة صورة داخل صورة: عند مغادرة التطبيق أثناء مكالمة تستمر المكالمة في نافذة صغيرة. لا تجمع هذه الميزة أي بيانات.",
        "• مسح رمز QR يتم عبر خدمات Google Play، ولا يطلب ناولني إذن الكاميرا بنفسه."
    )),
    Sec("خدمات Google", listOf(
        "يستخدم التطبيق خدمات من Google Play Services: Nearby Connections لاكتشاف الأجهزة ونقل البيانات، وماسح الرموز (Code Scanner)، وGoogle AdMob لعرض الإعلانات. تخضع هذه الخدمات لسياسات Google وشروطها."
    )),
    Sec("الإعلانات (Google AdMob)", listOf(
        "يعرض التطبيق إعلانات عبر Google AdMob (بانر دائم في الشاشات، وإعلان بيني بعد كل مشاركة ملفات مكتملة وعند الرجوع من بعض الشاشات، وإعلان بمكافأة).",
        "يطلب التطبيق إذن معرّف الإعلانات (AD_ID) لعرض الإعلانات. قد تستخدم Google ومشغّلو الإعلانات معرّف الإعلانات (Advertising ID) ومعلومات الجهاز والإعلان لعرض إعلانات وقياس أدائها، وفق سياسة خصوصية Google. لا يشارك ناولني ملفاتك ولا رسائلك ولا مكالماتك ولا أرقام الأجهزة مع أي جهة إعلانية.",
        "فتح الرسائل والمكالمات لمدة 15 دقيقة يتم بعد مشاهدة إعلان بمكافأة بموافقتك.",
        "يمكنك إعادة ضبط معرّف الإعلانات أو إيقاف تخصيص الإعلانات من إعدادات حساب Google على هاتفك."
    )),
    Sec("الأمان", listOf(
        "• لا يتم الاتصال إلا بعد موافقتك، ويظهر رمز تحقق على الجهازين لتتأكد أنك تتصل بالجهاز الصحيح.",
        "• لا تقبل الاتصال أو الملفات من أشخاص لا تعرفهم.",
        "• تثبيت أي تطبيق مستلم يحتاج موافقتك، فلا تثبّت إلا من مصدر تثق به."
    )),
    Sec("الاحتفاظ بالبيانات وحذفها", listOf(
        "• يمكنك حذف الرسائل من شاشة الرسائل، أو سجل الرسائل والملفات من الإعدادات، في أي وقت.",
        "• إلغاء تثبيت التطبيق يحذف بياناته من جهازك. أما الملفات التي استلمتها فتبقى في مجلداتها حتى تحذفها بنفسك."
    )),
    Sec("الأطفال", listOf(
        "التطبيق غير موجّه للأطفال دون 13 عاماً، ولا نجمع عمداً أي معلومات عنهم."
    )),
    Sec("التغييرات على هذه السياسة", listOf(
        "قد نحدّث هذه السياسة عند إضافة ميزات جديدة، وسنعرض تاريخ آخر تحديث في أعلاها."
    )),
    Sec("التواصل", listOf(
        "لأي سؤال حول الخصوصية: waleedmmh789@gmail.com"
    ))
)

val ABOUT_EN = listOf(
    Sec("What is Nawelny?", listOf(
        "Nawelny transfers files and lets you communicate between nearby phones — directly, with no internet or data plan.",
        "It uses Google’s Nearby Connections over Bluetooth and Wi-Fi between devices, without passing through any server."
    )),
    Sec("What does it offer?", listOf(
        "• Send and receive photos, videos, music, documents and any file.",
        "• Send and receive apps (APK), then install them from Downloads or a file manager.",
        "• Connect to several phones at the same time.",
        "• Three connection modes: “Wi-Fi Direct” (direct phone-to-phone link with the highest transfer speed and lowest audio delay), and “Fast” and “Multi-device” over Nearby. Both devices must use the same mode.",
        "• Text messages between connected devices, with copy, paste, delete and one-tap links.",
        "• Direct voice calls between devices without internet, with mute, speaker toggle and adding devices during a call.",
        "• Connect using the 6-digit device code or by scanning a QR code.",
        "• Received files are sorted automatically: photos in the photo gallery, videos in the video gallery, music and documents in their folders, and other files in Downloads.",
        "• Share the app’s Google Play link by any means, and send files through the system’s Bluetooth sharing.",
        "• Call and message tones, and a comfortable classic look with dark mode and a light/dark switch."
    )),
    Sec("How to use it", listOf(
        "1. Turn on Bluetooth, Wi-Fi and Location on both phones, and open Nawelny on both.",
        "2. On the sending phone tap “Send”, choose the files, then “Next”.",
        "3. Pick the nearby device from the list, or enter its code, or scan its QR code, and make sure the verification code matches on both devices.",
        "4. On the receiving phone tap “Receive” and accept the incoming files.",
        "5. Everything you received is in “Files” inside the app, sorted by type."
    )),
    Sec("Range and performance", listOf(
        "Range depends on the phones, obstacles and the method the system picks automatically. Over Bluetooth it is usually a few meters; when switched to Wi-Fi it grows to tens of meters in open spaces, and may approach 100 meters with a clear line of sight and no walls, though that isn’t guaranteed.",
        "For best performance: keep the phones as close as possible, keep Wi-Fi on, and avoid thick obstacles.",
        "While connected the app runs with a persistent notification and keeps Wi-Fi in high-performance mode to reduce drops."
    )),
    Sec("Support", listOf(
        "For questions, bug reports or feature suggestions, email us at: waleedmmh789@gmail.com"
    ))
)

val PRIVACY_EN = listOf(
    Sec("Introduction", listOf(
        "Your privacy matters. Nawelny works directly between phones; we have no servers that receive your data and we don’t create user accounts.",
        "This policy explains what the app handles and how we protect it. Last updated: November 27, 2026."
    )),
    Sec("What does the app handle?", listOf(
        "• Your device name and code (6 digits): visible only to nearby devices running Nawelny. You can change the name in Settings.",
        "• Files, messages and audio you send: they travel directly to the devices that accept the connection only, and never pass through any server of ours.",
        "• Text message history and the received-files list: stored on your device only. You can delete any message or clear all messages from the Messages screen itself, or clear the history from Settings.",
        "• Clipboard: when you tap “Copy” the app puts the chosen text on the clipboard, and when you tap “Paste” it reads the clipboard once to place its text into the message box. The app doesn’t read the clipboard at any other time.",
        "• Rating: a rating prompt appears on first launch and then every 3 days until you rate. We store only the last-shown date and whether you rated, on your device. The rating button opens the app’s page on Google Play, where rating happens under Google’s policies, and nothing about you reaches us from it.",
        "• Received files: saved in your device’s folders (Photos, Videos, Music, Documents, Downloads) inside a “Nawelny” folder, and remain under your control. The app keeps no copies of them in its own files, and any temporary copy is deleted after the transfer ends."
    )),
    Sec("What we don’t do", listOf(
        "• We don’t collect personal data ourselves, and we have no servers that receive your files, messages or calls.",
        "• We don’t use our own analytics or tracking tools (Google AdMob ads are explained below).",
        "• We don’t sell your data or share it with third parties.",
        "• We don’t record calls or keep a copy of them."
    )),
    Sec("Permissions and why the app requests them", listOf(
        "• Location, Nearby devices, Bluetooth and Wi-Fi: required by Android to discover and connect to nearby devices. The app doesn’t read or store your geographic location.",
        "• Microphone: for voice calls only, and active only during a call.",
        "• Photos, videos and music (or storage on older versions): to show your files so you can choose what to send.",
        "• Notifications: to alert you to messages, calls and connection requests.",
        "• Installing apps: the app doesn’t request the install permission. To install a received APK you open it yourself from Downloads or a file manager.",
        "• Local network: in Wi-Fi Direct mode the two devices connect directly over a local network between them only, and nothing is sent to the internet.",
        "• Foreground service: to keep the connection, call and transfer running while you use other apps.",
        "• Picture-in-picture: when you leave the app during a call, the call continues in a small window. This feature collects no data.",
        "• QR scanning is done through Google Play services, and Nawelny doesn’t request the camera permission itself."
    )),
    Sec("Google services", listOf(
        "The app uses Google Play services: Nearby Connections for device discovery and data transfer, the Code Scanner, and Google AdMob for ads. These services are subject to Google’s policies and terms."
    )),
    Sec("Ads (Google AdMob)", listOf(
        "The app shows ads through Google AdMob (a persistent banner on screens, an interstitial after each completed file share and when returning from some screens, and a rewarded ad).",
        "The app requests the advertising ID permission (AD_ID) to show ads. Google and ad operators may use the Advertising ID and device and ad information to show ads and measure their performance, under Google’s privacy policy. Nawelny doesn’t share your files, messages, calls or device codes with any advertiser.",
        "Unlocking messages and calls for 15 minutes happens after you choose to watch a rewarded ad.",
        "You can reset your advertising ID or turn off ad personalization from your phone’s Google account settings."
    )),
    Sec("Security", listOf(
        "• A connection is made only after your approval, and a verification code appears on both devices so you can be sure you’re connecting to the right one.",
        "• Don’t accept connections or files from people you don’t know.",
        "• Installing any received app needs your approval, so install only from a source you trust."
    )),
    Sec("Data retention and deletion", listOf(
        "• You can delete messages from the Messages screen, or the messages and files history from Settings, at any time.",
        "• Uninstalling the app deletes its data from your device. Files you received stay in their folders until you delete them yourself."
    )),
    Sec("Children", listOf(
        "The app isn’t directed to children under 13, and we don’t knowingly collect any information about them."
    )),
    Sec("Changes to this policy", listOf(
        "We may update this policy when new features are added, and the last-updated date will be shown at the top."
    )),
    Sec("Contact", listOf(
        "For any privacy question: waleedmmh789@gmail.com"
    ))
)
