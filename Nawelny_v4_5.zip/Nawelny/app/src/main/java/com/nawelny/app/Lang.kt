package com.nawelny.app

import android.content.Context
import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** لغة التطبيق: عربي (افتراضي لمن لغة جهازه عربية) أو إنجليزي. تُحفظ في التفضيلات. */
object Lang {
    var en by mutableStateOf(false)
        private set

    fun init(c: Context) {
        val sp = c.getSharedPreferences("nawelny_lang", Context.MODE_PRIVATE)
        en = if (sp.contains("en")) sp.getBoolean("en", false) else Locale.getDefault().language != "ar"
    }

    fun set(c: Context, english: Boolean) {
        en = english
        runCatching { c.getSharedPreferences("nawelny_lang", Context.MODE_PRIVATE).edit().putBoolean("en", english).apply() }
    }
}

private val AR_ANY = Regex("[\u0600-\u06FF]")
private const val LB = "(?<![\u0621-\u064A])"
private const val RB = "(?![\u0621-\u064A])"

private val RAW = listOf(
    "لم تبدأ التهيئة بعد" to "Not initialized yet",
    "التهيئة" to "Init",
    "تمت ✅" to "Done ✅",
    "البيني" to "Interstitial",
    "جاهز ✅" to "Ready ✅",
    "المكافأة" to "Rewarded",
    "البانر" to "Banner",
    "ظهر ✅" to "Shown ✅",
    "⚡ سريع" to "⚡ Fast",
    "👥 عدة أجهزة" to "👥 Multi-device",
    "Wi-Fi Direct بأعلى سرعة. اضغط على الجهاز ثم يوافق الطرف الآخر. لا يدعم الرقم/QR، وقد ينقطع الإنترنت مؤقتاً." to "Wi-Fi Direct at top speed. Tap a device, then the other side accepts. No code/QR support, and the internet may drop temporarily.",
    "جهاز واحد بسرعة عالية. يجب أن يكون الجهاز الآخر على نفس الوضع." to "One device at high speed. The other device must use the same mode.",
    "عدة أجهزة معاً بسرعة أقل. يجب أن يكون الجهاز الآخر على نفس الوضع." to "Several devices at once, at lower speed. The other device must use the same mode.",
    "يلزم السماح بالأذونات ليعمل التطبيق" to "Please grant the permissions so the app can work",
    "اضغط على جهاز للاتصال به" to "Tap a device to connect",
    "في انتظار المرسل… افتح «إرسال» على الجهاز الآخر" to "Waiting for the sender… open “Send” on the other device",
    "جارٍ البحث عن أجهزة قريبة… افتح «استلام» على الجهاز الآخر" to "Searching for nearby devices… open “Receive” on the other device",
    "⚠️ فشل البحث عن الأجهزة" to "⚠️ Device search failed",
    "⚠️ فشل الاتصال" to "⚠️ Connection failed",
    "عرض QR" to "Show QR",
    "إخفاء QR" to "Hide QR",
    "مسح QR" to "Scan QR",
    "بلوتوث" to "Bluetooth",
    "إعادة البحث" to "Rescan",
    "رقم جهازك — أعطه للطرف الآخر" to "Your device code — give it to the other side",
    "📋 نسخ" to "📋 Copy",
    "اتصال برقم الجهاز" to "Connect by device code",
    "اتصال" to "Connect",
    "إلغاء" to "Cancel",
    "💬 رسائل نصية" to "💬 Text messages",
    "📞 مكالمات" to "📞 Calls",
    " ملف جاهز للإرسال — اتصل بجهاز وسيبدأ الإرسال تلقائياً" to " file(s) ready to send — connect to a device and sending starts automatically",
    "الأجهزة المتصلة" to "Connected devices",
    "لا يوجد جهاز متصل" to "No connected device",
    "🟢 متصل" to "🟢 Connected",
    "قطع" to "Disconnect",
    "أجهزة قريبة أخرى" to "Other nearby devices",
    "متاح — اضغط للاتصال" to "Available — tap to connect",
    "معرض الصور" to "Photo gallery",
    "معرض الفيديو" to "Video gallery",
    "الموسيقى" to "Music",
    "المستندات" to "Documents",
    "التنزيلات" to "Downloads",
    "ناولني-" to "Nawelny-",
    "يعمل ✅" to "Working ✅",
    "فشل ❌ الإذن ناقص" to "Failed ❌ missing permission",
    "فشل ❌" to "Failed ❌",
    "اتصال Wi-Fi Direct مع" to "Wi-Fi Direct connection with",
    "انقطع الاتصال بـ" to "Disconnected from",
    "ملف" to "File",
    "⚠️ لم يكتمل إرسال:" to "⚠️ Sending incomplete:",
    "⚠️ لم يكتمل:" to "⚠️ Incomplete:",
    "فشل الإرسال:" to "Send failed:",
    "جهاز قريب" to "Nearby device",
    "الحافظة فارغة" to "Clipboard is empty",
    "طلب اتصال:" to "Connection request:",
    "طلب اتصال" to "Connection request",
    "يريد الاتصال بك" to "wants to connect to you",
    "نتيجة الاتصال:" to "Connection result:",
    "فشل الاتصال:" to "Connection failed:",
    "فشل الاتصال" to "Connection failed",
    "وُجد جهاز:" to "Device found:",
    "تم العثور على" to "Found",
    "— جارٍ الاتصال…" to "— connecting…",
    "أندرويد" to "Android",
    "موقع تقريبي" to "Approx. location",
    "موقع دقيق" to "Precise location",
    "بلوتوث مسح" to "Bluetooth scan",
    "بلوتوث بث" to "Bluetooth advertise",
    "بلوتوث اتصال" to "Bluetooth connect",
    "أجهزة قريبة" to "Nearby devices",
    "خدمة الموقع (GPS)" to "Location service (GPS)",
    "❌ مغلقة" to "❌ Off",
    "سماح النظام للموقع:" to "System location permission:",
    "❌ مرفوض من النظام" to "❌ Denied by system",
    "فعّل الموقع (GPS) ثم ارجع للتطبيق" to "Turn on Location (GPS), then return to the app",
    "فعّل البلوتوث ثم ارجع للتطبيق" to "Turn on Bluetooth, then return to the app",
    "فعّل الواي فاي ثم ارجع للتطبيق" to "Turn on Wi-Fi, then return to the app",
    "اسمح بإذن «الموقع» ثم ارجع للتطبيق" to "Allow the “Location” permission, then return to the app",
    "الاتصال بالرقم أو QR غير متاح في وضع Wi-Fi Direct — اختر الجهاز من القائمة" to "Connecting by code or QR isn’t available in Wi-Fi Direct mode — pick the device from the list",
    "الرقم يتكون من 6 أرقام" to "The code has 6 digits",
    "هذا رقم جهازك أنت" to "That is your own device code",
    "جارٍ الاتصال بـ" to "Connecting to",
    "جارٍ البحث عن الجهاز" to "Searching for device",
    "تأكد أن ناولني مفتوح عليه" to "make sure Nawelny is open on it",
    "رمز QR غير صالح لـ ناولني" to "Invalid QR code for Nawelny",
    "دعم تطبيق ناولني (الإصدار" to "Nawelny app support (version",
    "دعوة Wi-Fi Direct إلى" to "Wi-Fi Direct invitation to",
    "بانتظار موافقة الجهاز الآخر على الدعوة…" to "Waiting for the other device to accept the invitation…",
    "فشل طلب الاتصال:" to "Connection request failed:",
    "تعذر الاتصال بـ" to "Couldn’t connect to",
    "إعادة محاولة الاتصال بـ" to "Retrying connection to",
    "فشل قبول الاتصال:" to "Failed to accept connection:",
    "فشل القبول:" to "Accept failed:",
    "أنا" to "Me",
    "رسالة من" to "Message from",
    "ملف وارد من" to "Incoming file from",
    "الرسائل" to "Messages",
    "المكالمات" to "Calls",
    "تنبيهات ناولني" to "Nawelny alerts",
    "🚫 رفضت:" to "🚫 Rejected:",
    "اختر جهازاً متصلاً أولاً" to "Choose a connected device first",
    "الرسالة أطول من المسموح" to "The message is too long",
    "⚠️ تعذر فتح الملف:" to "⚠️ Couldn’t open file:",
    "،" to ",",
    "فشل إرسال الملف:" to "File send failed:",
    "⚠️ أُلغي:" to "⚠️ Cancelled:",
    "إرسال عبر البلوتوث" to "Send via Bluetooth",
    "تعذر فتح البلوتوث، تأكد أنه مفعّل" to "Couldn’t open Bluetooth, make sure it is on",
    "اختر الجهاز الآخر من القائمة — يجب أن يكون ضغط «استلام بلوتوث» ليظهر" to "Pick the other device from the list — it must have tapped “Bluetooth receive” to appear",
    "تعذر تجهيز ملف التطبيق" to "Couldn’t prepare the app file",
    "اسمح للتطبيق بإذن «الأجهزة القريبة» ثم اضغط استلام بلوتوث مرة أخرى" to "Allow the “Nearby devices” permission, then tap Bluetooth receive again",
    "وافق على جعل جهازك ظاهراً 5 دقائق، ثم اختره من الهاتف المُرسِل" to "Agree to make your device visible for 5 minutes, then pick it from the sending phone",
    "هذه نسخة مثبّتة من متجر (Split APK) وقد لا تعمل وحدها على جهاز آخر" to "This is a store-installed copy (Split APK) and may not work alone on another device",
    "حمّل تطبيق ناولني لنقل الملفات بين الهواتف بدون إنترنت:" to "Get the Nawelny app to transfer files between phones without internet:",
    "ناولني" to "Nawelny",
    "مشاركة تطبيق ناولني" to "Share the Nawelny app",
    "تعذر فتح قائمة المشاركة" to "Couldn’t open the share menu",
    "لا يوجد تطبيق لفتح هذا الملف" to "No app to open this file",
    "لا يوجد متصفح لفتح الرابط" to "No browser to open the link",
    "تم النسخ" to "Copied",
    "للتثبيت: افتح ملف التطبيق من «التنزيلات» أو من مدير الملفات واضغط تثبيت" to "To install: open the app file from “Downloads” or a file manager and tap Install",
    "إذن الميكروفون مطلوب للمكالمات" to "Microphone permission is required for calls",
    "مكالمة واردة" to "Incoming call",
    "لم يرد على المكالمة" to "didn’t answer the call",
    "⚠️ تعذر حفظ:" to "⚠️ Couldn’t save:",
    "م.ب" to "MB",
    "ك.ب" to "KB",
    "رمز التحقق:" to "Verification code:",
    "(يجب أن يتطابق على الجهازين)" to "(must match on both devices)",
    "قبول" to "Accept",
    "رفض" to "Decline",
    "📞 مكالمة واردة" to "📞 Incoming call",
    "شاهد الإعلان للرد على المكالمة، تعذر تحميله الآن" to "Watch the ad to answer the call; it couldn’t be loaded right now",
    "رد" to "Answer",
    "إرسال" to "Send",
    "استلام" to "Receive",
    "عن ناولني" to "About Nawelny",
    "سياسة الخصوصية" to "Privacy policy",
    "رسائل" to "Messages",
    "مكالمات" to "Calls",
    "مكالمة" to "Call",
    "إنهاء" to "End",
    "تعذر فتح الماسح" to "Couldn’t open the scanner",
    "⭐ قيّم ناولني" to "⭐ Rate Nawelny",
    "رأيك يهمنا ويساعدنا نطوّر التطبيق. اختر عدد النجوم ثم اكتب تقييمك في Google Play." to "Your opinion matters and helps us improve the app. Choose the number of stars, then write your review on Google Play.",
    "قيّم الآن" to "Rate now",
    "لاحقاً" to "Later",
    "لا توجد أجهزة متصلة" to "No connected devices",
    "إلى: " to "To: ",
    "الكل" to "All",
    "الإعدادات" to "Settings",
    "اسم جهازك" to "Your device name",
    "المظهر" to "Appearance",
    "اللغة" to "Language",
    "تلقائي" to "Auto",
    "فاتح" to "Light",
    "داكن" to "Dark",
    "🔔 نغمات المكالمات والرسائل" to "🔔 Call & message tones",
    "حالة الإعلانات:" to "Ads status:",
    "🗑 حذف سجل الرسائل والملفات" to "🗑 Delete messages & files history",
    "ℹ️ عن ناولني" to "ℹ️ About Nawelny",
    "🔒 سياسة الخصوصية" to "🔒 Privacy policy",
    "✉️ الدعم الفني" to "✉️ Support",
    "إخفاء التفاصيل التقنية" to "Hide technical details",
    "🔧 التفاصيل التقنية" to "🔧 Technical details",
    "البث:" to "Advertising:",
    "البحث:" to "Discovery:",
    "الإصدار" to "Version",
    "حفظ" to "Save",
    "إغلاق" to "Close",
    "🎁 افتح" to "🎁 Unlock",
    "الرسائل والمكالمات تُفتح بعد مشاهدة إعلان قصير." to "Messages and calls unlock after watching a short ad.",
    "جاري تحميل الإعلان..." to "Loading the ad...",
    "تعذر تحميل الإعلان. تأكد من الإنترنت وحاول بعد لحظات" to "Couldn’t load the ad. Check your internet and try again shortly",
    "مشاهدة الإعلان" to "Watch ad",
    "ملفات" to "Files",
    "لا يوجد — اضغط «استلام» أو «إرسال» للاتصال بجهاز" to "None — tap “Receive” or “Send” to connect to a device",
    "إعلان" to "Ad",
    "المزيد" to "More",
    "🔢 رقم جهازك" to "🔢 Your device code",
    "الاسم:" to "Name:",
    "📲 شارك التطبيق" to "📲 Share the app",
    "🔵 بلوتوث" to "🔵 Bluetooth",
    "تحديد الملفات" to "Select files",
    "موسيقى" to "Music",
    "صور" to "Photos",
    "تطبيقات" to "Apps",
    "فيديوهات" to "Videos",
    "🎬 اختيار فيديوهات من المعرض" to "🎬 Pick videos from the gallery",
    "🖼 اختيار صور من المعرض" to "🖼 Pick photos from the gallery",
    "📁 تصفح الملفات واختيارها" to "📁 Browse and pick files",
    "اختر من معرضك بأمان — لا يحتاج إذناً" to "Pick from your gallery safely — no permission needed",
    "يلزم السماح بالوصول للوسائط لعرضها" to "Allow media access to display it",
    "السماح" to "Allow",
    "أو اختر من المعرض بدون إذن" to "Or pick from the gallery without permission",
    "فتح إعدادات التطبيق" to "Open app settings",
    "لا يوجد شيء هنا بعد" to "Nothing here yet",
    "لا يوجد شيء هنا" to "Nothing here",
    "تم تحديد" to "Selected",
    " ملف (ملفات)" to " file(s)",
    "التالي" to "Next",
    "مستندات" to "Documents",
    "ملفات أخرى" to "Other files",
    "ملفاتي المستلمة" to "My received files",
    "^من " to "From ",
    "⬇️ تثبيت" to "⬇️ Install",
    "ملف AAB لا يُثبَّت مباشرة على الهاتف" to "AAB files can’t be installed directly on the phone",
    "فتح" to "Open",
    "مسح كل الرسائل؟" to "Clear all messages?",
    "سيتم حذف كل الرسائل النصية من هذا الجهاز فقط." to "All text messages will be deleted from this device only.",
    "مسح الكل" to "Clear all",
    "حذف الرسالة؟" to "Delete message?",
    "حذف" to "Delete",
    "🗑 مسح الكل" to "🗑 Clear all",
    "🔗 فتح" to "🔗 Open",
    "🗑 حذف" to "🗑 Delete",
    "اكتب رسالة" to "Type a message",
    "📥 لصق" to "📥 Paste",
    "➕ إضافة المحددين للمكالمة" to "➕ Add selected to the call",
    "📞 اتصال صوتي بالمحدد" to "📞 Voice call selected",
    "🎙 مكالمة جارية" to "🎙 Call in progress",
    "⏳ جارٍ الاتصال بـ" to "⏳ Calling",
    "🔇 مكتوم" to "🔇 Muted",
    "🎙 الميكروفون" to "🎙 Microphone",
    "🔊 مكبّر الصوت" to "🔊 Speaker",
    "📱 السماعة" to "📱 Earpiece",
    "إنهاء المكالمة" to "End call",
    "المكالمة تعمل مباشرة بين الأجهزة القريبة بدون إنترنت." to "Calls work directly between nearby devices without internet.",
    "مكالمة صوتية جارية" to "Voice call in progress",
    "ناولني متصل" to "Nawelny connected",
    "اضغط للعودة للمكالمة" to "Tap to return to the call",
    "التبادل مستمر مع الأجهزة القريبة" to "Exchange is ongoing with nearby devices",
    "خطأ داخلي" to "Internal error",
    "الجهاز لا يدعم Wi-Fi Direct" to "This device doesn’t support Wi-Fi Direct",
    "مشغول" to "Busy",
    "Wi-Fi Direct غير مفعّل — افتح الواي فاي" to "Wi-Fi Direct is off — turn on Wi-Fi",
    "جهاز" to "Device",
    "تعذر البحث" to "Search failed",
    "رمز" to "Code",
    "فشل" to "Failed",
    "✉️ تواصل مع الدعم:" to "✉️ Contact support:"
)

private val EXACT: Map<String, String> = RAW.filter { !it.first.startsWith("^") }.toMap()

/** عبارات الترجمة مرتبة من الأطول للأقصر، مع حدود كلمات عربية حتى لا تُستبدل أجزاء من كلمات. */
private val RULES: List<Pair<Regex, String>> = RAW.sortedByDescending { it.first.length }.map { (a, b) ->
    val anchored = a.startsWith("^")
    val key = if (anchored) a.substring(1) else a
    Regex((if (anchored) "^" else LB) + Regex.escape(key) + RB) to b
}

private val cache = ConcurrentHashMap<String, String>()

/** يترجم النص للإنجليزية عند اختيار الإنجليزية؛ الأجزاء الديناميكية (أسماء/أرقام) تبقى كما هي. */
fun tr(s: String): String {
    if (!Lang.en || !AR_ANY.containsMatchIn(s)) return s
    EXACT[s]?.let { return it }
    cache[s]?.let { return it }
    var r = s
    for ((re, b) in RULES) if (re.containsMatchIn(r)) r = re.replace(r) { b }
    if (cache.size > 3000) cache.clear()
    cache[s] = r
    return r
}

/** يحلّ محل Text من material3 داخل هذه الحزمة: يمرّر النص عبر tr() تلقائياً. */
@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: ((TextLayoutResult) -> Unit)? = null,
    style: TextStyle = LocalTextStyle.current
) {
    androidx.compose.material3.Text(
        tr(text), modifier, color, fontSize, fontStyle, fontWeight, fontFamily, letterSpacing, textDecoration,
        textAlign, lineHeight, overflow, softWrap, maxLines, minLines, onTextLayout, style
    )
}
