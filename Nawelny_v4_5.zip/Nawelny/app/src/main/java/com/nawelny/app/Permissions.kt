package com.nawelny.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/** الإذن الذي يشترطه Wi-Fi Direct: NEARBY_WIFI_DEVICES على أندرويد 13+، والموقع الدقيق قبلها. */
fun wifiDirectPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES else Manifest.permission.ACCESS_FINE_LOCATION

fun hasWifiDirectPermission(ctx: Context): Boolean =
    ContextCompat.checkSelfPermission(ctx, wifiDirectPermission()) == PackageManager.PERMISSION_GRANTED

fun hasPermission(ctx: Context, p: String): Boolean =
    ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
