package com.nawelny.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** منطق ظهور شاشة التقييم: أول فتح، ثم كل 3 أيام، ولا تظهر أبداً بعد أن يقيّم المستخدم. */
object Rating {
    private const val PREFS = "nawelny_rating"
    private const val KEY_RATED = "rated"
    private const val KEY_LAST = "last_shown"
    private const val EVERY_MS = 3L * 24 * 60 * 60 * 1000

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun shouldShow(c: Context): Boolean = runCatching {
        val sp = p(c)
        if (sp.getBoolean(KEY_RATED, false)) return false
        val last = sp.getLong(KEY_LAST, 0L)
        last == 0L || System.currentTimeMillis() - last >= EVERY_MS
    }.getOrDefault(false)

    fun markShown(c: Context) { runCatching { p(c).edit().putLong(KEY_LAST, System.currentTimeMillis()).apply() } }
    fun markRated(c: Context) { runCatching { p(c).edit().putBoolean(KEY_RATED, true).apply() } }

    /** يفتح صفحة التطبيق في Google Play لكتابة التقييم. */
    fun openStore(c: Context) {
        val pkg = c.packageName
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { c.startActivity(i) }.onFailure {
            runCatching { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PLAY_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }
}

@Composable
fun RatingDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var stars by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("⭐ قيّم ناولني", fontSize = 18.sp) },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("رأيك يهمنا ويساعدنا نطوّر التطبيق. اختر عدد النجوم ثم اكتب تقييمك في Google Play.",
                    fontSize = 13.sp, textAlign = TextAlign.Center, color = SubC)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (i in 1..5) {
                        Text(if (i <= stars) "★" else "☆", fontSize = 32.sp,
                            color = if (i <= stars) Color(0xFFFFB300) else SubC,
                            modifier = Modifier.clickable { stars = i }.padding(2.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = stars > 0, onClick = {
                Rating.markRated(ctx)      // بعد التقييم لا تظهر الشاشة مرة أخرى
                Rating.openStore(ctx)
                onClose()
            }) { Text("قيّم الآن") }
        },
        dismissButton = { TextButton(onClose) { Text("لاحقاً") } }
    )
}
