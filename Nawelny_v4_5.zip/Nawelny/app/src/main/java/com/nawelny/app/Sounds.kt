package com.nawelny.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.VibrationEffect
import android.os.Vibrator

/** نغمات المكالمات والرسائل. تحترم وضع الصامت/الاهتزاز في الهاتف. */
class Sounds(private val ctx: Context, private val enabled: () -> Boolean) {
    private var ring: MediaPlayer? = null
    private var ringOn = false
    private var back: MediaPlayer? = null
    private val am = ctx.getSystemService(AudioManager::class.java)
    private val vib: Vibrator? = ctx.getSystemService(Vibrator::class.java)

    private fun make(res: Int, loop: Boolean, usage: Int): MediaPlayer? = runCatching {
        val afd = ctx.resources.openRawResourceFd(res)
        MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(usage)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            isLooping = loop
            prepare()
        }
    }.getOrNull()

    /** نغمة مكالمة واردة + اهتزاز. */
    fun startRing() {
        if (ringOn || !enabled()) return
        ringOn = true
        val mode = am.ringerMode
        if (mode == AudioManager.RINGER_MODE_NORMAL) {
            ring = make(R.raw.call_ring, true, AudioAttributes.USAGE_NOTIFICATION_RINGTONE)?.also { it.start() }
        }
        if (mode != AudioManager.RINGER_MODE_SILENT) {
            runCatching { vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 900), 0)) }
        }
    }

    fun stopRing() {
        if (!ringOn) return
        ringOn = false
        ring?.let { runCatching { it.stop() }; it.release() }
        ring = null
        runCatching { vib?.cancel() }
    }

    /** رنين الانتظار عند الاتصال بشخص. */
    fun startRingback() {
        if (back != null || !enabled() || am.ringerMode == AudioManager.RINGER_MODE_SILENT) return
        back = make(R.raw.ringback, true, AudioAttributes.USAGE_VOICE_COMMUNICATION)?.also { it.start() }
    }

    fun stopRingback() {
        back?.let { runCatching { it.stop() }; it.release() }
        back = null
    }

    /** نغمة رسالة نصية واردة. */
    fun message() {
        if (!enabled() || am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val p = make(R.raw.msg_tone, false, AudioAttributes.USAGE_NOTIFICATION) ?: return
        p.setOnCompletionListener { it.release() }
        p.start()
    }
}
