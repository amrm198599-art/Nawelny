package com.nawelny.app

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * صوت المكالمات بإطارات صغيرة (20 ملّي ثانية) تُرسل كرسائل Bytes مباشرة،
 * بدل الـStream الذي كان يتجمّع قبل الإرسال ويسبب تأخيراً.
 * بداية كل إطار بايت واحد = 1 لتمييزه عن الرسائل النصية.
 */
class Voice(ctx: Context, private val send: (List<String>, ByteArray) -> Unit) {
    private val rate = 16000
    private val frameBytes = 640   // 20ms × 16kHz × 2 bytes
    private val am = ctx.getSystemService(AudioManager::class.java)
    private val peers = ConcurrentHashMap.newKeySet<String>()
    private val players = ConcurrentHashMap<String, LinkedBlockingQueue<ByteArray>>()

    @Volatile var muted = false
    @Volatile var active = false
        private set

    fun begin() {
        if (active) return
        active = true
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        setSpeaker(true)
        Thread { recordLoop() }.start()
    }

    @Suppress("DEPRECATION")
    fun setSpeaker(on: Boolean) { am.isSpeakerphoneOn = on }

    /** ابدأ إرسال صوتك لهذا الجهاز. */
    fun addPeer(id: String) { peers.add(id) }

    fun removePeer(id: String) {
        peers.remove(id)
        players.remove(id)?.let { it.clear(); it.offer(ByteArray(0)) }
    }

    fun end() {
        active = false
        peers.clear()
        players.keys.toList().forEach { removePeer(it) }
        am.mode = AudioManager.MODE_NORMAL
        setSpeaker(false)
    }

    @SuppressLint("MissingPermission")
    private fun recordLoop() {
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096) * 2)
        } catch (e: Exception) { return }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return }
        val buf = ByteArray(frameBytes)
        rec.startRecording()
        try {
            while (active) {
                var off = 0
                while (off < frameBytes && active) {
                    val n = rec.read(buf, off, frameBytes - off)
                    if (n <= 0) { Thread.sleep(10); break }
                    off += n
                }
                if (off < frameBytes || muted || peers.isEmpty()) continue
                val frame = ByteArray(frameBytes + 1)
                frame[0] = 1
                System.arraycopy(buf, 0, frame, 1, frameBytes)
                send(peers.toList(), frame)
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
    }

    /** إطار صوت وارد من جهاز (بايت العلامة في أوله). */
    fun playFrame(id: String, data: ByteArray) {
        val q = players.getOrPut(id) { startPlayer(id) }
        if (q.size > 12) q.poll()   // نتخلص من القديم للحفاظ على أقل تأخير
        q.offer(data)
    }

    private fun startPlayer(id: String): LinkedBlockingQueue<ByteArray> {
        val q = LinkedBlockingQueue<ByteArray>()
        Thread {
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(maxOf(min, 3200))
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            track.play()
            try {
                while (players[id] === q) {
                    val f = q.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    if (f.size <= 1) break
                    track.write(f, 1, f.size - 1)
                }
            } catch (e: Exception) {
            } finally {
                runCatching { track.stop() }
                track.release()
            }
        }.start()
        return q
    }
}
