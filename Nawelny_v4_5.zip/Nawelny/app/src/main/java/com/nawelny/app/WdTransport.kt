package com.nawelny.app

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.core.content.ContextCompat
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** أحداث ينقلها وسيط Wi-Fi Direct إلى Hub (قد تأتي من خيوط خلفية). */
interface WdEvents {
    fun identity(): Triple<String, String, String>   // المعرّف الثابت، الاسم، الرقم
    fun onPeers(list: List<Peer>)
    fun onState(ok: Boolean, msg: String)            // حالة البحث
    fun onError(msg: String)
    fun onConnected(id: String, name: String)
    fun onDisconnected(id: String)
    fun onBytes(id: String, data: ByteArray)
    fun onFileProgress(id: String, fid: Long, received: Long)
    fun onFileDone(id: String, fid: Long, file: File)
    fun onFileFailed(id: String, fid: Long)
}

/**
 * اتصال Wi-Fi Direct مباشر (WifiP2pManager) + مقابس TCP.
 * الجهاز الذي يصبح «مالك المجموعة» يستقبل الاتصالات، والباقي يتصل به.
 * شكل الإطار: [الطول 4 بايت][النوع 1 بايت][المحتوى]
 *   النوع 0 = بايتات (رسائل نصية/تحكم/صوت)، 1 = تعريف، 2 = جزء ملف (معرّف 8 بايت + بيانات)،
 *   3 = نهاية ملف، 4 = إلغاء ملف.
 */
class WdTransport(private val ctx: Context, private val ev: WdEvents) {
    private val port = 8988
    private val mgr = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private var channel: WifiP2pManager.Channel? = null
    private var server: ServerSocket? = null
    private val conns = ConcurrentHashMap<String, Conn>()
    private val main = Handler(Looper.getMainLooper())
    private val cancelledFids = ConcurrentHashMap.newKeySet<Long>()
    private val cancelledPairs = ConcurrentHashMap.newKeySet<String>()
    private val ignored = ConcurrentHashMap.newKeySet<String>()
    @Volatile private var running = false
    @Volatile private var connectingToGo = false

    private class Conn(val s: Socket, val out: DataOutputStream, val id: String, val name: String, val clientSide: Boolean) {
        val exec = Executors.newSingleThreadExecutor()

        fun frame(type: Int, fid: Long?, data: ByteArray, off: Int, len: Int): Boolean = try {
            synchronized(out) {
                out.writeInt(1 + (if (fid != null) 8 else 0) + len)
                out.writeByte(type)
                if (fid != null) out.writeLong(fid)
                out.write(data, off, len)
                out.flush()
            }
            true
        } catch (e: IOException) { close(); false }

        fun close() { runCatching { s.close() }; runCatching { exec.shutdownNow() } }
    }

    private fun reasonText(r: Int) = when (r) {
        0 -> "خطأ داخلي (0)"; 1 -> "الجهاز لا يدعم Wi-Fi Direct (1)"; 2 -> "مشغول (2)"; else -> "رمز $r"
    }

    private val receiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(c: Context, i: Intent) {
            val m = mgr ?: return
            val ch = channel ?: return
            when (i.action) {
                WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                    val on = i.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) == WifiP2pManager.WIFI_P2P_STATE_ENABLED
                    if (!on) ev.onState(false, "Wi-Fi Direct غير مفعّل — افتح الواي فاي")
                }
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> runCatching {
                    m.requestPeers(ch) { list ->
                        ev.onPeers(list.deviceList
                            .filter { it.status != WifiP2pDevice.CONNECTED }
                            .filter { it.primaryDeviceType?.startsWith("10-") != false }   // هواتف فقط
                            .map { Peer(it.deviceAddress, it.deviceName ?: "جهاز") })
                    }
                }
                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> runCatching {
                    m.requestConnectionInfo(ch) { info -> onGroup(info) }
                }
            }
        }
    }

    private val rediscover = object : Runnable {
        override fun run() { if (running) { discover(); main.postDelayed(this, 25_000) } }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        val m = mgr
        if (m == null) { ev.onState(false, "الجهاز لا يدعم Wi-Fi Direct"); return }
        if (running) return
        running = true
        channel = m.initialize(ctx, Looper.getMainLooper(), null)
        val f = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        runCatching { channel?.let { m.removeGroup(it, null) } }   // تنظيف مجموعة قديمة
        startServer()
        main.postDelayed({ discover() }, 700)
        main.postDelayed(rediscover, 25_000)
    }

    @SuppressLint("MissingPermission")
    private fun discover() {
        val m = mgr ?: return
        val ch = channel ?: return
        runCatching {
            m.discoverPeers(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { ev.onState(true, "") }
                override fun onFailure(reason: Int) { ev.onState(reason == 2, reasonText(reason)) }
            })
        }.onFailure { ev.onState(false, it.message ?: "تعذر البحث") }
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    fun connectTo(address: String) {
        val m = mgr ?: return
        val ch = channel ?: return
        val cfg = WifiP2pConfig().apply { deviceAddress = address; wps.setup = WpsInfo.PBC }
        runCatching {
            m.connect(ch, cfg, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {}
                override fun onFailure(reason: Int) { ev.onError("فشل الاتصال: " + reasonText(reason)) }
            })
        }.onFailure { ev.onError(it.message ?: "فشل الاتصال") }
    }

    private fun onGroup(info: WifiP2pInfo?) {
        if (info == null || !info.groupFormed || info.isGroupOwner) return   // المالك ينتظر في الخادم
        val host = info.groupOwnerAddress?.hostAddress ?: return
        if (connectingToGo || conns.values.any { it.clientSide }) return
        connectingToGo = true
        Thread {
            try {
                var done = false
                var tries = 0
                while (!done && running && tries < 12) {
                    tries++
                    try {
                        val s = Socket()
                        s.tcpNoDelay = true
                        s.connect(InetSocketAddress(host, port), 3000)
                        done = true
                        handshake(s, true)
                    } catch (e: IOException) {
                        if (!done) Thread.sleep(700)
                    }
                }
            } finally { connectingToGo = false }
        }.start()
    }

    private fun startServer() {
        if (server != null) return
        Thread {
            try {
                val ss = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(port)) }
                server = ss
                while (running) {
                    val s = ss.accept()
                    s.tcpNoDelay = true
                    Thread { handshake(s, false) }.start()
                }
            } catch (e: IOException) {
            }
        }.start()
    }

    private fun handshake(s: Socket, clientSide: Boolean) {
        try {
            val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 64 * 1024))
            val out = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 64 * 1024))
            val (myId, myName, myCode) = ev.identity()
            val hello = "H|$myId|${myName.replace("|", "/")}|$myCode".toByteArray()
            synchronized(out) { out.writeInt(1 + hello.size); out.writeByte(1); out.write(hello); out.flush() }
            s.soTimeout = 8000
            val len = inp.readInt()
            val type = inp.readUnsignedByte()
            if (type != 1 || len < 2 || len > 2000) { s.close(); return }
            val b = ByteArray(len - 1)
            inp.readFully(b)
            val p = String(b).split("|", limit = 4)
            if (p.size < 4 || p[0] != "H") { s.close(); return }
            s.soTimeout = 0
            val c = Conn(s, out, p[1], p[2], clientSide)
            conns.put(p[1], c)?.close()
            ev.onConnected(p[1], p[2])
            readLoop(c, inp)
        } catch (e: IOException) {
            runCatching { s.close() }
        }
    }

    private fun readLoop(c: Conn, inp: DataInputStream) {
        val dir = File(ctx.cacheDir, "in").apply { mkdirs() }
        fun part(fid: Long) = File(dir, "${c.id.take(8)}_$fid.part")
        val outs = HashMap<Long, FileOutputStream>()
        val counts = HashMap<Long, Long>()
        try {
            while (true) {
                val len = inp.readInt()
                if (len < 1 || len > 2_000_000) break
                when (inp.readUnsignedByte()) {
                    0 -> { val b = ByteArray(len - 1); inp.readFully(b); ev.onBytes(c.id, b) }
                    2 -> {
                        val fid = inp.readLong()
                        val b = ByteArray(len - 9)
                        inp.readFully(b)
                        if ("${c.id}:$fid" !in ignored) {
                            val o = outs.getOrPut(fid) { FileOutputStream(part(fid)) }
                            o.write(b)
                            val tot = (counts[fid] ?: 0L) + b.size
                            counts[fid] = tot
                            ev.onFileProgress(c.id, fid, tot)
                        }
                    }
                    3 -> {
                        val fid = inp.readLong()
                        outs.remove(fid)?.close()
                        counts.remove(fid)
                        if (ignored.remove("${c.id}:$fid")) part(fid).delete() else ev.onFileDone(c.id, fid, part(fid))
                    }
                    4 -> {
                        val fid = inp.readLong()
                        outs.remove(fid)?.close()
                        counts.remove(fid)
                        part(fid).delete()
                        ev.onFileFailed(c.id, fid)
                    }
                    else -> inp.skipBytes(len - 1)
                }
            }
        } catch (e: IOException) {
        } finally {
            outs.values.forEach { runCatching { it.close() } }
            c.close()
            if (conns[c.id] === c) {
                conns.remove(c.id)
                ev.onDisconnected(c.id)
                if (conns.isEmpty()) main.postDelayed({
                    if (conns.isEmpty() && running) runCatching { channel?.let { mgr?.removeGroup(it, null) } }
                }, 1500)
            }
        }
    }

    /** يرسل بايتات (رسالة/تحكم/إطار صوت) إلى الأجهزة المحددة، بالترتيب ودون حجب الواجهة. */
    fun send(ids: List<String>, data: ByteArray) {
        ids.forEach { id ->
            val c = conns[id] ?: return@forEach
            runCatching { c.exec.execute { c.frame(0, null, data, 0, data.size) } }
        }
    }

    /** يرسل ملفاً: يبدأ بالرسالة الوصفية ثم الأجزاء ثم علامة النهاية. */
    fun sendFile(
        ids: List<String>, fid: Long, meta: ByteArray, pfd: ParcelFileDescriptor,
        onProgress: (Long) -> Unit, onDone: (ok: List<String>, failed: List<String>) -> Unit
    ) {
        Thread {
            val targets = ids.mapNotNull { conns[it] }.toMutableList()
            val failed = (ids - targets.map { it.id }.toSet()).toMutableList()
            val ok = mutableListOf<String>()
            val metaFailed = targets.filter { !it.frame(0, null, meta, 0, meta.size) }
            targets.removeAll(metaFailed); failed.addAll(metaFailed.map { it.id })
            var total = 0L
            try {
                FileInputStream(pfd.fileDescriptor).use { ins ->
                    val buf = ByteArray(48 * 1024)
                    while (targets.isNotEmpty()) {
                        val n = ins.read(buf)
                        if (n <= 0) break
                        val iter = targets.iterator()
                        while (iter.hasNext()) {
                            val c = iter.next()
                            if (cancelledFids.contains(fid) || cancelledPairs.contains("$fid:${c.id}")) {
                                c.frame(4, fid, buf, 0, 0); iter.remove(); failed.add(c.id)
                            } else if (!c.frame(2, fid, buf, 0, n)) { iter.remove(); failed.add(c.id) }
                        }
                        total += n
                        onProgress(total)
                    }
                }
            } catch (e: IOException) {
                failed.addAll(targets.map { it.id }); targets.clear()
            } finally { runCatching { pfd.close() } }
            targets.forEach { c -> if (c.frame(3, fid, buf0, 0, 0)) ok.add(c.id) else failed.add(c.id) }
            cancelledFids.remove(fid)
            onDone(ok, failed)
        }.start()
    }

    private val buf0 = ByteArray(0)

    fun cancelFile(fid: Long, peer: String? = null) {
        if (peer == null) cancelledFids.add(fid) else cancelledPairs.add("$fid:$peer")
    }

    /** يتجاهل ما تبقى من ملف وارد (رفض أو إلغاء). */
    fun dropIncoming(peer: String, fid: Long) { ignored.add("$peer:$fid") }

    fun disconnect(id: String) { conns[id]?.close() }

    fun stop() {
        if (!running) return
        running = false
        main.removeCallbacks(rediscover)
        runCatching { ctx.unregisterReceiver(receiver) }
        runCatching { channel?.let { mgr?.stopPeerDiscovery(it, null); mgr?.removeGroup(it, null) } }
        val all = conns.values.toList()
        conns.clear()
        all.forEach { it.close() }
        runCatching { server?.close() }
        server = null
        runCatching { if (Build.VERSION.SDK_INT >= 27) channel?.close() }
        channel = null
    }
}
